package com.sample.hiradate;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.nio.file.FileSystem;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Properties;

import static org.powermock.api.mockito.PowerMockito.*;

/**
 * テスト用ユーティリティ
 */
public class TestUtil {

	/**
	 * @param propertyName
	 *            プロパティファイルのパス
	 * @throws IOException
	 *             ファイルの読み込みに失敗
	 */
	public static void setenv(String propertyName) throws IOException {
		setenv(propertyName, false);
	}

	/**
	 * @param propertyName
	 *            プロパティファイルのパス
	 * @param verbose
	 *            環境変数の設定を出力
	 * @throws IOException
	 *             ファイルの読み込みに失敗
	 */
	public static void setenv(String propertyName, boolean verbose) throws IOException {

		// モックに設定
		spy(Env.class);

		// ファイルの指定
		FileInputStream fs = new FileInputStream(propertyName);

		// プロパティの設定
		Properties properties = new Properties();
		properties.load(fs);

		// プロパティを環境変数(のモック)に登録
		for (String name : properties.stringPropertyNames()) {
			String value = properties.getProperty(name);
			try {
				when(Env.class, "getEnv", name).thenReturn(value);
			} catch (Exception e) {
				e.printStackTrace();
			}

			// 中身を見たいときは出力
			if (verbose) {
				System.out.println("[TestUtil#setenv] " + name + " = " + value);
			}
		}
	}

	/**
	 * 
	 * テスト用の分散キャッシュどうにかするクラス
	 *
	 */
	static class DistributedChacheFile {
		private ArrayList<File> list = new ArrayList<>();

		/**
		 * テスト用に分散キャッシュを用意
		 * 
		 * @param tableName
		 *            テーブル名
		 * @throws IOException
		 *             何かしらエラー
		 */
		public void prepare(String tableName) throws IOException {

			// パス
			File source = new File(Env.getEnv(tableName));
			File dst = new File(tableName);

			// ワーキングディレクトリにコピー
			copy(source, dst);

			list.add(dst);
		}

		/**
		 * 用意した分散キャッシュを削除
		 * 
		 * @throws IOException
		 *             何かしらエラー
		 */
		public void cleanup() throws IOException {
			for (File path : list) {
				path.delete();
			}
		}
	}

	/**
	 * @param source
	 * @param dst
	 * @throws IOException
	 */
	public static void copy(File source, File dst) throws IOException {
		
		File[] fromFile = source.listFiles();
		if (fromFile == null || fromFile.length == 0) {
			return;
		}
		
		dst.mkdir();
		for (File f : fromFile) {
			if (f.isFile()) {
				File newFile = new File(dst.toString() + "/" + f.getName());
				Files.copy(f.toPath(), newFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
			} else {
				copy(f, dst);
			}
		}
	}
}
