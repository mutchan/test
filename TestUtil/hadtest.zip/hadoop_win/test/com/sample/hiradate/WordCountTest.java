/**
 * 
 */
package com.sample.hiradate;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.sample.hiradate.TestUtil.DistributedChacheFile;

/**
 * @author Mutsuki Hiradate
 *
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({ Env.class })
@PowerMockIgnore({ "com.sun.*", "org.apache.*" })
public class WordCountTest {

	/**
	 * @throws java.lang.Exception
	 *             a
	 */
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 *             a
	 */
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 *             a
	 */
	@Before
	public void setUp() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 *             a
	 */
	@After
	public void tearDown() throws Exception {
	}

	/**
	 * @throws Exception
	 *             a
	 */
	@Test
	public void test() throws Exception {
		String[] args = { //
				"E:\\java\\testdata\\input", //
				"E:\\java\\testdata\\output" };

		TestUtil.setenv("conf/env.property", true);
		
		DistributedChacheFile manager = new DistributedChacheFile();
		manager.prepare("cc");
		
		System.out.println(Env.getEnv("aa"));

		try {
			WordCount.main(args);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		
		manager.cleanup();
		
		fail("まだ実装されていません");
	}

}
