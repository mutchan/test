package com.sample.hiradate;

import java.io.File;
import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.ArrayWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.log4j.PropertyConfigurator;

class TextArrayWritable extends ArrayWritable implements WritableComparable<TextArrayWritable>{
	public TextArrayWritable() {
		super(Text.class);
	}

	@Override
	public int compareTo(TextArrayWritable o) {
		Writable[] wr1 = this.get();
		Writable[] wr2 = o.get();
		
		if(wr1.length != wr2.length){
			return 1;
		}
		
		for(int i = 0; i < wr1.length; ++i){
			if( ((Text)wr1[i]).compareTo((Text)wr2[i]) == 1 ){
				return 1;
			}
		}
		
		return 0;
	}
}

/**
 * @author Mutsuki Hiradate
 *
 */
public class WordCount {

	/**
	 * @author Mutsuki Hiradate
	 *
	 */
	public static class Map extends Mapper<LongWritable, Text, TextArrayWritable, IntWritable> {
		private final static IntWritable one = new IntWritable(1);
		private TextArrayWritable word = new TextArrayWritable();

		@Override
		protected void map(LongWritable key, Text value,
				Mapper<LongWritable, Text, TextArrayWritable, IntWritable>.Context context)
				throws IOException, InterruptedException {
			String line = value.toString();
			String[] tokenizer = line.split(" ");

			Text[] text = new Text[tokenizer.length];

			for (int i = 0; i < tokenizer.length; i++) {
				text[i] = new Text(tokenizer[i]);
			}
			word.set(text);
			context.write(word, one);
		}
	}

	/**
	 * @author Mutsuki Hiradate
	 *
	 */
	public static class Reduce extends Reducer<TextArrayWritable, IntWritable, Text, IntWritable> {
		
		Text text = new Text();
		
		@Override
		protected void reduce(TextArrayWritable key, Iterable<IntWritable> values,
				Reducer<TextArrayWritable, IntWritable, Text, IntWritable>.Context context)
				throws IOException, InterruptedException {
			int sum = 0;
			for (IntWritable value: values) {
				sum += value.get();
			}

			for (String str : key.toStrings()) {
				text.set(str);
				context.write(text, new IntWritable(sum));
			}
		}
	}

	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		PropertyConfigurator.configure("conf/log4j.properties");
		delete(args[1]);
		
		Configuration conf = new Configuration();
		
		Job job = new Job(conf, "wordcount");

		job.setMapOutputKeyClass(TextArrayWritable.class);
		job.setMapOutputValueClass(IntWritable.class);

		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(IntWritable.class);

		job.setMapperClass(Map.class);
//		job.setCombinerClass(Reduce.class);
		job.setReducerClass(Reduce.class);

		job.setInputFormatClass(TextInputFormat.class);
		job.setOutputFormatClass(TextOutputFormat.class);

		FileInputFormat.setInputPaths(job, new Path(args[0]));
		FileOutputFormat.setOutputPath(job, new Path(args[1]));

		job.waitForCompletion(true);
	}

	private static void delete(String string) {
		File f = new File(string);
        
		/*
         * ファイルまたはディレクトリが存在しない場合は何もしない
         */
        if(f.exists() == false) {
            return;
        }

        if(f.isFile()) {
            /*
             * ファイルの場合は削除する
             */
            f.delete();

        } else if(f.isDirectory()){
            /*
             * ディレクトリの場合は、すべてのファイルを削除する
             */

            /*
             * 対象ディレクトリ内のファイルおよびディレクトリの一覧を取得
             */
            File[] files = f.listFiles();

            /*
             * ファイルおよびディレクトリをすべて削除
             */
            for(int i=0; i<files.length; i++) {
                /*
                 * 自身をコールし、再帰的に削除する
                 */
                delete( files[i].getAbsolutePath() );
            }
            /*
             * 自ディレクトリを削除する
             */
            f.delete();
        }
	}
}