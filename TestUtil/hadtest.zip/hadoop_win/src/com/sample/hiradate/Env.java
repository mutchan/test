package com.sample.hiradate;

/**
 * 
 * @author Mutsuki Hiradate
 *
 */
public class Env {

	/**
	 * @param name 環境変数名
	 * @return env_string
	 */
	public static String getEnv(String name) {
		//System.out.println(name);

		if (System.getenv(name) == null) {
			return "none";
		}

		return System.getenv(name);
	}
	
	public static void set(String set){
		System.out.println(set);
	}
}
