//Copyright FUJITSU LIMITED 2016
package com.fujitsu.soft.rad.devsemi;

/**
 * 商品の追加をするクラスです
 * 
 * @author Shimada(G03)
 */
public class NewItemBean {
	// 商品フィールド(仮)
	private String url;
	private String name;
	private String category;
	private String detail;
	// 公開非公開

	public NewItemBean() {
		this.url = "aaa";// 商品画像のURL
		this.name = "bbb";// 商品の名前
		this.category = "ccc";// 商品のカテゴリ
		this.detail = "ddd";// 商品の詳細
	}

	/**
	 * 画像のURL,説明文,名前,カテゴリが不正でないのかチェックする @
	 */
	public Boolean checkItemRegister() {
		boolean check = true;// 不正なときfalse
		//

		// 画像が不正でないか
		if (getURL() != null) {
			check = false;
		}
		// 説明文が不正でないか
		if (getDetail() != null) {
			check = false;
		}
		// categoryが不正でないか
		if (getCategory() != null) {
			check = false;
		}
		// nameが不正でないか
		if (getName() != null) {
			check = false;
		}
		return check;
	}

	/**
	 * 商品を追加するメソッド
	 * 
	 * @商品の情報
	 */
	public String addItem() {

		return "";
	}

	public String getURL() {
		return this.url;
	}

	public String getName() {
		return this.name;
	}

	public String getCategory() {
		return this.category;
	}

	private String getDetail() {
		return this.detail;
	}
}
