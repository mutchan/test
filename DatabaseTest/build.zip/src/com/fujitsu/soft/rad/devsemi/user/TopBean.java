//Copyright FUJITSU LIMITED 2016

package com.fujitsu.soft.rad.devsemi.user;

import com.fujitsu.soft.rad.devsemi.Sort;

/**
 * トップページの豆を蒔きます．
 * 
 * @author Omishima, Senchi(G03)
 */

import com.fujitsu.soft.rad.devsemi.entity.*;
import java.util.*;
import java.util.stream.Collectors;
import java.awt.ItemSelectable;
import java.io.Serializable;

import javax.annotation.Resource;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.UserTransaction;

import com.fujitsu.soft.rad.devsemi.entity.Item;
import com.fujitsu.soft.rad.devsemi.entity.UserAccount;
import com.fujitsu.soft.rad.devsemi.stub.AccountManagerStub;
import com.fujitsu.soft.rad.devsemi.stub.ItemManagerStub;
import com.fujitsu.soft.rad.devsemi.stub.ReviewManagerStub;
import com.fujitsu.soft.rad.devsemi.user.manager.AccountManager;
import com.fujitsu.soft.rad.devsemi.user.manager.ItemManager;
import com.fujitsu.soft.rad.devsemi.user.manager.ReviewManager;

@Named
@RequestScoped /* scopeはすぐ死ぬならこれで大丈夫らしい． */
public class TopBean implements Serializable {
	@PersistenceContext(unitName = "Numazon")
	private EntityManager em;
	
	@Resource
	UserTransaction utx;
	/**
	 * 
	 * @return おすすめ商品のリスト（リストの中身の型はitem）
	 */

	/**
	 * オススメアイテムリストを出力します。
	 * @return
	 */
	
	private final boolean STUBTEST = false;
	
	/**
	 * オススメ商品リストを取り出す。
	 * @return オススメ商品リスト
	 */
	public List<Item> getRecommendItemList(){
		//アイテムマネージャーに問い合わせる kudo
		//
		List<Item> items = new ArrayList<Item>();
		if(STUBTEST)
		{
			ItemManagerStub im = new ItemManagerStub();
			items = im.getRecommendItemList();
			/* データベースにおすすめ商品5位までを問い合わせて，リストitemsに追加していきます． */
		}
		else
		{
			//レビューから4点以上のものを抜き出して、Dateでソート、そのあとにidを射影する。
			ReviewManager rm = new ReviewManager(em,utx);
			ItemManager im = new ItemManager(em, utx);
			List<Review> rs = rm.getRecommendReviewList();
			if(rs.size() >= 3)
			{
				Sort.sortReviewByDate(rs);
				List<Integer> idlist = rs.stream().map(s->s.getItemId()).distinct().collect(Collectors.toList());
				if(idlist.size()>= 3)
				{
					items.add(im.getItem(idlist.get(0)));
					items.add(im.getItem(idlist.get(1)));
					items.add(im.getItem(idlist.get(2)));
				}
			}
		}
		
		return items;
	}
	
	/**
	 * 与えられたランクのオススメアイテムを出力します。
	 * @param rank
	 * @return
	 */
	public Item getRecommendItem(int rank)
	{
		List<Item> itemList = getRecommendItemList();
		
		return itemList.get(rank-1);
	}
	
	/**
	 * 
	 * @return YP廃人のリスト（リストの中身の型はaccount）
	 */
	public List<UserAccount> getAccountRanking(){
		//アカウントマネージャに問い合わせる。
		List<UserAccount> accounts = new ArrayList<UserAccount>();
		AccountManagerStub am = new AccountManagerStub();
		accounts = am.getYPRankList();
		/* データベースに廃人5人を問い合わせて，リストaccountsに追加していきます． */
		if(STUBTEST)
		{
			
		}else{
			//AccountManager am = new AccountManager(em,utx);
			
		}
		return accounts;
	}
	
	public UserAccount getYPRankAccount(int rank)
	{
		return getAccountRanking().get(rank-1);
	}
	
	/**
	 * 
	 * @return ポップアップを出す場合はtrue，出さない場合はfalse
	 */
	public boolean getReviewPopup(){
		/* 
		 * データベースに買ったのにレビューしてない商品があるか問い合わせて，ある場合trueを，ない場合falseを返します．
		 * 問い合わせる術がないのでここではとりあえずtrueを返すようにしておきます（TODO）
		 */
		//アカウントに問い合わせる
		return true;
	}
	public String getRecommendReview(int rank)
	{
		
		if(STUBTEST)
		{
			ItemManagerStub im = new ItemManagerStub();
			return im.getRecommendReview(rank).getComment();
		}else
		{
			List<Item> itemList = getRecommendItemList();
			ReviewManager rm = new ReviewManager(em,utx);
			List<Review> reviewlist = rm.getReviewListByItemId(itemList.get(rank-1).getId());
			Sort.sortReviewByStar(reviewlist);
			return reviewlist.get(0).getComment();
		}
		
		
	}

}
