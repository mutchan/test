package com.fujitsu.soft.rad.devsemi.user;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.UserTransaction;

import com.fujitsu.soft.rad.devsemi.entity.Avatar;
import com.fujitsu.soft.rad.devsemi.entity.Cart;
import com.fujitsu.soft.rad.devsemi.entity.Item;
import com.fujitsu.soft.rad.devsemi.entity.Review;
import com.fujitsu.soft.rad.devsemi.stub.ItemManagerStub;
import com.fujitsu.soft.rad.devsemi.stub.ReviewManagerStub;
import com.fujitsu.soft.rad.devsemi.user.manager.AccountManager;
import com.fujitsu.soft.rad.devsemi.user.manager.AvatarManager;
import com.fujitsu.soft.rad.devsemi.user.manager.CartManager;
import com.fujitsu.soft.rad.devsemi.user.manager.ItemManager;
import com.fujitsu.soft.rad.devsemi.user.manager.ReviewManager;

/*
 * 各商品の詳細を出すクラス
 * @auther Okano Naoki (6/28)
 */

@Named
@RequestScoped
public class DetailBean implements Serializable{
	@PersistenceContext(unitName = "Numazon")
	private EntityManager em;
	
	@Resource
	UserTransaction utx;
	
	private final boolean STUBTEST = false;
	
	private String imagePath;//画像へのパス
	private double averageStar;//評価の星の平均
	private String name;//商品の名前
	private int price;//商品の単価
	private int count;//商品をカートに入れる数
	private int stock;//商品の在庫数
	private String desc;//商品の説明descrption
	List<Review> review = new ArrayList<Review>();// 商品のレビューのリスト
	private String selectedImage;//レビューのアバター
	private String comment;//レビュー欄のコメント
	private int selectedStar;//レビュー欄の星の選択
	List<String> reviewImagePath = new ArrayList<String>();//他の人のレビューのアバターたち
	private int itemID = 0;//htmlでこのitemIDをsetして、そのitemを表示させる。テストでとりあえず0
	//ここからgetter,setter
	
	public String getImagePath() {
		//Stabでテスト
		if(STUBTEST)
		{
			ItemManagerStub im = new ItemManagerStub();
			imagePath = im.getItem(itemID).getImagePath();
		}else
		{
			ItemManager im = new ItemManager( em , utx );
			Item item = im.getItem(itemID);
			if(item != null){
				imagePath = item.getImagePath();
			}
		}
		return imagePath;
	}
	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}
	public double getAverageStar() {
		return averageStar;
	}
	public void setAverageStar(double averageStar) {
		this.averageStar = averageStar;
	}
	public String getName() {
		if(STUBTEST)
		{
			ItemManagerStub im = new ItemManagerStub();
			name = im.getItemName(itemID);
		}else{
			ItemManager im = new ItemManager( em , utx );
			Item item = im.getItem(itemID);
			if(item != null){
				name = item.getName();
			}
		}
		
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPrice() {
		if(STUBTEST)
		{
			ItemManagerStub im = new ItemManagerStub();
			price = im.getItem(itemID).getPrice();
		}else{
			ItemManager im = new ItemManager( em , utx );
			Item item = im.getItem(itemID);
			if(item != null)price = item.getPrice();
		}
		
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public int getStock() {
		if(STUBTEST)
		{
			ItemManagerStub im = new ItemManagerStub();
			stock = im.getItem(itemID).getStock();
		}else{
			ItemManager im = new ItemManager( em , utx );
			Item item = im.getItem(itemID);
			if(item != null)stock = item.getStock();
		}
		
		return stock;
	}
	public void setStock(int stock) {
		this.stock = stock;
	}
	public String getDesc() {
		if(STUBTEST)
		{
			//Stabでテスト
			ItemManagerStub im = new ItemManagerStub();
			desc = im.getItem(itemID).getDesc();
		}else{
			ItemManager im = new ItemManager( em , utx );
			Item item = im.getItem(itemID);
			if(item != null)desc = item.getDesc();
		}
		
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public List<Review> getReview() {
		if(STUBTEST)
		{
			ReviewManagerStub rm = new ReviewManagerStub();
			review = rm.getItemReviewList(itemID);
		}
		else
		{
			ReviewManager rm = new ReviewManager(em,utx);
			review = rm.getReviewListByItemId(itemID);
		}
		
		return review;
	}
	public void setReview(ArrayList<Review> review) {
		this.review = review;
	}
	public String getSelectedImage() {
		return selectedImage;
	}
	public void setSelectedImage(String selectedImage) {
		this.selectedImage = selectedImage;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public int getSelectedStar() {
		return selectedStar;
	}
	public void setSelectedStar(int selectedStar) {
		this.selectedStar = selectedStar;
	}
	public List<String> getReviewImagePath() {
		return reviewImagePath;
	}
	public void setReviewImagePath(ArrayList<String> reviewImagePath) {
		this.reviewImagePath = reviewImagePath;
	}
	//ここまでgetter,setter
	
	/*
	 * カートに追加を押したときにカートに追加するメソッド？
	 */
	public String onClickAddCart(){
		//カートマネージャを呼び出してカートに突っ込んでもらう。
		CartManager cm =new CartManager(em,utx);
		AccountManager am = new AccountManager(em,utx);
		Cart cart = new Cart();
		
		cart.setCount(count);
		cart.setItemId(itemID);
		cart.setAccountId(am.getCurrentUserAccount().getGlocommId());
		System.out.println("DEBUG:onClickAddCart,count:"+count+",itemID:"+itemID);
		cm.addCart(cart);
		return "cart.xhtml";//Todo:htmlさんにがんばってもらう
	}
	
	/*
	 *カートに加えた商品の個数をセットするメソッド 
	 */
	public void setClickAddCart(int count){	
		//Todo:htmlさんにがんばってもらう
		
	}
	/*
	 * レビューするボタンをクリックして投稿するメソッド
	 */
	public void onClickReview(){
		//ajaxでがんばる
		System.out.println("DEBUG:onClickReview,comm:"+comment+",star:"+selectedStar);
		
		if(STUBTEST)
		{
			Review review = new Review();
			Avatar avatar = new Avatar();//TODO:ちゃんとつくる
			
			//reviewIdのsetはadd側で行う
			review.setAccountId("test");//TODO:アカウントの処理
			review.setComment(comment);
			review.setDate(new Date());
			review.setGoodCount(0);
			review.setAvatar(avatar);//TODO:画像の処理は後回し
			review.setItemId(itemID);
			review.setStar(selectedStar);//取得する
			
			ReviewManagerStub rm = new ReviewManagerStub();
			rm.addReview(review);
		}
		else
		{
			AccountManager am = new AccountManager(em,utx);
			ReviewManager rm = new ReviewManager(em,utx);
			AvatarManager avm = new AvatarManager(em,utx);
			/**
			 * TODO:Avatarの処理
			 */
			rm.postReview(itemID,comment,avm.getAvatar(2),am.getCurrentUserAccount().getGlocommId(),selectedStar);//AccountIdを取得する処理
		}
		
	}
	
	/*
	 * レビュー定型文のフレーズのgetter
	 */
	public List<String> getPhrase(){
		//Todo:htmlさんにがんばってもらう
		return null;
	}
	
	public List<String> ImageList(){
		//Todo:
		return null;
	}
	
	/*
	 * いいねをクリックしたときにいいねをするメソッド
	 */
	public String onClickGood(int reviewid)
	{
		System.out.println("onClickGood" + reviewid);
		return "#";
	}
	/**
	 * @return the itemID
	 */
	public int getItemID() {
		return itemID;
	}
	/**
	 * @param itemID the itemID to set
	 */
	public void setItemID(int itemID) {
		this.itemID = itemID;
	}
	public void preRenderDetail()
	{
		//System.out.println("DEBUG:preRender");
		//temp
	}
	public boolean checkItemIdURL()
	{
		if(STUBTEST)
		{
			ItemManagerStub im = new ItemManagerStub();
			return im.getItem(itemID).getId() != -1;
		}
		else
		{
			return true;
		}
		
		
		//System.out.println("DEBUG:checkItemIdURL");
		
	}
}
