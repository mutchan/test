package com.fujitsu.soft.rad.devsemi.seller;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.fujitsu.soft.rad.devsemi.entity.Item;
import com.fujitsu.soft.rad.devsemi.entity.Sales;

import java.io.Serializable;

public class ItemViewBean implements Serializable {
	ArrayList<Sales> salesList = new ArrayList<Sales>();// 売り上げを表すSalesクラスがあるらしい
	private String newPicPath;// 商品画像へのパス
	private String newName;// 商品の名前
	private String newDetail;// 商品詳細
	ArrayList<String> reviewList = new ArrayList<String>();// 商品のレビューのリスト

	/**
	 * 一年間の商品の売り上げをもらうメソッド 商品の価格遷移のグラフを出すため？
	 */
	public List<Item> getOneYearsSalesList() {// 何の型で返すか分からないです…
		return null;
	}

	/**
	 * 商品説明のデータの編集をするメソッド
	 */
	public String editItemData() {
		return null;
	}

	/**
	 * 商品のレビューを削除するメソッド
	 */
	public String delReview(){
		return null;
	}

	public ArrayList<Sales> getSalesList() {
		return salesList;
	}

	public void setSalesList(ArrayList<Sales> salesList) {
		this.salesList = salesList;
	}

	public String getNewPicPath() {
		return newPicPath;
	}

	public void setNewPicPath(String newPicPath) {
		this.newPicPath = newPicPath;
	}

	public String getNewName() {
		return newName;
	}

	public void setNewName(String newName) {
		this.newName = newName;
	}

	public String getNewDetail() {
		return newDetail;
	}

	public void setNewDetail(String newDetail) {
		this.newDetail = newDetail;
	}

	public ArrayList<String> getReviewList() {
		return reviewList;
	}

	public void setReviewList(ArrayList<String> reviewList) {
		this.reviewList = reviewList;
	}

}
