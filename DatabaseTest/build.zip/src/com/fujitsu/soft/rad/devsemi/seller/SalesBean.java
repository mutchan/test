package com.fujitsu.soft.rad.devsemi.seller;

import java.io.Serializable;
import java.util.List;
import java.util.Random;

import javax.enterprise.context.RequestScoped;
import javax.inject.Named;

import com.fujitsu.soft.rad.devsemi.entity.Item;
import com.fujitsu.soft.rad.devsemi.stub.ItemManagerStub;

@Named
@RequestScoped
@SuppressWarnings("serial")
/**
 * 売り上げ画面です
 * 
 */
public class SalesBean implements Serializable {

	private int ItemID;// 現状はint型で(6/27) とりあえずItemのIは大文字で
	private int salesNum;
	private int subTotal;
	private int Tax;// ややこしいけど内税のことです（小計が100円なら8円のこと）、とりあえずTは大文字で
	private int date;// intでいいのか怪しいです
	private boolean alert; // 必要ないかもしれない
	private Item selectedStock;

	/**
	 * 在庫が不足しているか判断するメソッド 在庫の不測の基準はいまだ不明ですね 在庫が残り1割りを下回ったらtrue,下回っていなかったらfalse
	 * salesNum: 在庫数
	 * subTotal：　現在の単価
	 * @return true(在庫1割以下) false(在庫1割以上)
	 * 
	 */

	public boolean checkAlert(int salesNum, int subTotal) {
		/**
		 * salesNum: 現在の在庫数
		 * subTotal: 現在の価格
		 * アルゴリズム
		 * 在庫数が10個以下かつ現在の価格が100,000円ならばtrue
		 * 在庫数が100個以下かつ現在の価格が15,000円ならばtrue
		 * 在庫数が1000個以下かつ現在の価格が1,000円ならばtrue
		 */
		boolean ch = false;
		if(salesNum<=30&&subTotal==10000){ // テスト用に10→30、100000→10000に変更している
			ch=true;
		}else if(salesNum<=1000&&subTotal==14000){
			ch=true;
		}else if(salesNum<=10000&&subTotal==1000){
			ch=true;
		}
		return ch;
	} // なんか値返すの？

	/*
	 * 表中の小計を計算するメソッド 単価が変わるので結構めんどそう
	 */
	public int calcSubtotal() {
		return 0;
	}

	/*
	 * 表中の内税を計算するメソッド 小計×税率(0.08)ですかね
	 */
	public int calcTax() {
		return (int) (calcSubtotal() * 0.08);// intに型変換している 小数点以下切り捨て
	}

	public int getItemID() {
		return ItemID;
	}

	public void setItemID(int itemID) {
		this.ItemID = itemID;
	}

	public int getSalesNum() {
		return salesNum;
	}

	public void setSalesNum(int salesNum) {
		this.salesNum = salesNum;
	}

	public int getSubtotal() {
		return subTotal;
	}

	public void setSubtotal(int subTotal) {
		this.subTotal = subTotal;
	}

	public int getTax() {
		return Tax;
	}

	public void setTax(int tax) {
		this.Tax = tax;
	}

	/*
	 * 必要ないかもしれない
	 */
	public boolean getAlert() {
		return this.alert;
	}

	public void setAlert(boolean alert) {
		this.alert = alert;
	}

	/**
	 * 商品リストの取得
	 * 
	 * @return 商品リスト
	 */
	public List<Item> getSalesList() {
		return new ItemManagerStub().getItemList();
	}

	/**
	 * 選択された行の取得
	 * 
	 * @return 選択された在庫
	 */
	public Item getSelectedStock() {
		return selectedStock;
	}

	/**
	 * 選択された行の設定
	 * 
	 * @param selectedStock
	 *            選択された行の
	 */
	public void setSelectedStock(Item selectedStock) {
		this.selectedStock = selectedStock;
	}

}
