package com.fujitsu.soft.rad.devsemi.seller;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.UserTransaction;

import com.fujitsu.soft.rad.devsemi.entity.Item;
import com.fujitsu.soft.rad.devsemi.user.manager.ItemManager;

/**
 * 在庫管理画面のビーン
 * @author jumma kudo
 *
 */
@SuppressWarnings("serial")
@Named
@RequestScoped
public class StockBean implements Serializable {
	@PersistenceContext(unitName = "Numazon")
	private EntityManager em;
	
	@Resource
	UserTransaction utx;
	
	private HashMap<Integer, Integer> addStockList = new HashMap<Integer, Integer>();// 在庫の追加数ハッシュマップ：商品ID,追加数
	private Item selectedStock;
	private ItemManager im;

	private List<Item> itemList;

	@PostConstruct
	public void init() {
		im = new ItemManager(em, utx);
		itemList = im.getAllItemList();
	}

	/**
	 * 在庫追加リストの設定
	 * 
	 * @param addStockList
	 *            在庫追加リスト
	 */
	public void setAddStockList(HashMap<Integer, Integer> addStockList) {
		this.addStockList = addStockList;
	}

	/**
	 * 在庫追加リストの取得
	 * 
	 * @return 在庫追加リスト
	 */
	public HashMap<Integer, Integer> getAddStockList() {
		return addStockList;
	}

	/**
	 * html側で追加する数を見て、追加処理の結果を出力
	 * 
	 * @return 「○○○を××個追加しました。」というメッセージ
	 */
	public String getAddMessage() {
		System.out.println("Call getAddMessage()");
		String sRet = "";

		for (int id : addStockList.keySet()) {
			if (addStockList.get(id) != null) {
				// マネージャから商品名をもらう。
				sRet += im.getItem(id).getName() + "を" + addStockList.get(id) + "個追加しました。 \n";
			}
		}
		return sRet;
	}

	/**
	 * 在庫リストの取得
	 * 
	 * @return 在庫リスト
	 */
	public List<Item> getStockList() {
		return itemList;
	}

	/**
	 * 在庫追加を、マネージャに頼んで行うメソッド
	 * 
	 */
	public void onClickAdd() {
		for (int itemId : addStockList.keySet()) {
			if( addStockList.get(itemId) != null ){
				im.addStock(itemId, addStockList.get(itemId));
			}
		}
		itemList = im.getAllItemList();
	}

	/**
	 * 選択された行の取得
	 * 
	 * @return 選択された在庫
	 */
	public Item getSelectedStock() {
		return selectedStock;
	}

	/**
	 * 選択された行の設定
	 * 
	 * @param selectedStock
	 *            選択された行の
	 */
	public void setSelectedStock(Item selectedStock) {
		this.selectedStock = selectedStock;
	}

}
