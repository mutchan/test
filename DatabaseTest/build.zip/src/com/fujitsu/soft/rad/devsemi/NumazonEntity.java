package com.fujitsu.soft.rad.devsemi;

import java.io.Serializable;
import java.lang.String;
import javax.persistence.*;

/**
 * Entity implementation class for Entity: NumazonEntity
 *
 */

@SuppressWarnings("serial")
@Entity

@IdClass(NumazonEntityPK.class)
public class NumazonEntity implements Serializable {

	   
	@Id
	@GeneratedValue
	private int id;   
	@Id
	private String user_id;
	private String password;
	private static final long serialVersionUID = 1L;

	public NumazonEntity() {
		super();
	}   
	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}   
	public String getUser_id() {
		return this.user_id;
	}

	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}   
	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
   
}
