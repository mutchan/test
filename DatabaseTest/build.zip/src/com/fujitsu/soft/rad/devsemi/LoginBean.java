//Copyright FUJITSU LIMITED 2016

package com.fujitsu.soft.rad.devsemi;

import java.io.Serializable;

import javax.annotation.Resource;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.UserTransaction;

import com.fujitsu.soft.rad.devsemi.entity.SellerAccount;
import com.fujitsu.soft.rad.devsemi.entity.UserAccount;
import com.fujitsu.soft.rad.devsemi.user.manager.AccountManager;


/**
 * ログイン処理を行うクラスです．ログイン情報の保持？とかは他のところがやってくれるらしいので知りません．
 * 
 * @author Omishima, Senchi(G03)
 */

@Named
@RequestScoped /* scopeはすぐ死ぬならこれで大丈夫らしい． */
public class LoginBean implements Serializable {

	@PersistenceContext(unitName = "Numazon")
	private EntityManager em;

	@Resource
	UserTransaction utx;
	
	private String id;
	private String pass; /* passで名前はいいのか・・・ */
	
	/**
	 * 
	 * @return 成功時はトップページへのリンク
	 */
	public String onClickLogin() {
		AccountManager am = new AccountManager(em, utx);
		
		// 買い手側のIDとパスワードのチェック
		UserAccount user = am.userLogin(id, pass);
		if (user != null) {
			return "/user/top.xhtml?faces-redirect=true";
		}

		// 売り手側のIDとパスワードのチェック
		SellerAccount seller = am.sellerLogin(id, pass);
		if (seller != null) {
			return "/seller/seller.xhtml?faces-redirect=true";
		}

		// IDとパスワードが一致しない時はエラーページへ
		return "login-error.xhtml?faces-redirect=true";

	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		/*
		 * なんかヤバい入力だったら例外投げたほうがいいんだろうか． でもxhtmlの入力フォームのほうで，うまいこと弾いてくれそうな気もする．
		 */
		this.id = id;
		System.out.println(this.id);
	}

	public String getPass() {
		return pass;
	}

	public void setPass(String pass) {
		/* こっちも */
		this.pass = pass;
	}
}
