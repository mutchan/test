package com.fujitsu.soft.rad.devsemi;

import java.io.Serializable;
import java.lang.String;

/**
 * ID class for entity: NumazonEntity
 *
 */ 
public class NumazonEntityPK  implements Serializable {   
   
	         
	private int id;         
	private String user_id;
	private static final long serialVersionUID = 1L;

	public NumazonEntityPK() {}

	

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}
	

	public String getUser_id() {
		return this.user_id;
	}

	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	
   
	/*
	 * @see java.lang.Object#equals(Object)
	 */	
	public boolean equals(Object o) {
		if (o == this) {
			return true;
		}
		if (!(o instanceof NumazonEntityPK)) {
			return false;
		}
		NumazonEntityPK other = (NumazonEntityPK) o;
		return true
			&& getId() == other.getId()
			&& (getUser_id() == null ? other.getUser_id() == null : getUser_id().equals(other.getUser_id()));
	}
	
	/*	 
	 * @see java.lang.Object#hashCode()
	 */	
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + getId();
		result = prime * result + (getUser_id() == null ? 0 : getUser_id().hashCode());
		return result;
	}
   
   
}
