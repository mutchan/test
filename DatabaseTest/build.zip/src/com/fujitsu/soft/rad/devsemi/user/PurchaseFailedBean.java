package com.fujitsu.soft.rad.devsemi.user;
import java.io.Serializable;
	/*
	 * 購入不可画面にメッセージを出すBeanクラス
	 * @auther Okano Naoki (6/28)
	 */
public class PurchaseFailedBean  implements Serializable{
	
	private String message;

	public String getMessage() {
		return message;
	}
	//setterは使う予定はないので作っていません
}
