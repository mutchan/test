package com.fujitsu.soft.rad.devsemi;

import java.util.List;

import com.fujitsu.soft.rad.devsemi.entity.Item;
import com.fujitsu.soft.rad.devsemi.entity.Review;

public class Sort {
	public static void sortReviewByDate(List<Review> reviewlist)
	{
		reviewlist.sort( (c1,c2) -> c2.getDate().compareTo(c1.getDate()));
	}
	public static void sortReviewByStar(List<Review> reviewlist)
	{
		reviewlist.sort( (c1,c2) ->
		(c1.getStar() < c2.getStar())? 1 :
		(c1.getStar() == c2.getStar())?	0 : -1
				);
	}
}
