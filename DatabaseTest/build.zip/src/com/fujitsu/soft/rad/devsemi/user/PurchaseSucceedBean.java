//Copyright FUJITSU LIMITED 2016

package com.fujitsu.soft.rad.devsemi.user;

/**
 * 購入完了の豆です．残高を表すフィールドがあるだけです．
 * 
 * @author Omishima, Senchi(G03)
 */

import java.io.Serializable;

import javax.enterprise.context.RequestScoped;
import javax.inject.Named;

@Named
@RequestScoped
public class PurchaseSucceedBean implements Serializable {
	private int balance;

	public int getBalance() {
		return balance;
	}

	public void setBalance(int balance) {
		this.balance = balance;
	}

}
