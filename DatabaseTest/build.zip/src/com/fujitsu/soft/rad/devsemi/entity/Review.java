package com.fujitsu.soft.rad.devsemi.entity;

import java.io.Serializable;
import java.lang.String;
import java.util.Date;
import javax.persistence.*;

/**
 * Entity implementation class for Entity: Review
 *
 */
@Entity
@NamedQueries({ @NamedQuery(name = Review.FIND_ALL, query = "SELECT i FROM Review i"),
	@NamedQuery(name = Review.BY_ID, query = "SELECT i FROM Review i WHERE i.id = :id"),
	@NamedQuery(name = Review.BY_ACCOUNT_ID, query = "SELECT i FROM Review i WHERE i.accountId = :accountId"),
	@NamedQuery(name = Review.BY_ITEM_ID, query = "SELECT i FROM Review i WHERE i.itemId = :itemId") })
public class Review implements Serializable {

	public static final String FIND_ALL = "Review.findAll";
	public static final String BY_ID = "Review.findById";
	public static final String BY_ACCOUNT_ID = "Review.findByAccountId";
	public static final String BY_ITEM_ID = "Review.findByItemId";

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;

	@Column(name = "ACCOUNT_ID", length = 30)
	private String accountId;
	
	@Temporal(TemporalType.DATE)
	private Date date;

	@Column(name = "ITEM_ID")
	private int itemId;
	private String comment;
	private int star;

	@Column(name = "GOOD_COUNT")
	private int goodCount;

	@ManyToOne(targetEntity = Avatar.class)
	@JoinColumn(name = "AVATAR_ID", referencedColumnName = "id")
	private Avatar avatar;

	private static final long serialVersionUID = 1L;

	/**
	 * コンストラクタ
	 */
	public Review() {
		super();
	}

	/**
	 * IDの取得
	 * 
	 * @return ID
	 */
	public int getId() {
		return this.id;
	}

	/**
	 * IDの設定
	 * 
	 * @param id
	 *            設定するID
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * レビューしたアカウントのIDの取得
	 * 
	 * @return レビューしたアカウントのID
	 */
	public String getAccountId() {
		return this.accountId;
	}

	/**
	 * レビューしたアカウントのIDの設定
	 * @param accountId レビューしたアカウントのID
	 */
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	public Date getDate() {
		return this.date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public int getItemId() {
		return this.itemId;
	}

	public void setItemId(int itemId) {
		this.itemId = itemId;
	}

	public String getComment() {
		return this.comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public int getStar() {
		return this.star;
	}

	public void setStar(int star) {
		this.star = star;
	}

	public int getGoodCount() {
		return this.goodCount;
	}

	public void setGoodCount(int goodCount) {
		this.goodCount = goodCount;
	}
	
	public void addGoodCount(int goodCount)
	{
		this.goodCount+=goodCount;
	}

	public Avatar getAvatar() {
		return this.avatar;
	}

	public void setAvatar(Avatar avatar) {
		this.avatar = avatar;
	}

}
