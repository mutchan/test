package com.fujitsu.soft.rad.devsemi.user;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.enterprise.context.RequestScoped;
import javax.inject.Named;

import com.fujitsu.soft.rad.devsemi.entity.Cart;
import com.fujitsu.soft.rad.devsemi.entity.UserAccount;
import com.fujitsu.soft.rad.devsemi.stub.AccountManagerStub;
import com.fujitsu.soft.rad.devsemi.stub.CartManagerStub;
/**
 * 各商品の詳細を出すBean
 * @auther Okano Naoki (6/28)
 */
@SuppressWarnings("serial")
@Named
@RequestScoped
public class ConfirmBean implements Serializable{
	private AccountManagerStub am;
	private CartManagerStub cm;
	
	private UserAccount account;
	private List<Cart> cartList = new ArrayList<Cart>();
	private int total;//注文したときの合計金額
	private int tax;//内税
	private int balance;//残高
	
	public ConfirmBean(){
		am = new AccountManagerStub();
		cm = new CartManagerStub();
		
		account = am.getCurrentAccount();
		cartList = cm.getCartList(account.getGlocommId());
	}
	
	public List<Cart> getCartList() {
		return cartList;
	}

	public void setCartList(List<Cart> cartList) {
		this.cartList = cartList;
	}

	public int getTotal() {
		total = 0;
		for (Cart cart : cartList) {
			total += cart.getItem().getPrice() * cart.getCount();
		}
		
		tax = (int)(total * 0.05);
		total *= 1.05;
		
		return total;
	}

	public int getTax() {
		return tax;
	}
	
	public int getBalance() {
		balance = account.getMoney() - total;
		return balance;
	}
	
	public String purchase(){
		if(account.getMoney() < getTotal() ){
			return "purchasefailed";
		}
		return "purchasesucceed";
	}
	
	/*
	 * 確定ボタンを押したときにおこなうメソッド
	 */
	public void onClickSubmit(){
		//Todo:
	}
		
}
