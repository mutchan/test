package com.fujitsu.soft.rad.devsemi.user;

import java.io.Serializable;
import java.util.List;
import javax.faces.model.ListDataModel;
import org.primefaces.model.SelectableDataModel;

import com.fujitsu.soft.rad.devsemi.entity.Avatar;

/**
 * アバターのリスト
 * 
 * @author Hiradate, Mutsuki
 *
 */
public class AvatarDataModel extends ListDataModel<Avatar> implements SelectableDataModel<Avatar>, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2939048874488342492L;

	/**
	 * アバターのリストの設定
	 * 
	 * @param data
	 *            アバターのリスト
	 */
	public AvatarDataModel(List<Avatar> data) {
		super(data);
	}

	@Override
	public Object getRowKey(Avatar item) {
		return item.getId();
	}

	@Override
	public Avatar getRowData(String rowKey) {
		// アバターリストの取得
		List<Avatar> itemList = (List<Avatar>) getWrappedData();

		// キーに一致する要素を検索
		int key = Integer.parseInt(rowKey);
		return itemList.stream().filter(s -> s.getId() == key).findFirst().get();
	}
}
