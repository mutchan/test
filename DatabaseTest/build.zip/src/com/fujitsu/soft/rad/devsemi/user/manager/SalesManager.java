package com.fujitsu.soft.rad.devsemi.user.manager;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.transaction.HeuristicMixedException;
import javax.transaction.HeuristicRollbackException;
import javax.transaction.NotSupportedException;
import javax.transaction.RollbackException;
import javax.transaction.SystemException;
import javax.transaction.UserTransaction;

import com.fujitsu.soft.rad.devsemi.entity.Sales;

/**
 * 売り上げDBへのアクセス
 * @author Hiradae, Mutsuki
 *
 */
public class SalesManager {
	EntityManager em;
	UserTransaction utx;

	/**
	 * コンストラクタ
	 * 
	 * @param em
	 *            エンティティマネージャ
	 */
	public SalesManager(EntityManager em, UserTransaction utx) {
		this.em = em;
		this.utx = utx;
	}

	/**
	 * すべてのアバターの情報を取得
	 * 
	 * @return すべてのアバターのリスト
	 */
	public List<Sales> getAvatarList() {
		try {
			return em.createNamedQuery(Sales.FIND_ALL, Sales.class).getResultList();
		} catch (NoResultException e) {
			return new ArrayList<Sales>();
		}
	}

	/**
	 * すべてのアバターの情報を取得
	 * 
	 * @return すべてのアバターのリスト
	 */
	public List<Sales> getAvatarList(String glocommId) {
		try {
			return em.createNamedQuery(Sales.BY_ACCOUNT, Sales.class).setParameter("id", glocommId).getResultList();
		} catch (NoResultException e) {
			return new ArrayList<Sales>();
		}
	}
	
	/**
	 * 指定したIDのアバター情報を取得
	 * 
	 * @param avatarId
	 *            アバターのID
	 */
	public Sales getSales(int salesId) {
		try {
			return em.createNamedQuery(Sales.BY_ID, Sales.class).setParameter("id", salesId).getSingleResult();
		} catch (NoResultException e) {
			return null;
		}
	}

	/**
	 * アバターの削除
	 * 
	 * @param avatar
	 *            追加するカート
	 */
	public void removeSales(Sales sales) {
		try {
			utx.begin();
			em.remove(sales);
			utx.commit();
		} catch (NotSupportedException | SystemException | SecurityException | IllegalStateException | RollbackException
				| HeuristicMixedException | HeuristicRollbackException e) {
			e.printStackTrace();

			try {
				utx.rollback();
			} catch (IllegalStateException | SecurityException | SystemException e1) {
				e1.printStackTrace();
			}
		}
	}
}
