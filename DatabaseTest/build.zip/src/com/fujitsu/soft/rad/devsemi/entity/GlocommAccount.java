package com.fujitsu.soft.rad.devsemi.entity;

import java.io.Serializable;
import java.lang.String;
import javax.persistence.*;

/**
 * Entity implementation class for Entity: GlocommAccount
 *
 */
@Entity
@Table(name = "GLOCOMM_ACCOUNT")
@NamedQueries({ @NamedQuery(name = GlocommAccount.FIND_ALL, query = "select a from GlocommAccount a"),
		@NamedQuery(name = GlocommAccount.BY_GLOCOMM_ID, query = "select a from GlocommAccount a where a.id = :glocommId") })
public class GlocommAccount implements Serializable {
	public static final String FIND_ALL = "GlocommAccount.findAll";
	public static final String BY_GLOCOMM_ID = "GlocommAccount.byGlocommId";

	@Id
	private String id;
	private String pass;

	private static final long serialVersionUID = 1L;

	public GlocommAccount() {
		super();
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPass() {
		return this.pass;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}

}
