package com.fujitsu.soft.rad.devsemi.user.manager;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.transaction.HeuristicMixedException;
import javax.transaction.HeuristicRollbackException;
import javax.transaction.NotSupportedException;
import javax.transaction.RollbackException;
import javax.transaction.SystemException;
import javax.transaction.UserTransaction;

import com.fujitsu.soft.rad.devsemi.entity.Avatar;
import com.fujitsu.soft.rad.devsemi.entity.Review;

/**
 * レビューDBへのアクセス
 * 
 * @author Hiradate, Mutsuki
 *
 */
public class ReviewManager {
	EntityManager em;
	UserTransaction utx;

	/**
	 * コンストラクタ
	 * 
	 * @param em
	 *            エンティティマネージャ
	 */
	public ReviewManager(EntityManager em, UserTransaction utx) {
		this.em = em;
		this.utx = utx;
	}
	
	/**
	 * レビューIDからレビューを取得
	 * @param reviewId レビューID
	 */
	public Review getReview(int reviewId){
		try {
			return em.createNamedQuery(Review.BY_ID, Review.class).setParameter("id", reviewId).getSingleResult();
		} catch (NoResultException e) {
			return null;
		}
	}
	
	public List<Review> getRecommendReviewList()
	{
		try {
			return em.createQuery("select r from Review r where r.star >= 4", Review.class).getResultList();
		} catch (NoResultException e) {
			return null;
		}
	}
	
	
	/**
	 * 商品IDからレビューのリストを取得
	 * @param itemId 商品ID
	 */
	public List<Review> getReviewListByItemId(int itemId){
		try {
			return em.createNamedQuery(Review.BY_ITEM_ID, Review.class).setParameter("itemId", itemId).getResultList();
		} catch (NoResultException e) {
			return null;
		}
	}
	
	/**
	 * グロコミIDからレビューのリストを取得
	 * @param reviewId グロコミID
	 */
	public List<Review> getReviewListByAccountId(int accountId){
		try {
			return em.createNamedQuery(Review.BY_ACCOUNT_ID, Review.class).setParameter("accountId", accountId).getResultList();
		} catch (NoResultException e) {
			return null;
		}
	}

	/**
	 * レビューの投稿
	 *
	 * @param itemId
	 * @param comment
	 */
	public void postReview(int itemId, String comment, Avatar avatar, String accountId, int star) {
		try {
			utx.begin();
			Review review = new Review();
			
			review.setItemId(itemId);
			review.setComment(comment);
			review.setAvatar(avatar);
			review.setAccountId(accountId);
			review.setStar(star);
			review.setGoodCount(0);
			review.setDate(new Date());
			
			em.persist(review);
			utx.commit();
		} catch (NotSupportedException | SystemException | SecurityException | IllegalStateException | RollbackException
				| HeuristicMixedException | HeuristicRollbackException e) {
			e.printStackTrace();

			try {
				utx.rollback();
			} catch (IllegalStateException | SecurityException | SystemException e1) {
				e1.printStackTrace();
			}
		}
	}

	/**
	 * レビューの投稿
	 *
	 * @param itemId
	 * @param comment
	 */
	public void removeReview(int reviewId) {
		try {
			utx.begin();
			Review review = getReview(reviewId);			
			em.remove(review);
			utx.commit();
		} catch (NotSupportedException | SystemException | SecurityException | IllegalStateException | RollbackException
				| HeuristicMixedException | HeuristicRollbackException e) {
			e.printStackTrace();

			try {
				utx.rollback();
			} catch (IllegalStateException | SecurityException | SystemException e1) {
				e1.printStackTrace();
			}
		}
	}
}
