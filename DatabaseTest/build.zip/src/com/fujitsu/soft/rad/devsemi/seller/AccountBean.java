//Copyright FUJITSU LIMITED 2016

package com.fujitsu.soft.rad.devsemi.seller;

/**
 * アカウント変更処理を行うクラスです．
 * 
 * @author Omishima, Senchi(G03)
 */

import java.io.Serializable;

import javax.enterprise.context.RequestScoped;
import javax.inject.Named;

@Named
@RequestScoped
public class AccountBean implements Serializable {
	/*
	 * 名前が超どんくさい・・・ 上から順に現在のパスワード，変更後のパスワード，もう一回変更後のパスワードという感じです．
	 */
	private String passCurrent;
	private String passAfter;
	private String passAfterAgain;

	private boolean checkPassCurrent() {
		/*
		 * passCurrentが正しいかデータベースに問い合わせます．
		 * その際，IDとセットで聞かないと意味がないので，どこからかIDの情報をもらいます（たぶん）．
		 * とりあえず今は問い合わせる術がないのでfalseを投げるようにします．あとでちゃんと書き換えよう．
		 */
		return false;
	}

	private boolean checkPassAfter() {
		if (passAfter.equals(passAfterAgain)) {
			return true;
		}
		return false;
	}

	public void changePass() {
		if (!checkPassCurrent()) {
			/* 現在のパスワードが違います，とhtmlにお願いします． */
		} else {
			if (!checkPassAfter()) {
				/* 変更後の2つが一致してません，とhtmlにお願いします． */
			} else {
				/*
				 * 現在のパスワードpassCurrentをpassAfterに書き換えるようデータベースにお願いし，
				 * htmlに変更が完了した旨を伝えます．
				 */
			}
		}
	}

	/*
	 * とりあえず思考停止でgetter,setter作ってるけどいいんでしょうか．
	 * パスワードの文字数とか，使える記号とかの縛りはhtmlのほうでやる感じでしょうか． （それともこっちで判断して例外投げたほうがいいんでしょうか）．
	 */

	public String getPassCurrent() {
		return passCurrent;
	}

	public void setPassCurrent(String passCurrent) {
		this.passCurrent = passCurrent;
	}

	public String getPassAfter() {
		return passAfter;
	}

	public void setPassAfter(String passAfter) {
		this.passAfter = passAfter;
	}

	public String getPassAfterAgain() {
		return passAfterAgain;
	}

	public void setPassAfterAgain(String passAfterAgain) {
		this.passAfterAgain = passAfterAgain;
	}
}
