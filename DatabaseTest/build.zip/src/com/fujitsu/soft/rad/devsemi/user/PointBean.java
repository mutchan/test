// Copyright(c) FUJITSU lIMITED
package com.fujitsu.soft.rad.devsemi.user;

import java.sql.Date;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.io.Serializable;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.enterprise.context.RequestScoped;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.UserTransaction;

import org.primefaces.event.SelectEvent;
import org.primefaces.event.UnselectEvent;

import com.fujitsu.soft.rad.devsemi.entity.Avatar;
import com.fujitsu.soft.rad.devsemi.entity.UserAccount;
import com.fujitsu.soft.rad.devsemi.entity.PreservedAvatar;

import com.fujitsu.soft.rad.devsemi.stub.AvatarManagerStub;
import com.fujitsu.soft.rad.devsemi.user.AvatarDataModel;
import com.fujitsu.soft.rad.devsemi.user.manager.AccountManager;
import com.fujitsu.soft.rad.devsemi.user.manager.AvatarManager;
import com.fujitsu.soft.rad.devsemi.stub.AccountManagerStub;

/**
 * 
 * @author Kagajo Mitsuru
 *
 */

@Named
@RequestScoped
public class PointBean {

	@PersistenceContext(unitName = "Numazon")
	private EntityManager em;

	@Resource
	UserTransaction utx;

	// 一覧データ
	private AvatarDataModel avatarList;

	private List<Avatar> selectedAvatarList; // 選択されたアバターリスト
	private List<ExchangeHistory> exchangeHistoryList; // アバターの交換履歴

	private int predictPoint;
	private int currentPoint;

	AvatarManager avm;
	AccountManager acm;
	UserAccount account;

	/**
	 * 初期化
	 */
	@PostConstruct
	public void init() {
		avm = new AvatarManager(em, utx);
		acm = new AccountManager(em, utx);
		// 表示データ取得
		setAvatarList(new AvatarDataModel(avm.getAvatarList()));
		account = acm.getCurrentUserAccount();

		predictPoint = account.getPoint();
		currentPoint = account.getPoint();
		
		System.out.println("currentPoint:" + currentPoint);
	}

	/**
	 * @return avatarList
	 */
	public AvatarDataModel getAvatarList() {
		return avatarList;
	}

	/**
	 * @param avatarList
	 *            セットする avatarList
	 */
	public void setAvatarList(AvatarDataModel avatarList) {
		this.avatarList = avatarList;
	}

	/**
	 * @param selectedAvatarList
	 *            セットする selectedAvatarList
	 */
	public void setSelectedAvatarList(List<Avatar> selectedAvatarList) {
		this.selectedAvatarList = selectedAvatarList;
	}

	/**
	 * 
	 * @return チェックボックスで選択されたアバターのリスト
	 */
	public List<Avatar> getSelectedAvatarList() {
		return selectedAvatarList;
	}

	/**
	 * 交換した画像のパスを取得
	 * 
	 * @return
	 * @throws ParseException
	 */
	public List<PreservedAvatar> getAvatarExchangeList() throws ParseException {
		return new AvatarManagerStub().getAvatarExchangeList("user1");
	}

	/**
	 * 
	 * @return 所持Ypを取得
	 */
	public int getCurrentPoint() {
		return currentPoint;
	}

	/**
	 * 
	 * @return アバター交換後の残高
	 */
	public int getPredictPoint() {
		calcPredictPoint();
		return predictPoint;
	}

	/**
	 * "交換するが"押されたときに実行。 predictYpが0以上のとき、アバター交換可能。
	 */
	public void onClickExchange() {
		calcPredictPoint();
		if (predictPoint > 0) {
			acm.updateUserPoint(predictPoint);
			account = acm.getCurrentUserAccount();
			currentPoint = account.getPoint();
		}
	}

	/**
	 * 
	 * @return アバターの交換履歴のリスト
	 */
	public List<ExchangeHistory> getExchangeHistoryList() {
		return exchangeHistoryList;
	}

	/**
	 * アバターの交換履歴のリストのセッター
	 * 
	 * @param exchangeHistoryList
	 *            アバターの交換履歴のリスト
	 */
	public void setExchangeHistoryList(ArrayList<ExchangeHistory> exchangeHistoryList) {
		this.exchangeHistoryList = exchangeHistoryList;
	}

	/**
	 * 残りポイントの計算
	 */
	public void calcPredictPoint() {
		predictPoint = currentPoint;
		if (selectedAvatarList != null) {
			for (Avatar avatar : selectedAvatarList) {
				predictPoint -= avatar.getPoint();
			}
		}
	}

	/**
	 * 残りポイントの計算
	 */
	public String getExchangeString() {
		calcPredictPoint();
		if (predictPoint == currentPoint) {
			return "商品を選択してください";
		} else if (predictPoint < 0) {
			return "ポイントが足りません";
		} else {
			return "交換する";
		}
	}
}

/**
 * 交換履歴の履歴
 * 
 * @author Kagajo Mitsuru
 *
 */
class ExchangeHistory {
	Date date;
	String avatar;
	int avatarYp;
}
