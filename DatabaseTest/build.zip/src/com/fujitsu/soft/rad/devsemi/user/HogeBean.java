package com.fujitsu.soft.rad.devsemi.user;

import java.io.Serializable;
import java.util.ArrayList;

import javax.enterprise.context.RequestScoped;
import javax.inject.Named;

@SuppressWarnings("serial")
@RequestScoped
@Named
public class HogeBean implements Serializable {
	private String name;
	private int price;
	private int number;
	private int total;
	private int sums = 0;
	private int money = 10000; //残高
	private int restMoney;
	ArrayList<HogeBean> items;

	public HogeBean() {
		this.items = new ArrayList<>();
		System.out.println("Load init()");
		String tmp;
		HogeBean hoge;
		for (int i = 1; i < 5; i++) {
			tmp = "商品" + String.valueOf(i);
			// System.out.println(tmp);
			hoge = new HogeBean(tmp, 100, i);
			this.items.add(hoge);
			this.sums += hoge.total;
		}
		this.restMoney = this.money - this.sums;
	}

	public HogeBean(String name, int price, int number) {
		this.name = name;
		this.price = price;
		this.number = number;
		this.total = price * number;
	}

	/*
	 * @PostConstruct public void init(){ System.out.println("Load init()");
	 * String tmp; for(int i=1; i<5; i++){ tmp = "商品" + String.valueOf(i); //
	 * System.out.println(tmp); this.items.add(new HogeBean(tmp, 100, i)); } }
	 */

	public String python() {
		return "python";
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return this.name;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getPrice() {
		return this.price;
	}

	public void setNumber(int number) {
		this.number = number;
	}

	public int getNumber() {
		return this.number;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	public int getTotal() {
		return this.total;
	}
	
	public void setSums(int sums){
		this.sums = sums;
	}
	
	public int getSums(){
		return this.sums;
	}
	
	public void setMoney(int money){
		this.money = money;
	}
	public int getMoney(){
		return this.money;
	}
	
	public void setRestMoney(int restMoney){
		this.restMoney = restMoney;
	}
	
	public int getRestMoney(){
		return this.restMoney;
	}

	public void setItems(ArrayList<HogeBean> items) {
		this.items = items;
	}

	public ArrayList<HogeBean> getItems() {
		return this.items;
	}
}
