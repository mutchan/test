/** ItemManagerと不仲な状態です．この状態では全く動きません． **/

package com.fujitsu.soft.rad.devsemi.user;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.UserTransaction;

import com.fujitsu.soft.rad.devsemi.stub.ItemManagerStub;
import com.fujitsu.soft.rad.devsemi.entity.Item;
import com.fujitsu.soft.rad.devsemi.seller.*;
import com.fujitsu.soft.rad.devsemi.user.manager.*;

/**
 * 商品一覧のページのBean htmlと連携しやすいように大幅に変更してしまいました(6/30, Omishima)
 * 
 * @auther Okano Naoki (6/28)
 */

@SuppressWarnings("serial")
@Named
@RequestScoped
public class ListBean implements Serializable {
	private List<Item> itemList;
	private String keyword;
	
	public ListBean(){
		
	}
	
	public void setKeyword(String keyword){
		this.keyword = keyword;
	}
	public String getKeyword(){
		return keyword;
	}
	public List<Item> getItemList(){
		ItemManagerStub manager = new ItemManagerStub();
		itemList = manager.getItemList();
		if(keyword == null || keyword.length() == 0){
			return itemList;
		}else{
			List<Item> copy = new ArrayList<Item>();
			while(!itemList.isEmpty()){
				if(itemList.get(0).getName().contains(keyword)){
					copy.add(itemList.get(0));
				}
				itemList.remove(0);
			}
			itemList = copy;
			return itemList;
		}
	}
	/*
	
	@PersistenceContext(unitName = "Numazon")
	private EntityManager em;

	@Resource
	UserTransaction utx;

	
	private ItemManager manager;
	private List<Item> itemList;
	private String keyword;

	
	@PostConstruct
	public void init(){
		System.out.println(manager);
		manager = new ItemManager(em, utx);
		System.out.println(manager);
	}

	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}

	public String getKeyword() {
		return keyword;
	}

	public void setItemList(List<Item> itemList){
		this.itemList = itemList;
	}
	

	public List<Item> getItemList() {
		manager = new ItemManager(em, utx);
		System.out.println(em);
		if(keyword == null || keyword.length() == 0){
			itemList = manager.getAllItemList();
		}else{
			itemList = manager.getItemListContains(keyword);
		}
		return itemList;
	}
	*/

	/*
	 * xhtmlのほうの商品表示の条件を記述するのがダルいので，
	 * beanのほうでgetItemListをさらに分割させて，それを受け取って表示するようにしてます．
	 */
	public List<List<Item>> getDividedItemList() {
		List<Item> copy = new ArrayList<Item>();
		List<Item> list = getItemList();
		for (int i = 0; i < list.size(); i++) {
			copy.add(list.get(i));
		}
		if (list.size() < 4) {
			List<List<Item>> out = new ArrayList<List<Item>>();
			return out;
		} else {
			List<List<Item>> out = new ArrayList<List<Item>>();
			for (int i = 0; i < 3; i++) {
				copy.remove(0);
			}
			while (copy.size() >= 4) {
				List<Item> row = new ArrayList<Item>();
				for (int i = 0; i < 4; i++) {
					row.add(copy.get(0));
					copy.remove(0);
				}
				out.add(row);
			}
			if (copy.size() != 0) {
				out.add(copy);
			}
			return out;
		}
	}

	/*
	 * 試しにソート・フィルタの役割をもつメソッドをつくってみました． こんな感じで必要に応じて増やしていけばいいと思います．
	 */

	public void reverse() {
		Collections.reverse(itemList);
	}

	public void hidden() {
		itemList = new ArrayList<Item>();
	}
	
	public static void main(String[] args){
		ListBean lb = new ListBean();
		System.out.println(lb.getItemList() == null);
	}
}