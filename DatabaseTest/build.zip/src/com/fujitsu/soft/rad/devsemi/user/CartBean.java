package com.fujitsu.soft.rad.devsemi.user;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;

import com.fujitsu.soft.rad.devsemi.entity.Cart;
import com.fujitsu.soft.rad.devsemi.entity.Item;
import com.fujitsu.soft.rad.devsemi.entity.UserAccount;
import com.fujitsu.soft.rad.devsemi.stub.AccountManagerStub;
import com.fujitsu.soft.rad.devsemi.stub.CartManagerStub;
import com.fujitsu.soft.rad.devsemi.stub.ItemManagerStub;

import java.io.Serializable;

/**
 * カートの確認ビーン
 * 
 * @author kudo jumma
 *
 */

@SuppressWarnings("serial")
@Named
@RequestScoped
public class CartBean implements Serializable {
	private AccountManagerStub am;
	private CartManagerStub cm;

	private String message; // 「○○をカートに追加しました」メッセージ
	private List<Cart> cartList;// カートのリスト
	private UserAccount user; // 自分のユーザーアカウント
	private int total; // カートの合計
	private String alert; // 警告メッセージ

	@PostConstruct
	public void init() {
		// TODO:テストコードの修正
		cm = new CartManagerStub();
		am = new AccountManagerStub();

		user = am.getCurrentAccount();
		cartList = new ArrayList<Cart>();
		if (user != null) {
			String glocommId = user.getGlocommId();

			// カートマネージャからカートリストを受け取る
			cartList = cm.getCartList(glocommId);
		}
	}

	/**
	 * カートの削除ボタンを押したときの処理
	 */
	public void onClickRemove(String cartId) {
		System.out.println(cartId);
		// CartのDBにアクセス
		try {
			cm.removeCartItem(Integer.parseInt(cartId));
		} catch (NumberFormatException e) {
			throw new IllegalArgumentException("CartBean#onClickRemove 数値でないID \"" + cartId + "\" が指定されました");
		}
	}

	public String onClickConfirm() {
		// 注文確認画面へ飛ぶ
		System.out.println("click confirm"); // test用
		return "confirm";
	}

	/**
	 * cartの中見をマネージャに問い合わせて受け取り、返すメソッド
	 * 
	 * @return カートの中身
	 */
	public List<Cart> getCartList() {
		return cartList;
	}

	/**
	 * htmlで遷移するときに「○○をカートに追加しました」を入れる カートを確認して何もなかったら「カート内に商品がありません」をセットする
	 * 
	 * @param message
	 *            the message to set
	 */
	public String getMessage() {
		if (cartList.size() == 0) {
			message = "カート内に商品がありません";
		}

		// 「○○をカートに追加しました」処理

		return message;

	}

	public String getImagePath(int itemid){
		ItemManagerStub im = new ItemManagerStub();
		return im.getItem(itemid).getImagePath();
	}

	public String getItemName(int itemid) {
		ItemManagerStub im = new ItemManagerStub();
		
		return im.getItem(itemid).getName();
	}

	public int getItemPrice(int itemid){
		ItemManagerStub im = new ItemManagerStub();
		
		return im.getItem(itemid).getPrice();
	}
	
	/**
	 * リストから合計を出す。getで計算する
	 * 
	 * @return the total
	 */
	public int getTotal() {
		total = 0;
		ItemManagerStub im = new ItemManagerStub();
		for (Cart cart : cartList) {
			total += im.getItem(cart.getItemId()).getPrice() * cart.getCount();
		}
		return (int) (total * 1.08); // 消費税8%つけて切り捨て
	}

	/**
	 * 
	 * 「商品の在庫がありません」、「商品の在庫が足りません」、「残高が足りません」をセットして出力
	 * プルダウンを押したときにアラートのゲットを走らせて、表示部で表示する。
	 * 
	 * @return the alert
	 */
	public String getAlert() {
		// アイテムマネージャからカートと商品の在庫があるかの確認、
		ItemManagerStub im = new ItemManagerStub();
		for (Cart cart : cartList) {
			if (im.getItem(cart.getItemId()).getStock() < cart.getCount()) {
				alert = "商品の在庫が足りません";
			}
		}
		// アカウントの残高と商品合計を照らし合わせてアラートを表示
		if (user.getMoney() < getTotal()) {
			alert = "残高が足りません";
		}
		return alert;
	}

	/**
	 * ユーザーアカウントの取得
	 * 
	 * @return the user
	 */
	public UserAccount getUser() {
		return user;
	}

}
