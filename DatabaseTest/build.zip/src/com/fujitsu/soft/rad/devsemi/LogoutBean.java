//Copyright FUJITSU LIMITED 2016

package com.fujitsu.soft.rad.devsemi;

/**
 * ログアウト処理を行うクラスです。
 * loginBean.javaにaccountを追加しただけです。
 * @author Shimada(G03)
 */

import java.io.Serializable;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.UserTransaction;

import com.fujitsu.soft.rad.devsemi.entity.UserAccount;
/* TODO:スタブ使うためにインポートしました．あとで消そう */
import com.fujitsu.soft.rad.devsemi.stub.*;
import com.fujitsu.soft.rad.devsemi.user.manager.AccountManager;

@Named
@RequestScoped /* scopeはすぐ死ぬならこれで大丈夫らしい． */
public class LogoutBean extends LoginBean implements Serializable {
	@PersistenceContext(unitName = "Numazon")
	private EntityManager em;

	@Resource
	UserTransaction utx;
	
	/* @Injectってアノテーションつけてる例があるけど意味が分からない． */
	private String id;
	private String pass;
	private UserAccount account;// アカウント名です。変数
	private AccountManager am;

	public LogoutBean() {
	}
	
	@PostConstruct
	public void init(){
		am = new AccountManager(em, utx);
		account = am.getCurrentUserAccount();
	}

	/**
	 * ログアウト画面の「ようこそ、○○」の「○○」を返すメソッドです．
	 * 
	 * @return ユーザ名
	 */
	public String getName() {
		return account.getName();
	}
}
