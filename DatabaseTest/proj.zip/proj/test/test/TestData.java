package test;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.transaction.SystemException;
import javax.transaction.UserTransaction;

import com.fujitsu.soft.rad.devsemi.entity.Avatar;
import com.fujitsu.soft.rad.devsemi.entity.Bbs;
import com.fujitsu.soft.rad.devsemi.entity.Cart;
import com.fujitsu.soft.rad.devsemi.entity.GlocommAccount;
import com.fujitsu.soft.rad.devsemi.entity.Item;
import com.fujitsu.soft.rad.devsemi.entity.PreservedAvatar;
import com.fujitsu.soft.rad.devsemi.entity.Review;
import com.fujitsu.soft.rad.devsemi.entity.Sales;
import com.fujitsu.soft.rad.devsemi.entity.SellerAccount;
import com.fujitsu.soft.rad.devsemi.entity.UserAccount;
import com.fujitsu.soft.rad.devsemi.manager.AccountManager;
import com.fujitsu.soft.rad.devsemi.manager.ItemManager;
import com.fujitsu.soft.rad.devsemi.seller.Category;
import com.fujitsu.soft.rad.devsemi.seller.PublicStat;
import com.fujitsu.soft.rad.devsemi.stub.ItemManagerStub;

import java.util.List;
import com.fujitsu.soft.rad.devsemi.entity.Item;

/**
 * テスト用のデータベースの作成
 * 
 * @author Mutsuki Hiradate
 *
 */
@Named
@RequestScoped
public class TestData implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1176304073652316550L;

	@PersistenceContext(unitName = "Numazon")
	private EntityManager em;

	@Resource
	private UserTransaction utx;

	AccountManager am;
	ItemManager im;

	static final int USER_ACCOUNT_NUM = 10;
	static final int AVATAR_NUM = 10;
	static final int PRESERVED_AVATAR_NUM = 40;
	static final int REVIEW_NUM = 1000;
	static final int SALES_NUM = 100;
	static final int CART_NUM = 100;

	List<UserAccount> userAccount = new ArrayList<UserAccount>();
	List<Avatar> avatarList = new ArrayList<Avatar>();
	List<Item> itemList = new ArrayList<Item>();

	/**
	 * コンストラクタ
	 */
	@PostConstruct
	public void init() {
		am = new AccountManager(em, utx);
		im = new ItemManager(em, utx);
	}

	/**
	 * 
	 */
	public void createData() {
		// データベースのクリア
		clearDatabase();

		// 買い手アカウントのデータ作成
		createUserAccount();

		// 売り手アカウントのデータ作成
		createSellerAccount();

		// アバターのデータ作成
		createAvatar();

		// 商品のデータ作成
		createItem();

		// 商品レビューのデータ作成
		createReview();

		// 売上のデータ作成
		createSales();

		// カートのデータ作成
		createCart();
	}

	private void clearDatabase() {
		try {
			try {
				utx.begin();
				List<SellerAccount> list = em.createNamedQuery(SellerAccount.FIND_ALL, SellerAccount.class)
						.getResultList();
				list.stream().forEach(s -> em.remove(s));
				utx.commit();
			} catch (Exception e) {
				e.printStackTrace();
				try {
					utx.rollback();
				} catch (IllegalStateException | SecurityException | SystemException e1) {
					e1.printStackTrace();
				}
			}
		} catch (NoResultException e) {
		}

		try {
			try {
				utx.begin();
				List<Review> list = em.createNamedQuery(Review.FIND_ALL, Review.class).getResultList();
				list.stream().forEach(s -> em.remove(s));
				utx.commit();
			} catch (Exception e) {
				e.printStackTrace();
				try {
					utx.rollback();
				} catch (IllegalStateException | SecurityException | SystemException e1) {
					e1.printStackTrace();
				}
			}
		} catch (NoResultException e) {
		}

		try {
			try {
				utx.begin();
				List<Sales> list = em.createNamedQuery(Sales.FIND_ALL, Sales.class).getResultList();
				list.stream().forEach(s -> em.remove(s));
				utx.commit();
			} catch (Exception e) {
				e.printStackTrace();
				try {
					utx.rollback();
				} catch (IllegalStateException | SecurityException | SystemException e1) {
					e1.printStackTrace();
				}
			}
		} catch (NoResultException e) {
		}

		try {
			try {
				utx.begin();
				List<Cart> list = em.createNamedQuery(Cart.FIND_ALL, Cart.class).getResultList();
				list.stream().forEach(s -> em.remove(s));
				utx.commit();
			} catch (Exception e) {
				e.printStackTrace();
				try {
					utx.rollback();
				} catch (IllegalStateException | SecurityException | SystemException e1) {
					e1.printStackTrace();
				}
			}
		} catch (NoResultException e) {
		}

		try {
			try {
				utx.begin();
				List<Item> list = em.createNamedQuery(Item.FIND_ALL, Item.class).getResultList();
				list.stream().forEach(s -> em.remove(s));
				utx.commit();
			} catch (Exception e) {
				e.printStackTrace();
				try {
					utx.rollback();
				} catch (IllegalStateException | SecurityException | SystemException e1) {
					e1.printStackTrace();
				}
			}
		} catch (NoResultException e) {
		}

		try {
			try {
				utx.begin();
				List<PreservedAvatar> list = em.createNamedQuery(PreservedAvatar.FIND_ALL, PreservedAvatar.class)
						.getResultList();
				list.stream().forEach(s -> em.remove(s));
				utx.commit();
			} catch (Exception e) {
				e.printStackTrace();
				try {
					utx.rollback();
				} catch (IllegalStateException | SecurityException | SystemException e1) {
					e1.printStackTrace();
				}
			}
		} catch (NoResultException e) {
		}

		try {
			try {
				utx.begin();
				List<Avatar> list = em.createNamedQuery(Avatar.FIND_ALL, Avatar.class).getResultList();
				list.stream().forEach(s -> em.remove(s));
				utx.commit();
			} catch (Exception e) {
				e.printStackTrace();
				try {
					utx.rollback();
				} catch (IllegalStateException | SecurityException | SystemException e1) {
					e1.printStackTrace();
				}
			}
		} catch (NoResultException e) {
		}
		try {
			try {
				utx.begin();
				List<Bbs> list = em.createNamedQuery(Bbs.FIND_ALL, Bbs.class).getResultList();
				list.stream().forEach(s -> em.remove(s));
				utx.commit();
			} catch (Exception e) {
				e.printStackTrace();
				try {
					utx.rollback();
				} catch (IllegalStateException | SecurityException | SystemException e1) {
					e1.printStackTrace();
				}
			}
		} catch (NoResultException e) {
		}

		try {
			try {
				utx.begin();
				List<UserAccount> list = em.createNamedQuery(UserAccount.FIND_ALL, UserAccount.class).getResultList();
				list.stream().forEach(s -> em.remove(s));
				utx.commit();
			} catch (Exception e) {
				e.printStackTrace();
				try {
					utx.rollback();
				} catch (IllegalStateException | SecurityException | SystemException e1) {
					e1.printStackTrace();
				}
			}
		} catch (NoResultException e) {
		}

		try {
			try {
				utx.begin();
				List<GlocommAccount> list = em.createNamedQuery(GlocommAccount.FIND_ALL, GlocommAccount.class)
						.getResultList();
				list.stream().forEach(s -> em.remove(s));
				utx.commit();
			} catch (Exception e) {
				e.printStackTrace();
				try {
					utx.rollback();
				} catch (IllegalStateException | SecurityException | SystemException e1) {
					e1.printStackTrace();
				}
			}
		} catch (NoResultException e) {
		}
	}

	private void createUserAccount() {

		try {
			utx.begin();
			UserAccount account = new UserAccount();
			account.setGlocommId("user");
			account.setMoney(100000);
			account.setName("user");
			account.setPoint(100);
			account.setRoomNumber(296);
			em.persist(account);

			GlocommAccount ga = new GlocommAccount();
			ga.setId("user");
			ga.setPass("pass");
			em.persist(ga);
			userAccount.add(account);
			utx.commit();
		} catch (Exception e) {
			e.printStackTrace();
			try {
				utx.rollback();
			} catch (IllegalStateException | SecurityException | SystemException e1) {
				e1.printStackTrace();
			}
		}

		for (int i = 0; i < USER_ACCOUNT_NUM; i++) {
			try {
				utx.begin();
				UserAccount account = new UserAccount();
				account.setGlocommId("user" + i);
				account.setMoney(100000);
				account.setName("user" + i);
				account.setPoint(i * 100);
				account.setRoomNumber(100 + i * 30);
				em.persist(account);

				GlocommAccount ga = new GlocommAccount();
				ga.setId("user" + i);
				ga.setPass("pass");
				em.persist(ga);
				utx.commit();
				userAccount.add(account);
			} catch (Exception e) {
				e.printStackTrace();
				try {
					utx.rollback();
				} catch (IllegalStateException | SecurityException | SystemException e1) {
					e1.printStackTrace();
				}
			}
		}
	}

	private void createSellerAccount() {

		try {
			utx.begin();
			SellerAccount account = new SellerAccount();
			account.setId("seller");
			account.setPassword("pass");
			account.setMail("test@hoge.com");
			em.persist(account);
			utx.commit();
		} catch (Exception e) {
			e.printStackTrace();
			try {
				utx.rollback();
			} catch (IllegalStateException | SecurityException | SystemException e1) {
				e1.printStackTrace();
			}
		}
	}

	private void createAvatar() {
		for (int i = 0; i < AVATAR_NUM; i++) {
			try {
				utx.begin();
				Avatar avatar = new Avatar();
				avatar.setName("景品" + i);
				avatar.setPoint((int) (Math.random() * 500));
				avatar.setImagePath("/product/avater-img/" + i + ".JPG");

				em.persist(avatar);
				utx.commit();
				avatarList.add(avatar);
			} catch (Exception e) {
				e.printStackTrace();
				try {
					utx.rollback();
				} catch (IllegalStateException | SecurityException | SystemException e1) {
					e1.printStackTrace();
				}
			}
		}

		for (int i = 0; i < PRESERVED_AVATAR_NUM; i++) {
			try {
				utx.begin();
				PreservedAvatar pa = new PreservedAvatar();
				pa.setAvatar(avatarList.get((int) (Math.random() * AVATAR_NUM)));
				pa.setAccountId("user" + (int) (Math.random() * USER_ACCOUNT_NUM));

				int year = (int) (Math.random() * 16);
				int month = (int) (Math.random() * 12);
				int day = (int) (Math.random() * 20);
				int hour = (int) (Math.random() * 24);
				int min = (int) (Math.random() * 24);
				int sec = (int) (Math.random() * 24);

				DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S");
				String strDate = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", year, month, day, hour,
						min, sec);
				pa.setDate(format.parse(strDate));
				em.persist(pa);
				utx.commit();
			} catch (Exception e) {
				e.printStackTrace();
				try {
					utx.rollback();
				} catch (IllegalStateException | SecurityException | SystemException e1) {
					e1.printStackTrace();
				}
			}
		}
	}

	private void createItem() {
		itemList = new ArrayList<Item>();
		DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S");
		try {
			// 商品1
			utx.begin();
			Item item1 = new Item();
			item1.setName("3色ボールペン　富士通ロゴあり");
			item1.setDesc("富士通ロゴの入った黒3色ボールペンです。岡野さんが愛用しています。新人社員におすすめの商品です");
			item1.setCategory(Category.C);
			item1.setPublicStat(PublicStat.PUBLIC);
			item1.setStock(1000);
			item1.setImagePath("/product/item-img/1.JPG");
			item1.setLastEdit(new Date(2));
			item1.setPublicStat(PublicStat.values()[0]);
			item1.setAverageStar(Math.random() * 5);
			String strDate1 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 4, 1, 12, 0, 0);
			String lastDate1 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 6, 1, 12, 0, 0);
			try {
				item1.setLastEdit(format.parse(strDate1));
				item1.setRegistDate(format.parse(lastDate1));
			} catch (ParseException e) {
				e.printStackTrace();
			}
			em.persist(item1);
			utx.commit();
			itemList.add(item1);

			// 商品2
			utx.begin();
			Item item2 = new Item();
			item2.setName("4色ボールペン クリアカラー");
			item2.setDesc("クリアカラーのボールペンです。嶋田さんの愛用している4色ボールペンです。");
			item2.setCategory(Category.C);
			item2.setPublicStat(PublicStat.PUBLIC);
			item2.setStock(1000);
			item2.setImagePath("/product/item-img/2.JPG");
			item2.setLastEdit(new Date(2));
			item2.setPublicStat(PublicStat.values()[0]);
			item2.setAverageStar(Math.random() * 5);

			String strDate2 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 5, 1, 12, 0, 0);
			String lastDate2 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 6, 2, 12, 0, 0);
			try {
				item2.setLastEdit(format.parse(strDate2));
				item2.setRegistDate(format.parse(lastDate2));
			} catch (ParseException e) {
				e.printStackTrace();
			}
			em.persist(item2);
			utx.commit();
			itemList.add(item2);

			// 商品3
			utx.begin();
			Item item3 = new Item();
			item3.setName("3色ボールペン 消しゴム付き");
			item3.setDesc("消しゴム付きの3色ボールペンです。シャーペン機能も搭載の便利商品");
			item3.setCategory(Category.C);
			item3.setPublicStat(PublicStat.PUBLIC);
			item3.setStock(0);
			item3.setImagePath("/product/item-img/3.JPG");
			item3.setLastEdit(new Date(2));
			item3.setPublicStat(PublicStat.values()[0]);
			;
			item3.setAverageStar(Math.random() * 5);

			String strDate3 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 12, 4, 1, 12, 0, 0);
			String lastDate3 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 6, 3, 12, 0, 0);
			try {
				item3.setLastEdit(format.parse(strDate3));
				item3.setRegistDate(format.parse(lastDate3));
			} catch (ParseException e) {
				e.printStackTrace();
			}
			em.persist(item3);
			utx.commit();
			itemList.add(item3);

			// 商品4
			utx.begin();
			Item item4 = new Item();
			item4.setName("ボールペン ブラック");
			item4.setDesc("高級感ある黒ボールペンです。グリップの重みで文字が書きやすい商品です");
			item4.setCategory(Category.C);
			item4.setPublicStat(PublicStat.PUBLIC);
			item4.setStock(1000);
			item4.setImagePath("/product/item-img/4.JPG");
			item4.setLastEdit(new Date(5));
			item4.setPublicStat(PublicStat.values()[0]);
			item4.setAverageStar(Math.random() * 5);

			String strDate4 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 2, 1, 12, 0, 0);
			String lastDate4 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 6, 4, 13, 0, 0);
			try {
				item4.setLastEdit(format.parse(strDate4));
				item4.setRegistDate(format.parse(lastDate4));
			} catch (ParseException e) {
				e.printStackTrace();
			}
			em.persist(item4);
			utx.commit();
			itemList.add(item4);

			// 商品5
			utx.begin();
			Item item5 = new Item();
			item5.setName("ボールペン　シンプル");
			item5.setDesc("どこにでもある普通のボールペンです。シンプルな構造なところが素晴らしい。");
			item5.setCategory(Category.C);
			item5.setPublicStat(PublicStat.PUBLIC);
			item5.setStock(25000);
			item5.setImagePath("/product/item-img/5.JPG");
			item5.setLastEdit(new Date(1));
			item5.setPublicStat(PublicStat.values()[1]);
			item5.setAverageStar(Math.random() * 5);

			String strDate5 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 14, 5, 1, 12, 0, 0);
			String lastDate5 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 6, 5, 12, 0, 0);
			try {
				item5.setLastEdit(format.parse(strDate5));
				item5.setRegistDate(format.parse(lastDate5));
			} catch (ParseException e) {
				e.printStackTrace();
			}
			em.persist(item5);
			utx.commit();
			itemList.add(item5);

			// 商品6
			utx.begin();
			Item item6 = new Item();
			item6.setName("3色ボールペン　クリアブラック");
			item6.setDesc("クリアブラックのおしゃれな3色ボールペンです。");
			item6.setCategory(Category.C);
			item6.setPublicStat(PublicStat.PUBLIC);
			item6.setStock(1000);
			item6.setImagePath("/product/item-img/6.JPG");
			item6.setLastEdit(new Date(2));
			item6.setAverageStar(Math.random() * 5);
			String strDate6 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 4, 1, 12, 0, 0);
			String lastDate6 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 6, 6, 12, 0, 0);
			try {
				item6.setLastEdit(format.parse(strDate6));
				item6.setRegistDate(format.parse(lastDate6));
			} catch (ParseException e) {
				e.printStackTrace();
			}
			em.persist(item6);
			utx.commit();
			itemList.add(item6);

			// 商品7
			utx.begin();
			Item item7 = new Item();
			item7.setName("ボールペン 黒　シンプル");
			item7.setDesc("管理人さんおすすめ。どこにでもあるシンプルなボールペン。");
			item7.setCategory(Category.C);
			item7.setPublicStat(PublicStat.PRIVATE);
			item7.setStock(20);
			item7.setImagePath("/product/item-img/7.JPG");
			item7.setLastEdit(new Date(2));
			item7.setAverageStar(Math.random() * 5);

			String strDate7 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 5, 1, 12, 0, 0);
			String lastDate7 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 6, 7, 12, 0, 0);
			try {
				item7.setLastEdit(format.parse(strDate7));
				item7.setRegistDate(format.parse(lastDate7));
			} catch (ParseException e) {
				e.printStackTrace();
			}
			em.persist(item7);
			utx.commit();
			itemList.add(item7);

			// 商品8
			utx.begin();
			Item item8 = new Item();
			item8.setName("ホワイトボードマーカー　グリーン");
			item8.setDesc("緑色のホワイトボードマーカーです。グループワークで役に立つこと間違いなし");
			item8.setCategory(Category.C);
			item8.setPublicStat(PublicStat.PUBLIC);
			item8.setStock(20000);
			item8.setImagePath("/product/item-img/8.JPG");
			item8.setLastEdit(new Date(2));
			item8.setAverageStar(Math.random() * 5);
			String strDate8 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 12, 4, 1, 12, 0, 0);
			String lastDate8 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 6, 8, 12, 0, 0);
			try {
				item8.setLastEdit(format.parse(strDate8));
				item8.setRegistDate(format.parse(lastDate8));
			} catch (ParseException e) {
				e.printStackTrace();
			}
			em.persist(item8);
			utx.commit();
			itemList.add(item8);

			// 商品9
			utx.begin();
			Item item9 = new Item();
			item9.setName("ホワイトボードマーカー　レッド");
			item9.setDesc("赤いホワイトボードマーカーです。細いペンなので、細かいところも書けます。グループワークで役に立つこと間違いなし");
			item9.setCategory(Category.C);
			item9.setPublicStat(PublicStat.PUBLIC);
			item9.setStock(1000);
			item9.setImagePath("/product/item-img/9.JPG");
			item9.setLastEdit(new Date(5));
			item9.setAverageStar(Math.random() * 5);
			String strDate9 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 2, 1, 12, 0, 0);
			String lastDate9 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 6, 9, 13, 0, 0);
			try {
				item9.setLastEdit(format.parse(strDate9));
				item9.setRegistDate(format.parse(lastDate9));
			} catch (ParseException e) {
				e.printStackTrace();
			}
			em.persist(item9);
			utx.commit();
			itemList.add(item9);

			// 商品10
			utx.begin();
			Item item10 = new Item();
			item10.setName("筆箱　しま模様");
			item10.setDesc("しましまでおしゃれなふでばこです。コンパクトで場所をとらないところもポイント。");
			item10.setCategory(Category.C);
			item10.setPublicStat(PublicStat.PUBLIC);
			item10.setStock(25000);
			item10.setImagePath("/product/item-img/10.JPG");
			item10.setLastEdit(new Date(1));
			item10.setAverageStar(Math.random() * 5);
			String strDate10 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 14, 5, 1, 12, 0, 0);
			String lastDate10 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 6, 10, 12, 0, 0);
			try {
				item10.setLastEdit(format.parse(strDate10));
				item10.setRegistDate(format.parse(lastDate10));
			} catch (ParseException e) {
				e.printStackTrace();
			}
			em.persist(item10);
			utx.commit();
			itemList.add(item10);

			// 商品11
			utx.begin();
			Item item11 = new Item();
			item11.setName("筆箱　レッド");
			item11.setDesc("赤色の高級筆箱です。人気商品のため品薄不可避です。");
			item11.setCategory(Category.B);
			item11.setPublicStat(PublicStat.PUBLIC);
			item11.setStock(5);
			item11.setImagePath("/product/item-img/11.JPG");
			item11.setLastEdit(new Date(2));

			item11.setAverageStar(Math.random() * 5);
			String strDate11 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 4, 1, 12, 0, 0);
			String lastDate11 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 7, 1, 12, 0, 0);
			try {
				item11.setLastEdit(format.parse(strDate11));
				item11.setRegistDate(format.parse(lastDate11));
			} catch (ParseException e) {
				e.printStackTrace();
			}
			em.persist(item11);
			utx.commit();
			itemList.add(item11);

			// 商品12
			utx.begin();
			Item item12 = new Item();
			item12.setName("筆箱 網模様");
			item12.setDesc("嶋田さんが中学2年の時からずっと使っている筆箱です。なかなかこわれません。");
			item12.setCategory(Category.C);
			item12.setPublicStat(PublicStat.PUBLIC);
			item12.setStock(1000);
			item12.setImagePath("/product/item-img/12.JPG");
			item12.setLastEdit(new Date(2));
			item12.setPublicStat(PublicStat.values()[0]);
			item12.setAverageStar(Math.random() * 5);

			String strDate12 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 5, 1, 12, 0, 0);
			String lastDate12 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 7, 2, 12, 0, 0);
			try {
				item12.setLastEdit(format.parse(strDate12));
				item12.setRegistDate(format.parse(lastDate12));
			} catch (ParseException e) {
				e.printStackTrace();
			}
			em.persist(item12);
			utx.commit();
			itemList.add(item12);

			// 商品13
			utx.begin();
			Item item13 = new Item();
			item13.setName("筆箱　四角形");
			item13.setDesc("眼鏡ケースにも代用できる筆箱です。汎用性が高くおすすめ");
			item13.setCategory(Category.C);
			item13.setPublicStat(PublicStat.PUBLIC);
			item13.setStock(0);
			item13.setImagePath("/product/item-img/13.JPG");
			item13.setLastEdit(new Date(2));
			item13.setAverageStar(Math.random() * 5);
			String strDate13 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 12, 4, 1, 12, 0, 0);
			String lastDate13 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 7, 3, 12, 0, 0);
			try {
				item13.setLastEdit(format.parse(strDate13));
				item13.setRegistDate(format.parse(lastDate13));
			} catch (ParseException e) {
				e.printStackTrace();
			}
			em.persist(item13);
			utx.commit();
			itemList.add(item13);

			// 商品14
			utx.begin();
			Item item14 = new Item();
			item14.setName("筆箱　オレンジ");
			item14.setDesc("オレンジの筆箱です");
			item14.setCategory(Category.C);
			item14.setPublicStat(PublicStat.PUBLIC);
			item14.setStock(1000);
			item14.setImagePath("/product/item-img/14.JPG");
			item14.setLastEdit(new Date(5));
			item14.setPublicStat(PublicStat.values()[0]);
			item14.setAverageStar(Math.random() * 5);
			String strDate14 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 2, 1, 12, 0, 0);
			String lastDate14 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 6, 4, 13, 0, 0);
			try {
				item14.setLastEdit(format.parse(strDate14));
				item14.setRegistDate(format.parse(lastDate14));
			} catch (ParseException e) {
				e.printStackTrace();
			}
			em.persist(item14);
			utx.commit();
			itemList.add(item14);

			// 商品15
			utx.begin();
			Item item15 = new Item();
			item15.setName("手帳　ブラック　ボールペン付き");
			item15.setDesc("黒の手帳です。メモを取るためにの必須ツール。ボールペンもついています。");
			item15.setCategory(Category.C);
			item15.setPublicStat(PublicStat.PUBLIC);
			item15.setStock(100);
			item15.setImagePath("/product/item-img/15.JPG");
			item15.setLastEdit(new Date(1));
			item15.setPublicStat(PublicStat.values()[1]);
			item15.setAverageStar(Math.random() * 5);
			String strDate15 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 14, 5, 1, 12, 0, 0);
			String lastDate15 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 6, 15, 12, 0, 0);
			try {
				item15.setLastEdit(format.parse(strDate15));
				item15.setRegistDate(format.parse(lastDate15));
			} catch (ParseException e) {
				e.printStackTrace();
			}
			em.persist(item15);
			utx.commit();
			itemList.add(item15);

			// 商品16
			utx.begin();
			Item item16 = new Item();
			item16.setName("手帳　小型");
			item16.setDesc("バックに入れやすい手帳です");
			item16.setCategory(Category.C);
			item16.setPublicStat(PublicStat.PRIVATE);
			item16.setStock(50000);
			item16.setImagePath("/product/item-img/16.JPG");
			item16.setLastEdit(new Date(2));
			item16.setAverageStar(Math.random() * 5);
			String strDate16 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 4, 1, 12, 0, 0);
			String lastDate16 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 6, 16, 12, 0, 0);
			try {
				item16.setLastEdit(format.parse(strDate16));
				item16.setRegistDate(format.parse(lastDate16));
			} catch (ParseException e) {
				e.printStackTrace();
			}
			em.persist(item16);
			utx.commit();
			itemList.add(item16);

			// 商品17
			utx.begin();
			Item item17 = new Item();
			item17.setName("定規　30cm");
			item17.setDesc("メモリが見やすい定規です");
			item17.setCategory(Category.C);
			item17.setPublicStat(PublicStat.PUBLIC);
			item17.setStock(0);
			item17.setImagePath("/product/item-img/17.JPG");
			item17.setLastEdit(new Date(2));
			item17.setAverageStar(Math.random() * 5);

			String strDate17 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 5, 1, 12, 0, 0);
			String lastDate17 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 6, 17, 12, 0, 0);
			try {
				item17.setLastEdit(format.parse(strDate17));
				item17.setRegistDate(format.parse(lastDate17));
			} catch (ParseException e) {
				e.printStackTrace();
			}
			em.persist(item17);
			utx.commit();
			itemList.add(item17);

			// 商品18
			utx.begin();
			Item item18 = new Item();
			item18.setName("iphone6　ホワイト");
			item18.setDesc("iphone6です。駿河寮にも一応電波は届きます");
			item18.setCategory(Category.A);
			item18.setPublicStat(PublicStat.PUBLIC);
			item18.setStock(2);
			item18.setImagePath("/product/item-img/18.JPG");
			item18.setLastEdit(new Date(2));
			item18.setAverageStar(Math.random() * 5);
			String strDate18 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 12, 4, 1, 12, 0, 0);
			String lastDate18 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 6, 18, 12, 0, 0);
			try {
				item18.setLastEdit(format.parse(strDate18));
				item18.setRegistDate(format.parse(lastDate18));
			} catch (ParseException e) {
				e.printStackTrace();
			}
			em.persist(item18);
			utx.commit();
			itemList.add(item18);

			// 商品19
			utx.begin();
			Item item19 = new Item();
			item19.setName("iphone6s ローズゴールド");
			item19.setDesc("最新型iphone6sです。小型化されています");
			item19.setCategory(Category.A);
			item19.setPublicStat(PublicStat.PUBLIC);
			item19.setStock(1);
			item19.setImagePath("/product/item-img/19.JPG");
			item19.setLastEdit(new Date(5));
			item19.setAverageStar(Math.random() * 5);
			String strDate19 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 2, 19, 12, 0, 0);
			String lastDate19 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 6, 19, 13, 0, 0);
			try {
				item19.setLastEdit(format.parse(strDate19));
				item19.setRegistDate(format.parse(lastDate19));
			} catch (ParseException e) {
				e.printStackTrace();
			}
			em.persist(item19);
			utx.commit();
			itemList.add(item19);

			// 商品20
			utx.begin();
			Item item20 = new Item();
			item20.setName("テープ");
			item20.setDesc("手でちぎれる便利なテープです。");
			item20.setCategory(Category.C);
			item20.setPublicStat(PublicStat.PUBLIC);
			item20.setStock(10000);
			item20.setImagePath("/product/item-img/20.JPG");
			item20.setLastEdit(new Date(1));
			item20.setAverageStar(Math.random() * 5);
			String strDate20 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 14, 5, 12, 12, 0, 0);
			String lastDate20 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 6, 20, 12, 0, 0);
			try {
				item20.setLastEdit(format.parse(strDate20));
				item20.setRegistDate(format.parse(lastDate20));
			} catch (ParseException e) {
				e.printStackTrace();
			}
			em.persist(item20);
			utx.commit();
			itemList.add(item20);

			// 商品21
			utx.begin();
			Item item21 = new Item();
			item21.setName("掛け時計　大");
			item21.setDesc("部屋に時計が備え付けられていない駿河寮生に必見のおすすめ商品。目覚まし機能もついているので、遅刻対策にもピッタリ");
			item21.setCategory(Category.B);
			item21.setPublicStat(PublicStat.PUBLIC);
			item21.setStock(5);
			item21.setImagePath("/product/item-img/21.JPG");
			item21.setLastEdit(new Date(2));

			item21.setAverageStar(Math.random() * 5);
			String strDate21 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 4, 21, 12, 0, 0);
			String lastDate21 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 6, 21, 12, 0, 0);
			try {
				item21.setLastEdit(format.parse(strDate21));
				item21.setRegistDate(format.parse(lastDate21));
			} catch (ParseException e) {
				e.printStackTrace();
			}
			em.persist(item21);
			utx.commit();
			itemList.add(item21);

			// 商品22
			utx.begin();
			Item item22 = new Item();
			item22.setName("財布　レッド");
			item22.setDesc("おしゃれな駿河寮生必見。赤い財布です。");
			item22.setCategory(Category.B);
			item22.setPublicStat(PublicStat.PRIVATE);
			item22.setStock(1000);
			item22.setImagePath("/product/item-img/22.JPG");
			item22.setLastEdit(new Date(2));
			item22.setPublicStat(PublicStat.values()[0]);
			item22.setAverageStar(Math.random() * 5);

			String strDate22 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 5, 1, 12, 0, 0);
			String lastDate22 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 7, 2, 12, 0, 0);
			try {
				item22.setLastEdit(format.parse(strDate22));
				item22.setRegistDate(format.parse(lastDate22));
			} catch (ParseException e) {
				e.printStackTrace();
			}
			em.persist(item22);
			utx.commit();
			itemList.add(item22);

			// 商品23
			utx.begin();
			Item item23 = new Item();
			item23.setName("財布　ブラウン");
			item23.setDesc("新社会人注目。ポケットがたくさんあるので、カードをたくさん入れられる万能品です。");
			item23.setCategory(Category.B);
			item23.setPublicStat(PublicStat.PUBLIC);
			item23.setStock(0);
			item23.setImagePath("/product/item-img/23.JPG");
			item23.setLastEdit(new Date(2));
			item23.setAverageStar(Math.random() * 5);
			String strDate23 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 12, 4, 1, 12, 0, 0);
			String lastDate23 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 7, 3, 12, 0, 0);
			try {
				item23.setLastEdit(format.parse(strDate23));
				item23.setRegistDate(format.parse(lastDate23));
			} catch (ParseException e) {
				e.printStackTrace();
			}
			em.persist(item23);
			utx.commit();
			itemList.add(item23);

			// 商品24
			utx.begin();
			Item item24 = new Item();
			item24.setName("水筒　シルバー");
			item24.setDesc("節約中の、駿河寮生必見。水筒を使って節約しましょう。");
			item24.setCategory(Category.B);
			item24.setPublicStat(PublicStat.PUBLIC);
			item24.setStock(1000);
			item24.setImagePath("/product/item-img/24.JPG");
			item24.setLastEdit(new Date(5));
			item24.setPublicStat(PublicStat.values()[0]);
			item24.setAverageStar(Math.random() * 5);
			String strDate24 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 2, 1, 12, 0, 0);
			String lastDate24 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 6, 4, 13, 0, 0);
			try {
				item24.setLastEdit(format.parse(strDate24));
				item24.setRegistDate(format.parse(lastDate24));
			} catch (ParseException e) {
				e.printStackTrace();
			}
			em.persist(item24);
			utx.commit();
			itemList.add(item24);

			// 商品25
			utx.begin();
			Item item25 = new Item();
			item25.setName("セキュリティワイヤー　PC用");
			item25.setDesc("金曜日はつけなくても大丈夫です。");
			item25.setCategory(Category.B);
			item25.setPublicStat(PublicStat.PUBLIC);
			item25.setStock(999);
			item25.setImagePath("/product/item-img/25.JPG");
			item25.setLastEdit(new Date(1));
			item25.setPublicStat(PublicStat.values()[1]);
			item25.setAverageStar(Math.random() * 5);
			String strDate25 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 14, 5, 1, 12, 0, 0);
			String lastDate25 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 6, 15, 12, 0, 0);
			try {
				item25.setLastEdit(format.parse(strDate25));
				item25.setRegistDate(format.parse(lastDate25));
			} catch (ParseException e) {
				e.printStackTrace();
			}
			em.persist(item25);
			utx.commit();
			itemList.add(item25);

			// 商品26
			utx.begin();
			Item item26 = new Item();
			item26.setName("腕時計　シルバー");
			item26.setDesc("画面がホワイトな腕時計。シンプルなデザインなので会社に付けていっても大丈夫な商品です。駿河寮生必見のおすすめ商品");
			item26.setCategory(Category.A);
			item26.setPublicStat(PublicStat.PUBLIC);
			item26.setStock(20);
			item26.setImagePath("/product/item-img/26.JPG");
			item26.setLastEdit(new Date(2));
			item26.setAverageStar(Math.random() * 5);
			String strDate26 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 4, 1, 12, 0, 0);
			String lastDate26 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 6, 16, 12, 0, 0);
			try {
				item26.setLastEdit(format.parse(strDate26));
				item26.setRegistDate(format.parse(lastDate26));
			} catch (ParseException e) {
				e.printStackTrace();
			}
			em.persist(item26);
			utx.commit();
			itemList.add(item26);

			// 商品27
			utx.begin();
			Item item27 = new Item();
			item27.setName("腕時計　シルバー");
			item27.setDesc("画面がブラックな腕時計。ソーラー発電なので、電池がきれても下界にいかなくても大丈夫です");
			item27.setCategory(Category.A);
			item27.setPublicStat(PublicStat.PUBLIC);
			item27.setStock(0);
			item27.setImagePath("/product/item-img/27.JPG");
			item27.setLastEdit(new Date(2));
			item27.setAverageStar(Math.random() * 5);

			String strDate27 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 5, 1, 12, 0, 0);
			String lastDate27 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 6, 17, 12, 0, 0);
			try {
				item27.setLastEdit(format.parse(strDate27));
				item27.setRegistDate(format.parse(lastDate27));
			} catch (ParseException e) {
				e.printStackTrace();
			}
			em.persist(item27);
			utx.commit();
			itemList.add(item27);

			// 商品28
			utx.begin();
			Item item28 = new Item();
			item28.setName("腕時計 ブラック");
			item28.setDesc("おしゃれなデザインなので、休みの日に着けるのに最適。");
			item28.setCategory(Category.A);
			item28.setPublicStat(PublicStat.PUBLIC);
			item28.setStock(2);
			item28.setImagePath("/product/item-img/28.JPG");
			item28.setLastEdit(new Date(2));
			item28.setAverageStar(Math.random() * 5);
			String strDate28 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 12, 4, 1, 12, 0, 0);
			String lastDate28 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 6, 18, 12, 0, 0);
			try {
				item28.setLastEdit(format.parse(strDate28));
				item28.setRegistDate(format.parse(lastDate28));
			} catch (ParseException e) {
				e.printStackTrace();
			}
			em.persist(item28);
			utx.commit();
			itemList.add(item28);

			// 商品29
			utx.begin();
			Item item29 = new Item();
			item29.setName("腕時計　ブラック　液晶付き");
			item29.setDesc("黒の腕時計です。正面の液晶に日付と曜日が表示されるので便利");
			item29.setCategory(Category.A);
			item29.setPublicStat(PublicStat.PUBLIC);
			item29.setStock(1);
			item29.setImagePath("/product/item-img/29.JPG");
			item29.setLastEdit(new Date(5));
			item29.setAverageStar(Math.random() * 5);
			String strDate29 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 2, 19, 12, 0, 0);
			String lastDate29 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 6, 19, 13, 0, 0);
			try {
				item29.setLastEdit(format.parse(strDate29));
				item29.setRegistDate(format.parse(lastDate29));
			} catch (ParseException e) {
				e.printStackTrace();
			}
			em.persist(item29);
			utx.commit();
			itemList.add(item29);

			// 商品30
			utx.begin();
			Item item30 = new Item();
			item30.setName("ぞうさん　伊豆土産");
			item30.setDesc("伊豆のお土産です。おまんじゅうです。");
			item30.setCategory(Category.C);
			item30.setPublicStat(PublicStat.PUBLIC);
			item30.setStock(9000);
			item30.setImagePath("/product/item-img/30.JPG");
			item30.setLastEdit(new Date(1));
			item30.setAverageStar(Math.random() * 5);
			String strDate30 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 14, 5, 12, 12, 0, 0);
			String lastDate30 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 6, 30, 12, 0, 0);
			try {
				item30.setLastEdit(format.parse(strDate30));
				item30.setRegistDate(format.parse(lastDate30));
			} catch (ParseException e) {
				e.printStackTrace();
			}
			em.persist(item30);
			utx.commit();
			itemList.add(item30);

			// 商品31
			utx.begin();
			Item item31 = new Item();
			item31.setName("充電器　PC用");
			item31.setDesc("ノートPCの充電器です。PCを持ってる駿河寮生必見です");
			item31.setCategory(Category.B);
			item31.setPublicStat(PublicStat.PUBLIC);
			item31.setStock(5);
			item31.setImagePath("/product/item-img/31.JPG");
			item31.setLastEdit(new Date(2));

			item31.setAverageStar(Math.random() * 5);
			String strDate31 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 4, 21, 12, 0, 0);
			String lastDate31 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 6, 21, 12, 0, 0);
			try {
				item31.setLastEdit(format.parse(strDate31));
				item31.setRegistDate(format.parse(lastDate31));
			} catch (ParseException e) {
				e.printStackTrace();
			}
			em.persist(item31);
			utx.commit();
			itemList.add(item31);

			// 商品32
			utx.begin();
			Item item32 = new Item();
			item32.setName("イス　ブルー");
			item32.setDesc("駿河寮には座椅子しかないので、大活躍間違いなし。");
			item32.setCategory(Category.B);
			item32.setPublicStat(PublicStat.PRIVATE);
			item32.setStock(1000);
			item32.setImagePath("/product/item-img/32.JPG");
			item32.setLastEdit(new Date(2));
			item32.setPublicStat(PublicStat.values()[0]);
			item32.setAverageStar(Math.random() * 5);

			String strDate32 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 5, 1, 12, 0, 0);
			String lastDate32 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 7, 2, 12, 0, 0);
			try {
				item32.setLastEdit(format.parse(strDate32));
				item32.setRegistDate(format.parse(lastDate32));
			} catch (ParseException e) {
				e.printStackTrace();
			}
			em.persist(item32);
			utx.commit();
			itemList.add(item32);

			// 商品33
			utx.begin();
			Item item33 = new Item();
			item33.setName("イス　和風");
			item33.setDesc("駿河寮の和室にあう茶色のデザイン。");
			item33.setCategory(Category.B);
			item33.setPublicStat(PublicStat.PUBLIC);
			item33.setStock(0);
			item33.setImagePath("/product/item-img/33.JPG");
			item33.setLastEdit(new Date(2));
			item33.setAverageStar(Math.random() * 5);
			String strDate33 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 12, 4, 1, 12, 0, 0);
			String lastDate33 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 7, 3, 12, 0, 0);
			try {
				item33.setLastEdit(format.parse(strDate33));
				item33.setRegistDate(format.parse(lastDate33));
			} catch (ParseException e) {
				e.printStackTrace();
			}
			em.persist(item33);
			utx.commit();
			itemList.add(item33);

			// 商品34
			utx.begin();
			Item item34 = new Item();
			item34.setName("イス　パイプ椅子");
			item34.setDesc("使わないときは折りたためて、6畳の和室での使用に便利です。");
			item34.setCategory(Category.B);
			item34.setPublicStat(PublicStat.PUBLIC);
			item34.setStock(1000);
			item34.setImagePath("/product/item-img/34.JPG");
			item34.setLastEdit(new Date(5));
			item34.setPublicStat(PublicStat.values()[0]);
			item34.setAverageStar(Math.random() * 5);
			String strDate34 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 2, 1, 12, 0, 0);
			String lastDate34 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 6, 4, 13, 0, 0);
			try {
				item34.setLastEdit(format.parse(strDate34));
				item34.setRegistDate(format.parse(lastDate34));
			} catch (ParseException e) {
				e.printStackTrace();
			}
			em.persist(item34);
			utx.commit();
			itemList.add(item34);

			// 商品35
			utx.begin();
			Item item35 = new Item();
			item35.setName("クリップ　小型");
			item35.setDesc("小型のクリップです");
			item35.setCategory(Category.C);
			item35.setPublicStat(PublicStat.PUBLIC);
			item35.setStock(9999);
			item35.setImagePath("/product/item-img/35.JPG");
			item35.setLastEdit(new Date(1));
			item35.setPublicStat(PublicStat.values()[1]);
			item35.setAverageStar(Math.random() * 5);
			String strDate35 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 14, 5, 1, 12, 0, 0);
			String lastDate35 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 6, 15, 12, 0, 0);
			try {
				item35.setLastEdit(format.parse(strDate35));
				item35.setRegistDate(format.parse(lastDate35));
			} catch (ParseException e) {
				e.printStackTrace();
			}
			em.persist(item35);
			utx.commit();
			itemList.add(item35);

			// 商品36
			utx.begin();
			Item item36 = new Item();
			item36.setName("机　長机");
			item36.setDesc("寮でイベントをするときに便利です。机と一緒にセットで購入するのがおすすめ");
			item36.setCategory(Category.B);
			item36.setPublicStat(PublicStat.PUBLIC);
			item36.setStock(30);
			item36.setImagePath("/product/item-img/36.JPG");
			item36.setLastEdit(new Date(2));
			item36.setAverageStar(Math.random() * 5);
			String strDate36 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 4, 1, 12, 0, 0);
			String lastDate36 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 6, 16, 12, 0, 0);
			try {
				item36.setLastEdit(format.parse(strDate36));
				item36.setRegistDate(format.parse(lastDate36));
			} catch (ParseException e) {
				e.printStackTrace();
			}
			em.persist(item36);
			utx.commit();
			itemList.add(item36);

			// 商品37
			utx.begin();
			Item item37 = new Item();
			item37.setName("黒板消し　ホワイトボード用");
			item37.setDesc("ホワイトボードに書かれた文字を消すための黒板消し。");
			item37.setCategory(Category.C);
			item37.setPublicStat(PublicStat.PRIVATE);
			item37.setStock(0);
			item37.setImagePath("/product/item-img/37.JPG");
			item37.setLastEdit(new Date(2));
			item37.setAverageStar(Math.random() * 5);

			String strDate37 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 5, 1, 12, 0, 0);
			String lastDate37 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 6, 17, 12, 0, 0);
			try {
				item37.setLastEdit(format.parse(strDate37));
				item37.setRegistDate(format.parse(lastDate37));
			} catch (ParseException e) {
				e.printStackTrace();
			}
			em.persist(item37);
			utx.commit();
			itemList.add(item37);

			// 商品38
			utx.begin();
			Item item38 = new Item();
			item38.setName("眼鏡　ブルー　ブルーライト対応");
			item38.setDesc("一日中PCとにらめっこしている駿河寮生必見。ブルーライト対応の青眼鏡です。");
			item38.setCategory(Category.A);
			item38.setPublicStat(PublicStat.PUBLIC);
			item38.setStock(20);
			item38.setImagePath("/product/item-img/38.JPG");
			item38.setLastEdit(new Date(2));
			item38.setAverageStar(Math.random() * 5);
			String strDate38 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 12, 4, 1, 12, 0, 0);
			String lastDate38 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 6, 18, 12, 0, 0);
			try {
				item38.setLastEdit(format.parse(strDate38));
				item38.setRegistDate(format.parse(lastDate38));
			} catch (ParseException e) {
				e.printStackTrace();
			}
			em.persist(item38);
			utx.commit();
			itemList.add(item38);

			// 商品39
			utx.begin();
			Item item39 = new Item();
			item39.setName("眼鏡　グレー");
			item39.setDesc("特徴がないのが特徴の眼鏡です。シンプルなデザインの好きな駿河寮生必見");
			item39.setCategory(Category.A);
			item39.setPublicStat(PublicStat.PUBLIC);
			item39.setStock(40);
			item39.setImagePath("/product/item-img/39.JPG");
			item39.setLastEdit(new Date(5));
			item39.setAverageStar(Math.random() * 5);
			String strDate39 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 2, 19, 12, 0, 0);
			String lastDate39 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 6, 19, 13, 0, 0);
			try {
				item39.setLastEdit(format.parse(strDate39));
				item39.setRegistDate(format.parse(lastDate39));
			} catch (ParseException e) {
				e.printStackTrace();
			}
			em.persist(item39);
			utx.commit();
			itemList.add(item39);

			// 商品40
			utx.begin();
			Item item40 = new Item();
			item40.setName("眼鏡　青黒ぶち");
			item40.setDesc("フレームのおしゃれな眼鏡です");
			item40.setCategory(Category.A);
			item40.setPublicStat(PublicStat.PUBLIC);
			item40.setStock(50);
			item40.setImagePath("/product/item-img/40.JPG");
			item40.setLastEdit(new Date(1));
			item40.setAverageStar(Math.random() * 5);
			String strDate40 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 14, 5, 12, 12, 0, 0);
			String lastDate40 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 6, 30, 12, 0, 0);
			try {
				item40.setLastEdit(format.parse(strDate40));
				item40.setRegistDate(format.parse(lastDate40));
			} catch (ParseException e) {
				e.printStackTrace();
			}
			em.persist(item40);
			utx.commit();
			itemList.add(item40);

			// 商品41
			utx.begin();
			Item item41 = new Item();
			item41.setName("ハンカチ　グリーン");
			item41.setDesc("緑のハンカチです。シンプルなデザインが特徴的");
			item41.setCategory(Category.C);
			item41.setPublicStat(PublicStat.PUBLIC);
			item41.setStock(5);
			item41.setImagePath("/product/item-img/41.JPG");
			item41.setLastEdit(new Date(2));

			item41.setAverageStar(Math.random() * 5);
			String strDate41 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 4, 21, 12, 0, 0);
			String lastDate41 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 6, 21, 12, 0, 0);
			try {
				item41.setLastEdit(format.parse(strDate41));
				item41.setRegistDate(format.parse(lastDate41));
			} catch (ParseException e) {
				e.printStackTrace();
			}
			em.persist(item41);
			utx.commit();
			itemList.add(item41);

			// 商品42
			utx.begin();
			Item item42 = new Item();
			item42.setName("ハンカチ　ブルー");
			item42.setDesc("青のハンカチです。ハンカチは常に携帯しましょう");
			item42.setCategory(Category.B);
			item42.setPublicStat(PublicStat.PRIVATE);
			item42.setStock(100);
			item42.setImagePath("/product/item-img/42.JPG");
			item42.setLastEdit(new Date(2));
			item42.setPublicStat(PublicStat.values()[0]);
			item42.setAverageStar(Math.random() * 5);

			String strDate42 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 5, 1, 12, 0, 0);
			String lastDate42 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 7, 2, 12, 0, 0);
			try {
				item42.setLastEdit(format.parse(strDate42));
				item42.setRegistDate(format.parse(lastDate42));
			} catch (ParseException e) {
				e.printStackTrace();
			}
			em.persist(item42);
			utx.commit();
			itemList.add(item42);

			// 商品43
			utx.begin();
			Item item43 = new Item();
			item43.setName("ハンガー 黒A");
			item43.setDesc("一緒にズボンもかけられるタイプのハンガーです");
			item43.setCategory(Category.C);
			item43.setPublicStat(PublicStat.PUBLIC);
			item43.setStock(0);
			item43.setImagePath("/product/item-img/43.JPG");
			item43.setLastEdit(new Date(2));
			item43.setAverageStar(Math.random() * 5);
			String strDate43 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 12, 4, 1, 12, 0, 0);
			String lastDate43 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 7, 3, 12, 0, 0);
			try {
				item33.setLastEdit(format.parse(strDate43));
				item33.setRegistDate(format.parse(lastDate43));
			} catch (ParseException e) {
				e.printStackTrace();
			}
			em.persist(item43);
			utx.commit();
			itemList.add(item43);

			// 商品44
			utx.begin();
			Item item44 = new Item();
			item44.setName("ハンガー　黒B");
			item44.setDesc("振り回しやすいハンガーです。虫を叩けます。");
			item44.setCategory(Category.C);
			item44.setPublicStat(PublicStat.PUBLIC);
			item44.setStock(49999);
			item44.setImagePath("/product/item-img/44.JPG");
			item44.setLastEdit(new Date(5));
			item44.setPublicStat(PublicStat.values()[0]);
			item44.setAverageStar(Math.random() * 5);
			String strDate44 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 2, 1, 12, 0, 0);
			String lastDate44 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 6, 4, 13, 0, 0);
			try {
				item44.setLastEdit(format.parse(strDate44));
				item44.setRegistDate(format.parse(lastDate44));
			} catch (ParseException e) {
				e.printStackTrace();
			}
			em.persist(item44);
			utx.commit();
			itemList.add(item44);

			// 商品45
			utx.begin();
			Item item45 = new Item();
			item45.setName("LANケーブル 3m");
			item45.setDesc("ネット環境のある駿河寮生必見。3mのLANケーブルです。部屋の端から端まで届きます");
			item45.setCategory(Category.B);
			item45.setPublicStat(PublicStat.PUBLIC);
			item45.setStock(9999);
			item45.setImagePath("/product/item-img/45.JPG");
			item45.setLastEdit(new Date(1));
			item45.setPublicStat(PublicStat.values()[1]);
			item45.setAverageStar(Math.random() * 5);
			String strDate45 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 14, 5, 1, 12, 0, 0);
			String lastDate45 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 6, 15, 12, 0, 0);
			try {
				item45.setLastEdit(format.parse(strDate45));
				item45.setRegistDate(format.parse(lastDate45));
			} catch (ParseException e) {
				e.printStackTrace();
			}
			em.persist(item45);
			utx.commit();
			itemList.add(item45);

			// 商品46
			utx.begin();
			Item item46 = new Item();
			item46.setName("LANケーブル 1m");
			item46.setDesc("ネット環境のある駿河寮生必見。1mのLANケーブルです。狭い部屋でもOK");
			item46.setCategory(Category.B);
			item46.setPublicStat(PublicStat.PUBLIC);
			item46.setStock(30);
			item46.setImagePath("/product/item-img/46.JPG");
			item46.setLastEdit(new Date(2));
			item46.setAverageStar(Math.random() * 5);
			String strDate46 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 4, 1, 12, 0, 0);
			String lastDate46 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 6, 16, 12, 0, 0);
			try {
				item46.setLastEdit(format.parse(strDate46));
				item46.setRegistDate(format.parse(lastDate46));
			} catch (ParseException e) {
				e.printStackTrace();
			}
			em.persist(item46);
			utx.commit();
			itemList.add(item46);

			// 商品47
			utx.begin();
			Item item47 = new Item();
			item47.setName("磁石　棒状");
			item47.setDesc("部屋のドア前に張り紙を張るときに便利");
			item47.setCategory(Category.C);
			item47.setPublicStat(PublicStat.PRIVATE);
			item47.setStock(0);
			item47.setImagePath("/product/item-img/47.JPG");
			item47.setLastEdit(new Date(2));
			item47.setAverageStar(Math.random() * 5);

			String strDate47 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 5, 1, 12, 0, 0);
			String lastDate47 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 6, 17, 12, 0, 0);
			try {
				item47.setLastEdit(format.parse(strDate47));
				item47.setRegistDate(format.parse(lastDate47));
			} catch (ParseException e) {
				e.printStackTrace();
			}
			em.persist(item47);
			utx.commit();
			itemList.add(item47);

			// 商品48
			utx.begin();
			Item item48 = new Item();
			item48.setName("メモ帳　グリーン");
			item48.setDesc("小型のメモ帳です");
			item48.setCategory(Category.C);
			item48.setPublicStat(PublicStat.PUBLIC);
			item48.setStock(20);
			item48.setImagePath("/product/item-img/48.JPG");
			item48.setLastEdit(new Date(2));
			item48.setAverageStar(Math.random() * 5);
			String strDate48 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 12, 4, 1, 12, 0, 0);
			String lastDate48 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 6, 18, 12, 0, 0);
			try {
				item48.setLastEdit(format.parse(strDate48));
				item48.setRegistDate(format.parse(lastDate48));
			} catch (ParseException e) {
				e.printStackTrace();
			}
			em.persist(item48);
			utx.commit();
			itemList.add(item48);

			// 商品49
			utx.begin();
			Item item49 = new Item();
			item49.setName("メモ帳　ブラック");
			item49.setDesc("デスノートをモチーフにしています");
			item49.setCategory(Category.C);
			item49.setPublicStat(PublicStat.PUBLIC);
			item49.setStock(40);
			item49.setImagePath("/product/item-img/49.JPG");
			item49.setLastEdit(new Date(5));
			item49.setAverageStar(Math.random() * 5);
			String strDate49 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 2, 19, 12, 0, 0);
			String lastDate49 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 6, 19, 13, 0, 0);
			try {
				item49.setLastEdit(format.parse(strDate49));
				item49.setRegistDate(format.parse(lastDate49));
			} catch (ParseException e) {
				e.printStackTrace();
			}
			em.persist(item49);
			utx.commit();
			itemList.add(item49);

			// 商品50
			utx.begin();
			Item item50 = new Item();
			item50.setName("LIFEBOOK 富士通製ノートPC");
			item50.setDesc("布教用にどうぞ");
			item50.setCategory(Category.A);
			item50.setPublicStat(PublicStat.PUBLIC);
			item50.setStock(9000);
			item50.setImagePath("/product/item-img/50.JPG");
			item50.setLastEdit(new Date(1));
			item50.setAverageStar(Math.random() * 5);
			String strDate50 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 14, 5, 12, 12, 0, 0);
			String lastDate50 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 6, 30, 12, 0, 0);
			try {
				item50.setLastEdit(format.parse(strDate50));
				item50.setRegistDate(format.parse(lastDate50));
			} catch (ParseException e) {
				e.printStackTrace();
			}
			em.persist(item50);
			utx.commit();
			itemList.add(item50);

			// 商品51
			utx.begin();
			Item item51 = new Item();
			item51.setName("折り紙　100色");
			item51.setDesc("寮で一人で時間をつぶすのに最適。100色セットの折り紙です");
			item51.setCategory(Category.C);
			item51.setPublicStat(PublicStat.PUBLIC);
			item51.setStock(1000);
			item51.setImagePath("/product/item-img/51.JPG");
			item51.setLastEdit(new Date(1));
			item51.setAverageStar(Math.random() * 5);
			String strDate51 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 14, 5, 12, 12, 0, 0);
			String lastDate51 = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", 16, 6, 30, 12, 0, 0);
			try {
				item51.setLastEdit(format.parse(strDate51));
				item51.setRegistDate(format.parse(lastDate51));
			} catch (ParseException e) {
				e.printStackTrace();
			}

			em.persist(item51);
			utx.commit();
			itemList.add(item51);

		} catch (Exception e) {
			e.printStackTrace();
			try {
				utx.rollback();
			} catch (IllegalStateException | SecurityException | SystemException e1) {
				e1.printStackTrace();
			}
		}
	}

	private void createReview() {
		for (int i = 0; i < REVIEW_NUM; i++) {
			try {
				utx.begin();
				Review review = new Review();
				review.setItemId(itemList.get((int) (Math.random() * itemList.size())).getId());
				review.setAvatar(avatarList.get((int) (Math.random() * avatarList.size())));
				review.setComment((getRandomString(255)));
				review.setAccountId(userAccount.get((int) (Math.random() * userAccount.size())).getGlocommId());
				review.setStar((int) (Math.random() * 5));
				review.setGoodCount((int) (Math.random() * 100));

				int year = (int) (Math.random() * 16);
				int month = (int) (Math.random() * 12);
				int day = (int) (Math.random() * 20);
				int hour = (int) (Math.random() * 24);
				int min = (int) (Math.random() * 24);
				int sec = (int) (Math.random() * 24);

				DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S");
				String strDate = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", year, month, day, hour,
						min, sec);
				try {
					review.setDate(format.parse(strDate));
				} catch (ParseException e) {
					e.printStackTrace();
				}

				em.persist(review);
				utx.commit();
			} catch (Exception e) {
				e.printStackTrace();
				try {
					utx.rollback();
				} catch (IllegalStateException | SecurityException | SystemException e1) {
					e1.printStackTrace();
				}
			}
		}
	}

	private void createSales() {
		List<UserAccount> userAccount = em.createNamedQuery(UserAccount.FIND_ALL, UserAccount.class).getResultList();
		for (int i = 0; i < SALES_NUM; i++) {
			try {
				utx.begin();
				Sales sales = new Sales();
				sales.setItemId(itemList.get((int) (Math.random() * itemList.size())).getId());
				sales.setPrice((int) (Math.random() * 1000) * 100);
				sales.setCount((int) (Math.random() * 100));
				sales.setAccountId(userAccount.get((int) (Math.random() * userAccount.size())).getGlocommId());

				int year = (int) (Math.random() * 16);
				int month = (int) (Math.random() * 12);
				int day = (int) (Math.random() * 20);
				int hour = (int) (Math.random() * 24);
				int min = (int) (Math.random() * 24);
				int sec = (int) (Math.random() * 24);

				DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S");
				String strDate = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", year, month, day, hour,
						min, sec);
				try {
					sales.setDate(format.parse(strDate));
				} catch (ParseException e) {
					e.printStackTrace();
				}

				em.persist(sales);
				utx.commit();
			} catch (Exception e) {
				e.printStackTrace();
				try {
					utx.rollback();
				} catch (IllegalStateException | SecurityException | SystemException e1) {
					e1.printStackTrace();
				}
			}
		}

	}

	private void createCart() {
		List<Item> itemList = em.createNamedQuery(Item.FIND_ALL, Item.class).getResultList();
		for (int i = 0; i < SALES_NUM; i++) {
			try {
				Item item = itemList.get((int) (Math.random() * itemList.size()));
				utx.begin();
				Cart cart = new Cart();
				cart.setItemId(item.getId());
				cart.setCount((int) (Math.random() * 100));
				cart.setAccountId("user" + (int) (Math.random() * USER_ACCOUNT_NUM));

				em.persist(cart);
				utx.commit();
			} catch (Exception e) {
				e.printStackTrace();
				try {
					utx.rollback();
				} catch (IllegalStateException | SecurityException | SystemException e1) {
					e1.printStackTrace();
				}
			}
		}
	}

	/**
	 * ランダムな文字列の取得
	 * 
	 * @param maxLength
	 *            文字列の長さ
	 * @return
	 */
	private String getRandomString(int maxLength) {
		String ret = "";
		int length = (int) (Math.random() * maxLength);
		for (int i = 0; i < length; i++) {
			if (Math.random() > 0.5) {
				ret += (char) ('あ' + Math.random() * ('ん' - 'あ'));
			} else {
				ret += (char) ('亜' + Math.random() * ('唯' - '亜'));
			}
		}
		return ret;
	}

	/**
	 * 
	 */
	public void testData() {
		for (int i = 0; i < 10; i++) {
			getRandomString(255);
		}
	}
}