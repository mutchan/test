package com.fujitsu.soft.rad.devsemi.stub;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import com.fujitsu.soft.rad.devsemi.entity.Item;
import com.fujitsu.soft.rad.devsemi.entity.Review;
import com.fujitsu.soft.rad.devsemi.seller.Category;
import com.fujitsu.soft.rad.devsemi.seller.PublicStat;

/**
 * ItemManagerのスタブ
 * 
 * @author Hiradate, Mutsuki
 *
 */
public class ItemManagerStub {

	List<Item> itemList = new ArrayList<Item>();

	public ItemManagerStub() {
		ArrayList<Item> list = new ArrayList<Item>();
		
		Item item = new Item();
		item.setId(0);
		item.setName("激レア！！");
		item.setDesc("非公開のレア写真です。ボーナスの使い道はこれで決まり！！");
		item.setCategory(Category.B);
		item.setPublicStat(PublicStat.PRIVATE);
		item.setStock(5000);
		item.setLastEdit(new Date(0));
		item.setImagePath("../product/item-img/akazawa_smile.JPG");
		list.add(item);
		
		Item item1 = new Item();
		item1.setId(1);
		item1.setName("三色ボールペン");
		item1.setDesc("あの岡野さんが愛用しているフリクションボールペンです。");
		item1.setCategory(Category.C);
		item1.setPublicStat(PublicStat.PUBLIC);
		item1.setStock(10000);
		item1.setLastEdit(new Date(1));
		item1.setImagePath("../product/item-img/1.JPG");
		list.add(item1);


		
		Item item2 = new Item();
		item2.setId(2);
		item2.setName("4色ボールペン");
		item2.setDesc("島田さんが愛用しているボールペンです。");
		item2.setCategory(Category.C);
		item2.setPublicStat(PublicStat.PUBLIC);
		item2.setStock(10000);
		item2.setLastEdit(new Date(2));
		item2.setImagePath("../product/item-img/2.JPG");
		list.add(item2);

		Item item3 = new Item();
		item3.setId(3);
		item3.setName("3色ボールペン");
		item3.setDesc("シャーペン機能搭載のボールペンです。消しゴムもついてます");
		item3.setCategory(Category.B);
		item3.setPublicStat(PublicStat.PUBLIC);
		item3.setStock(5000);
		item3.setLastEdit(new Date(3));
		item3.setImagePath("../product/item-img/3.JPG");
		list.add(item3);

		Item item4 = new Item();
		item4.setId(4);
		item4.setName("ボールペン");
		item4.setDesc("高級感のある黒ボールペンです。");
		item4.setCategory(Category.C);
		item4.setPublicStat(PublicStat.PUBLIC);
		item4.setStock(5000);
		item4.setLastEdit(new Date(4));
		item4.setImagePath("../product/item-img/4.JPG");
		list.add(item4);
		
		Item item5 = new Item();
		item5.setId(5);
		item5.setName("ボールペン");
		item5.setDesc("某銀行でも採用されてそうなペンなんです。");
		item5.setCategory(Category.C);
		item5.setPublicStat(PublicStat.PUBLIC);
		item5.setStock(5000);
		item5.setLastEdit(new Date(5));
		item5.setImagePath("../product/item-img/5.JPG");
		list.add(item5);
		
		Item item6 = new Item();
		item6.setId(6);
		item6.setName("3色ボールペン");
		item6.setDesc("グリップが素晴らしい使い心地のボールペンです。");
		item6.setCategory(Category.C);
		item6.setPublicStat(PublicStat.PUBLIC);
		item6.setStock(5000);
		item6.setLastEdit(new Date(6));
		item6.setImagePath("../product/item-img/6.JPG");
		list.add(item6);
		
		Item item7 = new Item();
		item7.setId(7);
		item7.setName("ボールペン");
		item7.setDesc("管理人さんおススメのシンプルで使いやすいボールペンです。");
		item7.setCategory(Category.C);
		item7.setPublicStat(PublicStat.PUBLIC);
		item7.setStock(5000);
		item7.setLastEdit(new Date(7));
		item7.setImagePath("../product/item-img/7.JPG");
		list.add(item7);	
		
		Item item8 = new Item();
		item8.setId(8);
		item8.setName("マーカー（緑）");
		item8.setDesc("ホワイトボードにもしっかり描けます。");
		item8.setCategory(Category.C);
		item8.setPublicStat(PublicStat.PUBLIC);
		item8.setStock(9000);
		item8.setLastEdit(new Date(8));
		item8.setImagePath("../product/item-img/8.JPG");
		list.add(item8);
		
		Item item9 = new Item();
		item9.setId(9);
		item9.setName("マーカー（赤）");
		item9.setDesc("ホワイトボードにもしっかり描けます。（その2）");
		item9.setCategory(Category.B);
		item9.setPublicStat(PublicStat.PUBLIC);
		item9.setStock(5000);
		item9.setLastEdit(new Date(9));
		item9.setImagePath("../product/item-img/9.JPG");
		list.add(item9);
		
		Item item10 = new Item();
		item10.setId(10);
		item10.setName("筆箱");
		item10.setDesc("しましまでおしゃれな筆箱です。");
		item10.setCategory(Category.B);
		item10.setPublicStat(PublicStat.PUBLIC);
		item10.setStock(4000);
		item10.setLastEdit(new Date(10));
		item10.setImagePath("../product/item-img/10.JPG");
		list.add(item10);
		
		Item item11 = new Item();
		item11.setId(11);
		item11.setName("筆箱");
		item11.setDesc("コンパクトで赤い筆箱です。");
		item11.setCategory(Category.B);
		item11.setPublicStat(PublicStat.PUBLIC);
		item11.setStock(4000);
		item11.setLastEdit(new Date(11));
		item11.setImagePath("../product/item-img/11.JPG");
		list.add(item11);		
		
		Item item12 = new Item();
		item12.setId(12);
		item12.setName("筆箱");
		item12.setDesc("島田さんが厨二のころから使っている筆箱です。");
		item12.setCategory(Category.B);
		item12.setPublicStat(PublicStat.PUBLIC);
		item12.setStock(7000);
		item12.setLastEdit(new Date(12));
		item12.setImagePath("../product/item-img/12.JPG");
		list.add(item12);
		
		Item item13 = new Item();
		item13.setId(13);
		item13.setName("筆箱");
		item13.setDesc("眼鏡とか入りそうな筆箱です。");
		item13.setCategory(Category.B);
		item13.setPublicStat(PublicStat.PUBLIC);
		item13.setStock(3000);
		item13.setLastEdit(new Date(13));
		item13.setImagePath("../product/item-img/13.JPG");
		list.add(item13);
		
		Item item14 = new Item();
		item14.setId(14);
		item14.setName("筆箱");
		item14.setDesc("収納しやすい筆箱です。");
		item14.setCategory(Category.B);
		item14.setPublicStat(PublicStat.PUBLIC);
		item14.setStock(2000);
		item14.setLastEdit(new Date(14));
		item14.setImagePath("../product/item-img/14.JPG");
		list.add(item14);
		
		Item item15 = new Item();
		item15.setId(15);
		item15.setName("手帳");
		item15.setDesc("高級感あふれ出ている手帳です。今ならボールペンもついてきます。");
		item15.setCategory(Category.B);
		item15.setPublicStat(PublicStat.PUBLIC);
		item15.setStock(7000);
		item15.setLastEdit(new Date(15));
		item15.setImagePath("../product/item-img/15.JPG");
		list.add(item15);
		
		Item item16 = new Item();
		item16.setId(16);
		item16.setName("手帳");
		item16.setDesc("バックに入れやすい大きさです。");
		item16.setCategory(Category.B);
		item16.setPublicStat(PublicStat.PUBLIC);
		item16.setStock(3000);
		item16.setLastEdit(new Date(16));
		item16.setImagePath("../product/item-img/16.JPG");
		list.add(item16);
		
		Item item17 = new Item();
		item17.setId(17);
		item17.setName("30cm定規");
		item17.setDesc("メモリが見やすい定規です");
		item17.setCategory(Category.B);
		item17.setPublicStat(PublicStat.PUBLIC);
		item17.setStock(8000);
		item17.setLastEdit(new Date(0));
		item17.setImagePath("../product/item-img/17.JPG");
		list.add(item17);
		
		Item item18 = new Item();
		item18.setId(18);
		item18.setName("iphone6");
		item18.setDesc("シルバーの色です。");
		item18.setCategory(Category.A);
		item18.setPublicStat(PublicStat.PUBLIC);
		item18.setStock(50);
		item18.setLastEdit(new Date(18));
		item18.setImagePath("../product/item-img/18.JPG");
		list.add(item18);
		
		Item item19 = new Item();
		item19.setId(19);
		item19.setName("iphone6s");
		item19.setDesc("ローズゴールドです。新色です。");
		item19.setCategory(Category.B);
		item19.setPublicStat(PublicStat.PUBLIC);
		item19.setStock(50);
		item19.setLastEdit(new Date(19));
		item19.setImagePath("../product/item-img/19.JPG");
		list.add(item19);
		
		Item item20 = new Item();
		item20.setId(20);
		item20.setName("テープ");
		item20.setDesc("手でちぎれる便利なテープです");
		item20.setCategory(Category.C);
		item20.setPublicStat(PublicStat.PUBLIC);
		item20.setStock(50000);
		item20.setLastEdit(new Date(20));
		item20.setImagePath("../product/item-img/20.JPG");
		list.add(item20);
		
		Item item21 = new Item();
		item21.setId(21);
		item21.setName("掛け時計");
		item21.setDesc("部屋に時計が備え付けられていない寮生におススメです。");
		item21.setCategory(Category.B);
		item21.setPublicStat(PublicStat.PUBLIC);
		item21.setStock(5000);
		item21.setLastEdit(new Date(21));
		item21.setImagePath("../product/item-img/21.JPG");
		list.add(item21);
		
		Item item22 = new Item();
		item22.setId(22);
		item22.setName("お財布");
		item22.setDesc("赤いおしゃれな財布です。");
		item22.setCategory(Category.A);
		item22.setPublicStat(PublicStat.PUBLIC);
		item22.setStock(100);
		item22.setLastEdit(new Date(22));
		item22.setImagePath("../product/item-img/22.JPG");
		list.add(item22);
		
		Item item23 = new Item();
		item23.setId(23);
		item23.setName("お財布");
		item23.setDesc("たくさん収納できるスペースのあるお財布です。");
		item23.setCategory(Category.B);
		item23.setPublicStat(PublicStat.PUBLIC);
		item23.setStock(9000);
		item23.setLastEdit(new Date(23));
		item23.setImagePath("../product/item-img/23.JPG");
		list.add(item23);
		
		Item item24 = new Item();
		item24.setId(24);
		item24.setName("水筒");
		item24.setDesc("これを使って節約しましょう。");
		item24.setCategory(Category.B);
		item24.setPublicStat(PublicStat.PUBLIC);
		item24.setStock(1000);
		item24.setLastEdit(new Date(24));
		item24.setImagePath("../product/item-img/24.JPG");
		list.add(item24);
		
		Item item25 = new Item();
		item25.setId(25);
		item25.setName("セキュリティワイヤー");
		item25.setDesc("金曜日はつけなくて大丈夫です。");
		item25.setCategory(Category.C);
		item25.setPublicStat(PublicStat.PUBLIC);
		item25.setStock(50000);
		item25.setLastEdit(new Date(25));
		item25.setImagePath("../product/item-img/25.JPG");
		list.add(item25);
		
		Item item26 = new Item();
		item26.setId(26);
		item26.setName("腕時計");
		item26.setDesc("シンプルなデザインなので会社でも使えます");
		item26.setCategory(Category.A);
		item26.setPublicStat(PublicStat.PUBLIC);
		item26.setStock(60);
		item26.setLastEdit(new Date(26));
		item26.setImagePath("../product/item-img/26.JPG");
		list.add(item26);
		
		Item item27 = new Item();
		item27.setId(27);
		item27.setName("腕時計");
		item27.setDesc("大人な感じの落ち着いた時計です。");
		item27.setCategory(Category.A);
		item27.setPublicStat(PublicStat.PUBLIC);
		item27.setStock(20);
		item27.setLastEdit(new Date(0));
		item27.setImagePath("../product/item-img/27.JPG");
		list.add(item27);
		
		Item item28 = new Item();
		item28.setId(28);
		item28.setName("腕時計");
		item28.setDesc("休みの日にも最適な時計です。");
		item28.setCategory(Category.A);
		item28.setPublicStat(PublicStat.PUBLIC);
		item28.setStock(30);
		item28.setLastEdit(new Date(28));
		item28.setImagePath("../product/item-img/28.JPG");
		list.add(item28);
		
		Item item29 = new Item();
		item29.setId(29);
		item29.setName("腕時計");
		item29.setDesc("液晶がついていて、曜日と日付が表示されています。");
		item29.setCategory(Category.A);
		item29.setPublicStat(PublicStat.PUBLIC);
		item29.setStock(50);
		item29.setLastEdit(new Date(29));
		item29.setImagePath("../product/item-img/29.JPG");
		list.add(item29);
		
		Item item30 = new Item();
		item30.setId(30);
		item30.setName("象さんの饅頭");
		item30.setDesc("伊豆のお土産にぜひどうぞ。");
		item30.setCategory(Category.C);
		item30.setPublicStat(PublicStat.PUBLIC);
		item30.setStock(50000);
		item30.setLastEdit(new Date(30));
		item30.setImagePath("../product/item-img/30.JPG");
		list.add(item30);
		
		Item item31 = new Item();
		item31.setId(31);
		item31.setName("充電器");
		item31.setDesc("PC用の充電器です。");
		item31.setCategory(Category.C);
		item31.setPublicStat(PublicStat.PUBLIC);
		item31.setStock(50000);
		item31.setLastEdit(new Date(0));
		item31.setImagePath("../product/item-img/31.JPG");
		list.add(item31);
		
		Item item32 = new Item();
		item32.setId(32);
		item32.setName("椅子");
		item32.setDesc("腰に優しい椅子です。");
		item32.setCategory(Category.B);
		item32.setPublicStat(PublicStat.PUBLIC);
		item32.setStock(7000);
		item32.setLastEdit(new Date(0));
		item32.setImagePath("../product/item-img/32.JPG");
		list.add(item32);
		
		Item item33 = new Item();
		item33.setId(33);
		item33.setName("椅子");
		item33.setDesc("和室にも合うデザインです。。");
		item33.setCategory(Category.B);
		item33.setPublicStat(PublicStat.PUBLIC);
		item33.setStock(1000);
		item33.setLastEdit(new Date(0));
		item33.setImagePath("../product/item-img/33.JPG");
		list.add(item33);
		
		Item item34 = new Item();
		item34.setId(34);
		item34.setName("パイプ椅子");
		item34.setDesc("使わないときは折りたためて、狭い部屋での使用に便利です。");
		item34.setCategory(Category.B);
		item34.setPublicStat(PublicStat.PUBLIC);
		item34.setStock(5000);
		item34.setLastEdit(new Date(34));
		item34.setImagePath("../product/item-img/34.JPG");
		list.add(item34);
		
		Item item35 = new Item();
		item35.setId(35);
		item35.setName("クリップ");
		item35.setDesc("見た目よりも大きくいろいろはさめます。");
		item35.setCategory(Category.B);
		item35.setPublicStat(PublicStat.PUBLIC);
		item35.setStock(5000);
		item35.setLastEdit(new Date(35));
		item35.setImagePath("../product/item-img/35.JPG");
		list.add(item35);
		
		Item item36 = new Item();
		item36.setId(36);
		item36.setName("長机");
		item36.setDesc("折りたためる机です。椅子と一緒にどうぞ。");
		item36.setCategory(Category.B);
		item36.setPublicStat(PublicStat.PUBLIC);
		item36.setStock(3000);
		item36.setLastEdit(new Date(0));
		item36.setImagePath("../product/item-img/36.JPG");
		list.add(item36);
		
		Item item37 = new Item();
		item37.setId(37);
		item37.setName("黒板消し");
		item37.setDesc("ホワイトボートと一緒にどうぞ");
		item37.setCategory(Category.B);
		item37.setPublicStat(PublicStat.PUBLIC);
		item37.setStock(5000);
		item37.setLastEdit(new Date(37));
		item37.setImagePath("../product/item-img/37.JPG");
		list.add(item37);
		
		Item item38 = new Item();
		item38.setId(38);
		item38.setName("眼鏡");
		item38.setDesc("ブルーライト対応。引きこもり生活のお供に。");
		item38.setCategory(Category.A);
		item38.setPublicStat(PublicStat.PUBLIC);
		item38.setStock(50);
		item38.setLastEdit(new Date(38));
		item38.setImagePath("../product/item-img/38.JPG");
		list.add(item38);
		
		Item item39 = new Item();
		item39.setId(39);
		item39.setName("眼鏡");
		item39.setDesc("特徴がないのが特徴です。");
		item39.setCategory(Category.A);
		item39.setPublicStat(PublicStat.PUBLIC);
		item39.setStock(50);
		item39.setLastEdit(new Date(0));
		item39.setImagePath("../product/item-img/39.JPG");
		list.add(item39);
		
		Item item40 = new Item();
		item40.setId(40);
		item40.setName("眼鏡");
		item40.setDesc("眼鏡はステータスです。");
		item40.setCategory(Category.A);
		item40.setPublicStat(PublicStat.PUBLIC);
		item40.setStock(50);
		item40.setLastEdit(new Date(40));
		item40.setImagePath("../product/item-img/40.JPG");
		list.add(item40);
		
		Item item41 = new Item();
		item41.setId(41);
		item41.setName("ハンカチ");
		item41.setDesc("チェック柄で無難なハンカチです。");
		item41.setCategory(Category.C);
		item41.setPublicStat(PublicStat.PUBLIC);
		item41.setStock(50000);
		item41.setLastEdit(new Date(41));
		item41.setImagePath("../product/item-img/41.JPG");
		list.add(item41);
		
		Item item42 = new Item();
		item42.setId(42);
		item42.setName("ハンカチ");
		item42.setDesc("卒業祝いにどうぞ");
		item42.setCategory(Category.C);
		item42.setPublicStat(PublicStat.PUBLIC);
		item42.setStock(50000);
		item42.setLastEdit(new Date(40));
		item42.setImagePath("../product/item-img/42.JPG");
		list.add(item42);
		
		Item item43 = new Item();
		item43.setId(43);
		item43.setName("ハンガー");
		item43.setDesc("下にズボンがかけられます。");
		item43.setCategory(Category.C);
		item43.setPublicStat(PublicStat.PUBLIC);
		item43.setStock(51000);
		item43.setLastEdit(new Date(43));
		item43.setImagePath("../product/item-img/43.JPG");
		list.add(item43);
		
		Item item44 = new Item();
		item44.setId(44);
		item44.setName("ハンガー");
		item44.setDesc("振り回しやすいハンガーです。虫を叩けます。");
		item44.setCategory(Category.C);
		item44.setPublicStat(PublicStat.PUBLIC);
		item44.setStock(5000);
		item44.setLastEdit(new Date(44));
		item44.setImagePath("../product/item-img/44.JPG");
		list.add(item44);
		
		Item item45 = new Item();
		item45.setId(45);
		item45.setName("LANケーブル（3m）");
		item45.setDesc("部屋にネット回線を引いたかたはぜひ。");
		item45.setCategory(Category.C);
		item45.setPublicStat(PublicStat.PUBLIC);
		item45.setStock(75000);
		item45.setLastEdit(new Date(45));
		item45.setImagePath("../product/item-img/45.JPG");
		list.add(item45);
		
		Item item46 = new Item();
		item46.setId(46);
		item46.setName("LANケーブル（1m）");
		item46.setDesc("狭いに部屋ではこの長さで十分です。");
		item46.setCategory(Category.C);
		item46.setPublicStat(PublicStat.PUBLIC);
		item46.setStock(35000);
		item46.setLastEdit(new Date(46));
		item46.setImagePath("../product/item-img/46.JPG");
		list.add(item46);
		
		Item item47 = new Item();
		item47.setId(47);
		item47.setName("棒磁石");
		item47.setDesc("ドアの前に張り紙を張ると便利。");
		item47.setCategory(Category.C);
		item47.setPublicStat(PublicStat.PUBLIC);
		item47.setStock(75000);
		item47.setLastEdit(new Date(47));
		item47.setImagePath("../product/item-img/47.JPG");
		list.add(item47);
		
		Item item48 = new Item();
		item48.setId(48);
		item48.setName("メモ帳");
		item48.setDesc("表紙が頑丈なメモ帳です。");
		item48.setCategory(Category.C);
		item48.setPublicStat(PublicStat.PUBLIC);
		item48.setStock(65000);
		item48.setLastEdit(new Date(48));
		item48.setImagePath("../product/item-img/48.JPG");
		list.add(item48);
		
		Item item49 = new Item();
		item49.setId(49);
		item49.setName("メモ帳");
		item49.setDesc("デスノートをモチーフにしたノートです。");
		item49.setCategory(Category.C);
		item49.setPublicStat(PublicStat.PUBLIC);
		item49.setStock(75000);
		item49.setLastEdit(new Date(49));
		item49.setImagePath("../product/item-img/49.JPG");
		list.add(item49);
		
		Item item50 = new Item();
		item50.setId(50);
		item50.setName("LIFEBOOK");
		item50.setDesc("弊社のパソコンです。布教用にどうぞ");
		item50.setCategory(Category.C);
		item50.setPublicStat(PublicStat.PUBLIC);
		item50.setStock(75000);
		item50.setLastEdit(new Date(50));
		item50.setImagePath("../product/item-img/50.JPG");
		list.add(item50);
		
		Item item51 = new Item();
		item51.setId(50);
		item51.setName("折り紙");
		item51.setDesc("下界に降りれないときに折りましょう");
		item51.setCategory(Category.C);
		item51.setPublicStat(PublicStat.PUBLIC);
		item51.setStock(75000);
		item51.setLastEdit(new Date(51));
		item51.setImagePath("../product/item-img/51.JPG");
		list.add(item51); 
		
		Item item200 = new Item();
		item200.setId(200);
		item200.setName("折り紙200");
		item200.setDesc("下界に降りれないときに折りましょう200");
		item200.setCategory(Category.C);
		item200.setPublicStat(PublicStat.PUBLIC);
		item200.setStock(75200);
		item200.setLastEdit(new Date(200));
		item200.setImagePath("../product/item-img/51.JPG");
		list.add(item200); 
		
		itemList.addAll(list);
	}

	/**
	 * 商品リストの取得
	 * 
	 * @return 商品リスト
	 */
	public List<Item> getItemList() {		
		return itemList;
	}

	public void addStock(int id, Integer value) {
		System.out.println(id + " += " + value);
		for (Item item : itemList) {
			if (item.getId() == id) {
				item.setStock(item.getStock() + value);
				break;
			}
		}
	}

	public String getItemName(int id) {
		return getItem(id).getName();
	}
	public Item getItem(int id)
	{
		//とりあえずtestでリストを検索してるけど、実際はDB側でやってください
		/*
		Item retItem = null;
		
		for(Item item : itemList)
		{
			if(item.getId() == id)
			{
				retItem = item;
				break;
			}
		}
		
		
		return retItem;
		*/
		Item elseItem = new Item();
		elseItem.setId(-1);
		elseItem.setName("エラー商品");
		elseItem.setDesc("エラー商品");
		elseItem.setCategory(Category.A);
		elseItem.setPublicStat(PublicStat.PRIVATE);
		elseItem.setStock(10000);
		elseItem.setLastEdit(new Date(0));
		elseItem.setImagePath("../product/item-img/akazawa_smile.JPG");
		return itemList.stream()
				.filter(s -> (s.getId() == id))
				.findFirst().orElse(elseItem);
		
	}
	public Item getRecommendItem(int rank)
	{
		//testプログラム
		return (1 <= rank && rank <= 3) ? itemList.get(rank - 1) : itemList.get(0);
	}
	/**
	 * オススメアイテムリストを表示します。
	 * @return
	 */
	public List<Item> getRecommendItemList()
	{
		//アイテムとレビューとのリレーショナルを全部引っ張ってきて、
		//レビューに対してフィルター、ソートしたものを返す。

		//とりあえず全部
		return itemList;
	}
	
	/**
	 * 
	 * @param rank
	 * @return
	 */
	public Review getRecommendReview(int rank)
	{
		//アイテムに対してレビューのリストを持ってきて処理する。
		//とりあえずstubなのでReviewManagerから呼ぶ
		ReviewManagerStub rm = new ReviewManagerStub();
		
		return rm.getRecommendReview(rank-1);
	}
}
