package com.fujitsu.soft.rad.devsemi.stub;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.fujitsu.soft.rad.devsemi.entity.Item;
import com.fujitsu.soft.rad.devsemi.entity.Sales;
import com.fujitsu.soft.rad.devsemi.seller.Category;
import com.fujitsu.soft.rad.devsemi.seller.PublicStat;

public class SalesManagerStub {
	private boolean alert;
	private List<Sales> salesList;
	private List<Item> itemList;

	public SalesManagerStub() {
		salesList = new ArrayList<Sales>();
		itemList = new ArrayList<Item>();

		ArrayList<Sales> tmp_list = new ArrayList<Sales>();
		
		Sales sales = new Sales();
		sales.setId(0);
		sales.setCount(50);
		sales.setDate(new Date(0));
		sales.setPrice(100);
		sales.setItemId(0);
		tmp_list.add(sales);
		
		Sales sales11 = new Sales();
		sales11.setId(1);
		sales11.setCount(23);
		sales11.setDate(new Date(1));
		sales11.setPrice(100);
		sales11.setItemId(0);
		tmp_list.add(sales11);
		
		
		Sales sales2 = new Sales();
		sales2.setId(2);
		sales2.setCount(20);
		sales2.setDate(new Date(0));
		sales2.setPrice(5000);
		sales2.setItemId(1);
		tmp_list.add(sales2);
		
		Sales sales21 = new Sales();
		sales21.setId(3);
		sales21.setCount(48);
		sales21.setDate(new Date(1));
		sales21.setPrice(100);
		sales21.setItemId(1);
		tmp_list.add(sales21);
		
		Sales sales3 = new Sales();
		sales3.setId(4);
		sales3.setCount(10);
		sales3.setDate(new Date(0));
		sales3.setPrice(10000);
		sales3.setItemId(2);
		tmp_list.add(sales3);
		
		Sales sales4 = new Sales();
		sales4.setId(5);
		sales4.setCount(100);
		sales4.setDate(new Date(0));
		sales4.setPrice(100);
		sales4.setItemId(3);
		tmp_list.add(sales4);
		
		Sales sales5 = new Sales();
		sales5.setId(6);
		sales5.setCount(100);
		sales5.setDate(new Date(0));
		sales5.setPrice(504000);
		sales5.setItemId(5);
		tmp_list.add(sales4);
		
		salesList.addAll(tmp_list);
		

		ArrayList<Item> list = new ArrayList<Item>();
		
		Item item = new Item();
		item.setId(0);
		item.setName("激レア！！");
		item.setDesc("非公開のレア写真です。ボーナスの使い道はこれで決まり！！");
		item.setCategory(Category.B);
		item.setPublicStat(PublicStat.PRIVATE);
		item.setStock(10);
		item.setLastEdit(new Date(0));
		item.setImagePath("../product/item-img/akazawa_smile.JPG");
		list.add(item);
		
		Item item1 = new Item();
		item1.setId(1);
		item1.setName("三色ボールペン");
		item1.setDesc("あの岡野さんが愛用しているフリクションボールペンです。");
		item1.setCategory(Category.C);
		item1.setPublicStat(PublicStat.PUBLIC);
		item1.setStock(10000);
		item1.setLastEdit(new Date(1));
		item1.setImagePath("../product/item-img/1.JPG");
		list.add(item1);


		Item item2 = new Item();
		item2.setId(2);
		item2.setName("4色ボールペン");
		item2.setDesc("島田さんが愛用しているボールペンです。");
		item2.setCategory(Category.C);
		item2.setPublicStat(PublicStat.PUBLIC);
		item2.setStock(100);
		item2.setLastEdit(new Date(2));
		item2.setImagePath("../product/item-img/2.JPG");
		list.add(item2);

		Item item3 = new Item();
		item3.setId(3);
		item3.setName("3色ボールペン");
		item3.setDesc("シャーペン機能搭載のボールペンです。消しゴムもついてます");
		item3.setCategory(Category.B);
		item3.setPublicStat(PublicStat.PUBLIC);
		item3.setStock(3000);
		item3.setLastEdit(new Date(3));
		item3.setImagePath("../product/item-img/3.JPG");
		list.add(item3);

		Item item4 = new Item();
		item4.setId(4);
		item4.setName("ボールペン");
		item4.setDesc("高級感のある黒ボールペンです。");
		item4.setCategory(Category.C);
		item4.setPublicStat(PublicStat.PUBLIC);
		item4.setStock(2000);
		item4.setLastEdit(new Date(4));
		item4.setImagePath("../product/item-img/4.JPG");
		list.add(item4);
		
		Item item5 = new Item();
		item5.setId(5);
		item5.setName("お財布");
		item5.setDesc("赤いおしゃれな財布です。");
		item5.setCategory(Category.A);
		item5.setPublicStat(PublicStat.PUBLIC);
		item5.setStock(10);
		item5.setLastEdit(new Date(22));
		item5.setImagePath("../product/item-img/22.JPG");
		list.add(item5);
		
		itemList.addAll(list);
	}

	public void setAlert(boolean alert) {
		this.alert = alert;
	}

	public boolean getAlert() {
		return this.alert;
	}

	public List<Sales> getSalesList() {
		// TODO Auto-generated method stub
		return this.salesList;
	}
	
	public void setSalesList(List<Sales> salesList){
		this.salesList = salesList;
	}
	
	public List<Item> getItemList(){
		return this.itemList;
	}
	
	public void setItemList(List<Item> itemList){
		this.itemList = itemList;
	}
}
