package com.fujitsu.soft.rad.devsemi.stub;

import java.util.ArrayList;
import java.util.List;

import com.fujitsu.soft.rad.devsemi.entity.Cart;

/**
 * CartManagerのスタブ
 * 
 * @author Hiradate, Mutsuki
 *
 */
public class CartManagerStub {
	List<Cart> cartList;
	ItemManagerStub im;

	/**
	 * 
	 */
	public CartManagerStub() {
		im = new ItemManagerStub();
		cartList = new ArrayList<Cart>();

		Cart cart0 = new Cart();
		cart0.setId(0);
		cart0.setAccountId("user1");
		cart0.setItemId(8);
		cart0.setCount(1);
		cartList.add(cart0);
		
		Cart cart2 = new Cart();
		cart2.setId(200);
		cart2.setAccountId("user1");
		cart2.setItemId(12);
		cart2.setCount(10);
		cartList.add(cart2);

		Cart cart1 = new Cart();
		cart1.setId(100);
		cart1.setAccountId("user2");
		cart1.setItemId(1);
		cart1.setCount(200);
		cartList.add(cart1);

		Cart cart = new Cart();
		cart.setId(300);
		cart.setAccountId("user2");
		cart.setItemId(2);
		cart.setCount(20);
		cartList.add(cart);
	}

	/**
	 * 
	 * @param id
	 * @return
	 */
	public List<Cart> getCartList(String id) {
		List<Cart> idCartList = new ArrayList<Cart>();
		for (Cart cart : cartList) {
			if (cart.getAccountId().equals(id)) {
				idCartList.add(cart);
			}
		}
		return idCartList;
	}

	/**
	 * 
	 * @param cartId
	 * @param value
	 */
	public void setOrderCount(int cartId, int value) {
		for (Cart cart : cartList) {
			cart.setCount(value);
		}
	}

	/**
	 * 
	 * @param accountId
	 * @param itemId
	 * @param count
	 */
	public void addCartItem(String accountId, int itemId, int count) {
		Cart cart = new Cart();
		cart.setId(100);
		cart.setAccountId(accountId);
		cart.setItemId(itemId);
		cart.setCount(count);
		cartList.add(cart);
	}

	/**
	 * 
	 * @param cartId
	 */
	public void removeCartItem(int cartId) {
		System.out.print("SIZE:" + cartList.size());
		Cart removeCart = null;
		for (Cart cart : cartList) {
			if (cart.getId() == cartId) {
				removeCart = cart;
			}
		}
		cartList.remove(removeCart);
		System.out.println("->" + cartList.size());
	}
}
