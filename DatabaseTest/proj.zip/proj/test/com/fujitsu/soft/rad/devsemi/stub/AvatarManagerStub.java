package com.fujitsu.soft.rad.devsemi.stub;

import java.text.DateFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import com.fujitsu.soft.rad.devsemi.entity.Avatar;
import com.fujitsu.soft.rad.devsemi.entity.PreservedAvatar;;

/**
 * AvatarManagerのスタブ
 * 
 * @author Hiradate, Mutsuki
 *
 */
public class AvatarManagerStub {
	/**
	 * すべてのアバター情報を取得
	 * 
	 * @return
	 */
	public List<Avatar> getAvatarList() {
		List<Avatar> avatarList = new ArrayList<Avatar>();

		Avatar avatar0 = new Avatar();
		avatar0.setId(0);
		avatar0.setImagePath("/test.png");
		avatar0.setName("景品1");
		avatar0.setPoint(10);
		avatarList.add(avatar0);

		Avatar avatar1 = new Avatar();
		avatar1.setId(1);
		avatar1.setImagePath("/test.png");
		avatar1.setName("景品2");
		avatar1.setPoint(100);
		avatarList.add(avatar1);

		Avatar avatar2 = new Avatar();
		avatar2.setId(2);
		avatar2.setImagePath("/test.png");
		avatar2.setName("景品3");
		avatar2.setPoint(20);
		avatarList.add(avatar2);

		Avatar avatar3 = new Avatar();
		avatar3.setId(3);
		avatar3.setImagePath("/test.png");
		avatar3.setName("景品4");
		avatar3.setPoint(40);
		avatarList.add(avatar3);

		Avatar avatar4 = new Avatar();
		avatar4.setId(4);
		avatar4.setImagePath("/test.png");
		avatar4.setName("景品5");
		avatar4.setPoint(200);
		avatarList.add(avatar4);

		Avatar avatar5 = new Avatar();
		avatar5.setId(5);
		avatar5.setImagePath("/test.png");
		avatar5.setName("景品6");
		avatar5.setPoint(40);
		avatarList.add(avatar5);

		Avatar avatar6 = new Avatar();
		avatar6.setId(6);
		avatar6.setImagePath("/test.png");
		avatar6.setName("景品7");
		avatar6.setPoint(80);
		avatarList.add(avatar6);

		return avatarList;
	}

	/**
	 * すべてのアバター画像のパスを取得
	 * 
	 * @return
	 */
	public List<String> getImagePathList() {
		List<String> pathList = new ArrayList<String>();
		pathList.add("avatar/test1.png");
		pathList.add("avatar/test2.png");
		pathList.add("avatar/test3.png");
		pathList.add("avatar/test4.png");

		return pathList;
	}

	/**
	 * アバターIDから画像パスを取得
	 * 
	 * @param avatarId
	 * @return
	 */
	public String getImagePathFromId(int avatarId) {

		return getImagePathList().get(avatarId);
	}

	/**
	 * 
	 * @param glocommId
	 *            グロコミID
	 * @return 交換履歴
	 * @throws ParseException
	 */
	public List<PreservedAvatar> getAvatarExchangeList(String glocommId) throws ParseException {
		List<PreservedAvatar> exchangeList = new ArrayList<PreservedAvatar>();

		switch (glocommId) {
		case "user1":
			PreservedAvatar preserved0 = new PreservedAvatar();
			Avatar avatar0 = new Avatar();
			avatar0.setId(0);
			avatar0.setImagePath("/test.png");
			avatar0.setName("景品1");
			avatar0.setPoint(10);
			preserved0.setDate(DateFormat.getDateInstance().parse("2000/11/12"));
			preserved0.setAvatar(avatar0);
			exchangeList.add(preserved0);

			PreservedAvatar preserved1 = new PreservedAvatar();
			Avatar avatar4 = new Avatar();
			avatar4.setId(3);
			avatar4.setImagePath("/test.png");
			avatar4.setName("景品4");
			avatar4.setPoint(200);
			preserved1.setAvatar(avatar4);
			preserved1.setDate(DateFormat.getDateInstance().parse("2016/7/3"));
			exchangeList.add(preserved1);
			break;

		case "user2":
			break;
		}
		return exchangeList;
	}

	/**
	 * グロコミIDから所持画像のリストを取得
	 * 
	 * @param glocommId
	 *            グロコミID
	 * @return
	 */
	public List<String> getPreservedImagePathList(String glocommId) {
		List<String> pathList = new ArrayList<String>();
		switch (glocommId) {
		case "user1":
			pathList.add("avatar/test1.png");
			pathList.add("avatar/test2.png");
			break;
		case "user2":
			pathList.add("avatar/test3.png");
			pathList.add("avatar/test4.png");
			break;
		}

		return pathList;
	}
}