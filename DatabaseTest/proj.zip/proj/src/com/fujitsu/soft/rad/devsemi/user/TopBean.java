//Copyright FUJITSU LIMITED 2016

package com.fujitsu.soft.rad.devsemi.user;

import com.fujitsu.soft.rad.devsemi.Sort;


import com.fujitsu.soft.rad.devsemi.entity.*;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.io.Serializable;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.UserTransaction;

import com.fujitsu.soft.rad.devsemi.entity.Item;
import com.fujitsu.soft.rad.devsemi.entity.UserAccount;

import com.fujitsu.soft.rad.devsemi.manager.AccountManager;

import com.fujitsu.soft.rad.devsemi.manager.ItemManager;
import com.fujitsu.soft.rad.devsemi.manager.ReviewManager;
import com.fujitsu.soft.rad.devsemi.seller.PublicStat;

/**
 * トップページの豆を蒔きます．
 * 
 * @author Omishima, Senchi(G03)
 */
@Named
@RequestScoped /* scopeはすぐ死ぬならこれで大丈夫らしい． */
public class TopBean implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -2547580903593845951L;

	@PersistenceContext(unitName = "Numazon")
	private EntityManager em;

	@Resource
	UserTransaction utx;

	AccountManager am;

	ReviewManager rm;
	ItemManager im;

	class Ranking {
		int ranking;
		UserAccount account;
	}

	private List<Item> recommendItemList;
	private Map<Integer, String> recommendReviewMap;

	private List<UserAccount> rankingList;
	private Map<String, String> imagePathMap;

	private final boolean STUBTEST = false;

	/**
	 * 初期化
	 */
	@PostConstruct
	public void init() {
		am = new AccountManager(em, utx);
		im = new ItemManager(em, utx);
		rm = new ReviewManager(em, utx);

		// アイテムマネージャーに問い合わせる kudo
		if (STUBTEST) {
			// ItemManager im = new ItemManager(em, utx);
			// items = im.getRecommendItemList();
			/* データベースにおすすめ商品5位までを問い合わせて，リストitemsに追加していきます． */
		} else {
			// レビューから4点以上のものを抜き出して、Dateでソート、そのあとにidを射影する。
			recommendItemList=new ArrayList<Item>();
			List<Review> rs = rm.getRecommendReviewList();
			if (rs.size() >= 3) {
				Sort.sortReviewByDate(rs);
				List<Integer> idlist = rs.stream().map(s -> s.getItemId()).filter(itemid -> im.getItem(itemid).getPublicStat() == PublicStat.PUBLIC).distinct().collect(Collectors.toList());
				if (idlist.size() >= 3) {
					recommendItemList.add(im.getItem(idlist.get(0)));
					recommendItemList.add(im.getItem(idlist.get(1)));
					recommendItemList.add(im.getItem(idlist.get(2)));
				}
			}
			//recommendItemList = im.getRecommendItemList(3);
		}

		// 検索できなかった時のダミーのレビュー
		Avatar avatar = new Avatar();
		avatar.setImagePath("");
		Review rev = new Review();
		rev.setComment("");
		rev.setAvatar(avatar);

		// おすすめレビューの取得
		recommendReviewMap = recommendItemList.stream().collect(Collectors.toMap(item -> item.getId(),
				item -> Sort.getReviewByStar(rm.getReviewListByItemId(item.getId())).stream().findFirst().orElse(rev).getComment()));
				
		// アカウントマネージャからランキングを取得
		rankingList = getAccountRanking();

		// アバターの画像パスのマップ
		imagePathMap = rankingList.stream()
				.collect(Collectors.toMap(a -> a.getGlocommId(), a -> Sort.getReviewByDate(rm.getReviewListByAccountId(a.getGlocommId()))
						.stream().findFirst().orElse(rev).getAvatar().getImagePath()));
	}

	/**
	 * オススメ商品リストを取り出す。
	 * 
	 * @return オススメ商品リスト
	 */
	public List<Item> getRecommendItemList() {
		return recommendItemList;
	}

	/**
	 * 
	 * @return YP廃人のリスト（リストの中身の型はaccount）
	 */

	public List<UserAccount> getAccountRanking(){
		//アカウントマネージャに問い合わせる。
		List<UserAccount> accounts = new ArrayList<UserAccount>();
		
		/* データベースに廃人5人を問い合わせて，リストaccountsに追加していきます． */
		
		AccountManager am = new AccountManager(em,utx);
		accounts = am.getUserAccountList();
		Sort.sortUserByYP(accounts);
		
		return accounts;
	}
	
	public Avatar getAvatarUserAccount(String userId)
	{
		Avatar retAvatar = new Avatar();
		retAvatar.setImagePath("../product/item-img/test.png");
		List<Review> reviewlist = new ArrayList<Review>();
		if(STUBTEST)
		{
			
		}else{
			ReviewManager rm = new ReviewManager(em, utx);
			reviewlist = rm.getReviewListByAccountId(userId);
			Sort.sortReviewByDate(reviewlist);
		}
		return (reviewlist.size() != 0) ? reviewlist.get(0).getAvatar() : retAvatar;
	}
	
	public String getAvatarImageYPRank(int rank)
	{
		return getAvatarUserAccount(getAccountRanking().get(rank-1).getGlocommId()).getImagePath();
	}
	//public List<UserAccount> getAccountRanking() {
	//	return rankingList;

//	}

	/**
	 * 
	 * @return ポップアップを出す場合はtrue，出さない場合はfalse
	 */
	public boolean getReviewPopup() {
		/*
		 * データベースに買ったのにレビューしてない商品があるか問い合わせて，ある場合trueを，ない場合falseを返します．
		 * 問い合わせる術がないのでここではとりあえずtrueを返すようにしておきます（TODO）
		 */
		// アカウントに問い合わせる
		return true;
	}

	/**
	 * おすすめのレビューのマップを取得
	 * 
	 * @return レビューのマップ
	 */
	public Map<Integer, String> getRecommendReview() {
		return recommendReviewMap;
	}

	/**
	 * 画像パスのマップを取得
	 * 
	 * @return 画像パスのマップ
	 */
	public Map<String, String> getImagePathMap() {
		return imagePathMap;
	}	
}
