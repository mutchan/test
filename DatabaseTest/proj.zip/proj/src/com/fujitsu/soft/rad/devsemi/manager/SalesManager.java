package com.fujitsu.soft.rad.devsemi.manager;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.TemporalType;
import javax.transaction.HeuristicMixedException;
import javax.transaction.HeuristicRollbackException;
import javax.transaction.NotSupportedException;
import javax.transaction.RollbackException;
import javax.transaction.SystemException;
import javax.transaction.UserTransaction;

import com.fujitsu.soft.rad.devsemi.entity.Item;
import com.fujitsu.soft.rad.devsemi.entity.Sales;
import com.sun.xml.wss.core.Timestamp;

/**
 * 売り上げDBへのアクセス
 * 
 * @author Hiradae, Mutsuki
 *
 */
public class SalesManager implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -5357886754168894712L;
	
	EntityManager em;
	UserTransaction utx;

	/**
	 * コンストラクタ
	 * 
	 * @param em
	 *            エンティティマネージャ
	 * @param utx
	 *            ユーザートランザクション
	 */
	public SalesManager(EntityManager em, UserTransaction utx) {
		this.em = em;
		this.utx = utx;
	}

	/**
	 * すべてのアバターの情報を取得
	 * 
	 * @return すべてのアバターのリスト
	 */
	public List<Sales> getSalesList() {
		try {
			return em.createNamedQuery(Sales.FIND_ALL, Sales.class).getResultList();
		} catch (NoResultException e) {
			return new ArrayList<Sales>();
		}
	}

	/**
	 * グロコミIDから売上情報を取得
	 * 
	 * @param glocommId
	 *            グロコミID
	 * 
	 * @return すべてのアバターのリスト
	 */
	public List<Sales> getSalesList(String glocommId) {
		try {
			return em.createNamedQuery(Sales.BY_ACCOUNT, Sales.class).setParameter("id", glocommId).getResultList();
		} catch (NoResultException e) {
			return new ArrayList<Sales>();
		}
	}

	/**
	 * 指定したIDの売上情報を取得
	 * 
	 * @param salesId
	 *            アバターのID
	 * @return 売上情報
	 */
	public Sales getSales(int salesId) {
		try {
			return em.createNamedQuery(Sales.BY_ID, Sales.class).setParameter("id", salesId).getSingleResult();
		} catch (NoResultException e) {
			return null;
		}
	}

	/**
	 * 全ての商品の売り上げ情報を取得
	 * 
	 * @return ArrayList<Sales>
	 */
	public List<Sales> getAllSalesList() {
		try {
			return em.createNamedQuery(Sales.FIND_ALL, Sales.class).getResultList();
		} catch (NoResultException e) {
			return new ArrayList<Sales>();
		}
	}

	/**
	 * 売上情報の削除
	 * 
	 * @param sales
	 *            売上情報
	 */
	public void removeSales(Sales sales) {
		try {
			utx.begin();
			em.remove(sales);
			utx.commit();
		} catch (NotSupportedException | SystemException | SecurityException | IllegalStateException | RollbackException
				| HeuristicMixedException | HeuristicRollbackException e) {
			e.printStackTrace();

			try {
				utx.rollback();
			} catch (IllegalStateException | SecurityException | SystemException e1) {
				e1.printStackTrace();
			}
		}
	}

	/**
	 * 指定された期間の売り上げリストを返す
	 * 
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public List<Sales> extractAllSalesList(Date startDate, Date endDate) {
		try {
			return em.createNamedQuery(Sales.BY_DATE, Sales.class)
					.setParameter("startDate", startDate, TemporalType.TIMESTAMP)
					.setParameter("endDate", endDate, TemporalType.TIMESTAMP)
					.getResultList();
		} catch (NoResultException e) {
			return new ArrayList<Sales>();
		}
	}

	/**
	 * 売上情報の追加
	 * 
	 * @param glocommId
	 * @param count
	 * @param itemId
	 * @param price
	 */
	public void addSales(String glocommId, int count, int itemId, int price) {
		try {
			utx.begin();
			Sales sales = new Sales();
			sales.setAccountId(glocommId);
			sales.setCount(count);
			sales.setItemId(itemId);
			sales.setPrice(price);
			sales.setDate(new Date());
			em.persist(sales);
			utx.commit();
		} catch (NotSupportedException | SystemException | SecurityException | IllegalStateException | RollbackException
				| HeuristicMixedException | HeuristicRollbackException e) {
			e.printStackTrace();

			try {
				utx.rollback();
			} catch (IllegalStateException | SecurityException | SystemException e1) {
				e1.printStackTrace();
			}
		}
	}
}
