//Copyright FUJITSU LIMITED 2016
package com.fujitsu.soft.rad.devsemi.user;

import java.io.Serializable;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.enterprise.context.RequestScoped;
import javax.faces.application.ConfigurableNavigationHandler;
import javax.faces.context.FacesContext;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.UserTransaction;

import com.fujitsu.soft.rad.devsemi.entity.UserAccount;
import com.fujitsu.soft.rad.devsemi.manager.AccountManager;

/**
 * ヘッダーの豆を蒔きます．
 * 
 * @author Omishima, Senchi(G03)
 */
@SuppressWarnings("serial")
@Named
@RequestScoped
public class HeaderBean implements Serializable {
	@PersistenceContext(unitName = "Numazon")
	private EntityManager em;

	@Resource
	UserTransaction utx;

	private UserAccount account;
	private String searchText;

	private AccountManager am;

	/**
	 * 初期化
	 */
	@PostConstruct
	public void init() {
		am = new AccountManager(em, utx);
		account = am.getCurrentUserAccount();
	}

	/**
	 * 
	 * 検索ボタンを押したときに呼び出されるメソッドです．
	 * 
	 * @return 検索結果の表示画面
	 */
	public String onClickSearch() {
		if (searchText == null || searchText.length() == 0) {
			return "list.xhtml?faces-redirect=true";
		} else {
			return "list.xhtml?keyword=" + getSearchText() + "&amp?faces-redirect=true";
		}
	}

	/**
	 * 検索するテキストの取得
	 * 
	 * @return 検索するテキスト
	 */
	public String getSearchText() {
		return this.searchText;
	}

	/**
	 * 検索するテキストの設定
	 * 
	 * @param searchText
	 *            検索するテキスト
	 */
	public void setSearchText(String searchText) {
		this.searchText = searchText;
	}

	/**
	 * ログイン中のアカウント情報の取得
	 * 
	 * @return ログイン中のアカウント
	 */
	public UserAccount getAccount() {
		if (account == null) {
			return new UserAccount();
		}
		return account;
	}

	/**
	 * ログインしているのかを確認
	 */
	public void isLoggedIn() {
		if (am.getCurrentUserAccount() == null) {
			ConfigurableNavigationHandler handler = (ConfigurableNavigationHandler) FacesContext.getCurrentInstance()
					.getApplication().getNavigationHandler();
			// handler.performNavigation("/login");
		}

	}
}
