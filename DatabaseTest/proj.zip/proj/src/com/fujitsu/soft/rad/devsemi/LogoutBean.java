//Copyright FUJITSU LIMITED 2016

package com.fujitsu.soft.rad.devsemi;

import java.io.Serializable;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.UserTransaction;

import com.fujitsu.soft.rad.devsemi.entity.SellerAccount;
import com.fujitsu.soft.rad.devsemi.entity.UserAccount;
import com.fujitsu.soft.rad.devsemi.manager.AccountManager;

/**
 * ログアウト処理を行うクラスです。 loginBean.javaにaccountを追加しただけです。
 * 
 * @author Shimada(G03)
 */
@Named
@RequestScoped
public class LogoutBean extends LoginBean implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 4855761205073722817L;

	@PersistenceContext(unitName = "Numazon")
	private EntityManager em;

	@Resource
	UserTransaction utx;

	private SellerAccount sellerAccount;// アカウント名です。変数
	private UserAccount userAccount;// アカウント名です。変数
	private AccountManager am;

	/**
	 * 初期化
	 */
	@PostConstruct
	public void init() {
		am = new AccountManager(em, utx);
		userAccount = am.getCurrentUserAccount();
		sellerAccount = am.getCurrentSellerAccount();
	}

	/**
	 * ログアウト画面の「ようこそ、○○」の「○○」を返すメソッドです．
	 * 
	 * @return ユーザ名
	 */
	public String getName() {
		if (userAccount != null) {
			return userAccount.getName();
		}else if(sellerAccount != null){
			return sellerAccount.getId();
		}
		return "";
	}
}
