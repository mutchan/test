package com.fujitsu.soft.rad.devsemi.user;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.UserTransaction;

import com.fujitsu.soft.rad.devsemi.entity.Item;
import com.fujitsu.soft.rad.devsemi.entity.PreservedAvatar;
import com.fujitsu.soft.rad.devsemi.entity.Review;
import com.fujitsu.soft.rad.devsemi.entity.Sales;
import com.fujitsu.soft.rad.devsemi.entity.UserAccount;
import com.fujitsu.soft.rad.devsemi.manager.AccountManager;
import com.fujitsu.soft.rad.devsemi.manager.ItemManager;
import com.fujitsu.soft.rad.devsemi.manager.ReviewManager;
import com.fujitsu.soft.rad.devsemi.manager.SalesManager;
import com.fujitsu.soft.rad.devsemi.stub.AccountManagerStub;

/**
 * アカウント画面のバッキングビーン
 * 
 * @author kudo jumma
 *
 */

@SuppressWarnings("serial")
@Named
@RequestScoped
public class UserAccountBean implements Serializable {
	@PersistenceContext(unitName = "Numazon")
	private EntityManager em;

	@Resource
	UserTransaction utx;

	private AccountManager am;
	private ItemManager im;
	private ReviewManager rm;
	private SalesManager sm;

	private UserAccount account;

	private String newName; /* 何に使うんだろう・・・ */

	public UserAccountBean() {
	}

	@PostConstruct
	public void init() {
		am = new AccountManager(em, utx);
		im = new ItemManager(em, utx);
		rm = new ReviewManager(em, utx);
		sm = new SalesManager(em, utx);
		account = am.getCurrentUserAccount();
	}

	/**
	 * アカウントの部屋番号をだす
	 * 
	 * @return アカウントの部屋番号
	 */
	public String getRoomNumber() {
		if (account == null) {
			return "***";
		} else {
			return Integer.toString(account.getRoomNumber());
		}
	}

	/**
	 * アカウントの名前を出力
	 * 
	 * @return アカウントの名前
	 */
	public String getName() {
		if (account == null) {
			return "nanashi";
		} else {
			return account.getName();
		}
	}

	/**
	 * アカウントのグロコミID出力
	 * 
	 * @return アカウントのグロコミID
	 */
	public String getGlocommId() {
		if (account == null) {
			return "nanashiID";
		} else {
			return account.getGlocommId();
		}
	}

	/**
	 * アカウントの残高を出力
	 * 
	 * @return アカウントの残高
	 */
	public String getMoney() {
		if (account == null) {
			return "***";
		} else {
			return Integer.toString(account.getMoney());
		}
	}

	/**
	 * アカウントのYPを出力
	 * 
	 * @return アカウントのYP
	 */
	public String getPoint() {
		if (account == null) {
			return "***";
		} else {
			return Integer.toString(account.getPoint());
		}
	}

	/**
	 * YPランキングDBから現在のランキングを計算する
	 * 
	 * @return 現在のランキング
	 */
	public int getRanking() {
		if (account == null) {
			return 0;
		} else {
			int nRetRank = 0;
			// アカウントマネージャからYPランクを計算
			// AccountManager am = new AccountManager();
			// nRetRank = am.getYPRank(account);

			return nRetRank;
		}
	}

	/**
	 * ItemManagerから取り出した注文履歴をかえす
	 * 
	 * @return 注文履歴
	 */
	public List<Sales> getOrderHistory() {
		List<Sales> retOrderHistory;
		if (account == null) {
			retOrderHistory = new ArrayList<Sales>();
		} else {
			retOrderHistory = sm.getSalesList(account.getGlocommId());
			if (retOrderHistory == null) {
				retOrderHistory = new ArrayList<Sales>();
			} else {
				Collections.sort(retOrderHistory, new java.util.Comparator<Sales>() {
					public int compare(Sales a, Sales b) {
						return b.getDate().compareTo(a.getDate());
					}
				});
			}
		}
		return retOrderHistory;
	}

	/* htmlのほうでmanagerがいないとsalesから商品名やpathが呼べないので，ここにメソッドを用意しています． */
	public String getName(int id) {
		if (im.getItem(id) == null) {
			return "***";
		} else {
			return im.getItem(id).getName();
		}
	}

	public String getImagePath(int id) {
		if (im.getItem(id) == null) {
			return "";
		} else {
			return im.getItem(id).getImagePath();
		}
	}

	public List<Review> getReviewHistory() {
		List<Review> retReviewHistory;
		if (account == null) {
			retReviewHistory = new ArrayList<Review>();
		} else {
			retReviewHistory = rm.getReviewListByAccountId(account.getGlocommId());
			if (retReviewHistory == null) {
				retReviewHistory = new ArrayList<Review>();
			} else {
				Collections.sort(retReviewHistory, new java.util.Comparator<Review>() {
					public int compare(Review a, Review b) {
						return b.getDate().compareTo(a.getDate());
					}
				});
			}
		}
		return retReviewHistory;
	}

	/**
	 * PreservedAvatarManagerから取り出したポイント履歴をかえす
	 * 
	 * @return
	 */
	List<PreservedAvatar> getPointHistory() {
		List<PreservedAvatar> retPointHistoryList = null;
		// マネージャーから取りに行く
		// PreservedAvatarManager pm = new PreservedAvatarManager();

		return retPointHistoryList;
	}

	/**
	 * レビューするをクリック
	 */
	void onClickReview() {
		// ReviewManager rm = new ReviewManager();
		// Review review;
	}

	/**
	 * その商品にレビューされたか？ をチェックする。レビューマネージャから判断してもらう。
	 * 
	 * @return
	 */
	public String isReviewed(int id) { /* 引数はitemのid */
		List<Review> list = rm.getReviewListByItemId(id);
		if (list == null || list.size() == 0) {
			return "レビューを書くべき";
		} else {
			while (!list.isEmpty()) {
				if (list.get(0).getAccountId().equals(account.getGlocommId())) {
					return "レビューありがとね！";
				}
				list.remove(0);
			}
			return "レビューの輪に入りましょう";
		}
	}

	/**
	 * @return the newname
	 */
	public String getNewName() {
		return newName;
	}

	/**
	 * 新しいアカウント名
	 * 
	 * @param newname
	 *            the newname to set
	 */
	public void setNewName(String newName) {
		this.newName = newName;
	}

	/**
	 * 名前変更をクリック
	 */

	public String onClickName() {
		if (account == null) {
		} else {
			if (newName == null || newName.length() == 0) {
			} else {
				am.updateUserName(newName);
			}
		}
		return "account?faces-redirect=true";

	}

}
