package com.fujitsu.soft.rad.devsemi.manager;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.transaction.HeuristicMixedException;
import javax.transaction.HeuristicRollbackException;
import javax.transaction.NotSupportedException;
import javax.transaction.RollbackException;
import javax.transaction.SystemException;
import javax.transaction.UserTransaction;

import com.fujitsu.soft.rad.devsemi.Sort;
import com.fujitsu.soft.rad.devsemi.entity.Item;
import com.fujitsu.soft.rad.devsemi.seller.Category;
import com.fujitsu.soft.rad.devsemi.seller.PublicStat;

/**
 * 商品DBへのアクセスを行うクラス
 * 
 * @author Hiradate, Mutsuki
 *
 */
public class ItemManager implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -5880511071720779457L;

	EntityManager em;
	UserTransaction utx;

	/**
	 * コンストラクタ
	 * 
	 * @param em
	 *            エンティティマネージャ
	 *
	 * @param utx
	 *            ユーザートランザクション
	 */
	public ItemManager(EntityManager em, UserTransaction utx) {
		this.em = em;
		this.utx = utx;
	}

	/**
	 * 商品IDから商品を取得
	 * 
	 * @param itemId
	 *            商品ID
	 * @return 商品
	 */
	public Item getItem(int itemId) {
		try {
			return em.createNamedQuery(Item.BY_ID, Item.class).setParameter("id", itemId).getSingleResult();
		} catch (NoResultException e) {
			return null;
		}
	}

	/**
	 * 全商品の取得
	 * 
	 * @return 全商品のリスト
	 */
	public List<Item> getAllItemList() {
		try {
			return em.createNamedQuery(Item.FIND_ALL, Item.class).getResultList();
		} catch (NoResultException e) {
			return new ArrayList<Item>();
		}
	}

	/**
	 * 商品名による商品の検索
	 * 
	 * @param searchText
	 *            検索文字列
	 * @return 検索文字列を含む商品のリスト
	 */
	public List<Item> getItemListContains(String searchText) {
		try {
			return em.createNamedQuery(Item.BY_NAME, Item.class).setParameter("name", "%" + searchText + "%")
					.getResultList();
		} catch (NoResultException e) {
			return new ArrayList<Item>();
		}
	}

	/**
	 * おすすめ商品の取得
	 * 
	 * @param limit
	 *            最大個数
	 * @return 商品リスト
	 */
	public List<Item> getRecommendItemList(int limit) {
		try {
			return em.createNamedQuery(Item.BY_STAR_ORDER_DATE, Item.class).setMaxResults(limit).getResultList();
		} catch (NoResultException e) {
			return new ArrayList<Item>();
		}
	}
	
	/**
	 * リリース日でソートしたリストを表示
	 * @return
	 */
	public List<Item> getItemOrderRelease()
	{
		try {
			return em.createNamedQuery(Item.ORDER_RELEASE, Item.class).getResultList();
		} catch (NoResultException e) {
			return new ArrayList<Item>();
		}
	}
	/**
	 * 星の平均でソートしたアイテムリストを表示
	 * @return
	 */
	public List<Item> getItemOrderStar()
	{
		try {
			return em.createNamedQuery(Item.ORDER_STAR, Item.class).getResultList();
		} catch (NoResultException e) {
			return new ArrayList<Item>();
		}
	}
	/**
	 * 値段順でソートしたアイテムリストを出力します。
	 * @return
	 */
	public List<Item> getItemOrderPrice()
	{
		List<Item> retList=new ArrayList<Item>();
		try {
			retList = em.createNamedQuery(Item.FIND_ALL, Item.class).getResultList();
			Sort.sortItemByPrice(retList);
		} catch (NoResultException e) {
			
		}
		return retList;
	}

	/**
	 * 商品の追加
	 * 
	 * @param name
	 *            商品名
	 * @param desc
	 *            商品説明
	 * @param category
	 *            商品カテゴリ
	 * @param publicStat
	 *            公開/非公開
	 * @param imagePath
	 *            画像パス
	 * @return 追加した商品ID
	 */
	public int addItem(String name, String desc, Category category, PublicStat publicStat, String imagePath) {
		try {
			utx.begin();
			Item item = new Item();
			item.setDesc(desc);
			item.setStock(category.getInitStock());
			item.setName(name);
			item.setCategory(category);
			item.setPublicStat(publicStat);
			item.setRegistDate(new Date());
			item.setLastEdit(new Date());
			item.setImagePath(imagePath);
			em.persist(item);
			utx.commit();
			return item.getId();
		} catch (NotSupportedException | SystemException | SecurityException | IllegalStateException | RollbackException
				| HeuristicMixedException | HeuristicRollbackException e) {
			e.printStackTrace();

			try {
				utx.rollback();
				return -1;
			} catch (IllegalStateException | SecurityException | SystemException e1) {
				e1.printStackTrace();
				return -1;
			}
		}
	}

	/**
	 * 商品の更新
	 * 
	 * @param itemId
	 *            商品ID
	 * @param name
	 *            商品名
	 * @param desc
	 *            商品説明
	 * @param category
	 *            商品カテゴリ
	 * @param publicStat
	 *            公開/非公開
	 * @param imagePath
	 *            画像パス
	 */
	public void updateItem(int itemId, String name, String desc, Category category, PublicStat publicStat,
			String imagePath) {
		try {
			utx.begin();
			Item item = getItem(itemId);
			item.setDesc(desc);
			item.setStock(category.getInitStock());
			item.setName(name);
			item.setCategory(category);
			item.setPublicStat(publicStat);
			item.setRegistDate(new Date());
			item.setLastEdit(new Date());
			item.setImagePath(imagePath);
			em.persist(item);
			utx.commit();
		} catch (NotSupportedException | SystemException | SecurityException | IllegalStateException | RollbackException
				| HeuristicMixedException | HeuristicRollbackException e) {
			e.printStackTrace();

			try {
				utx.rollback();
			} catch (IllegalStateException | SecurityException | SystemException e1) {
				e1.printStackTrace();
			}
		}
	}

	/**
	 * 商品の在庫の更新
	 * 
	 * @param itemId
	 *            商品ID
	 * @param stock
	 *            更新後の在庫数
	 */
	public void addStock(int itemId, int stock) {
		try {
			utx.begin();
			Item item = getItem(itemId);
			item.setStock(item.getStock() + stock);
			item.setLastEdit(new Date());
			em.persist(item);
			utx.commit();
		} catch (NotSupportedException | SystemException | SecurityException | IllegalStateException | RollbackException
				| HeuristicMixedException | HeuristicRollbackException e) {
			e.printStackTrace();

			try {
				utx.rollback();
			} catch (IllegalStateException | SecurityException | SystemException e1) {
				e1.printStackTrace();
			}
		}
	}
}