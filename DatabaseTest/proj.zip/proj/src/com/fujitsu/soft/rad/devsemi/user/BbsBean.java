//Copyright FUJITSU LIMITED 2016

package com.fujitsu.soft.rad.devsemi.user;

import java.io.Serializable;

import javax.enterprise.context.RequestScoped;
import javax.inject.Named;

/**
 * 掲示板の豆です．書き込み（トピック？）のデータ構造をあんましよく理解できてないので，ほとんど空洞です．
 * 
 * @author Omishima, Senchi(G03)
 */
@SuppressWarnings("javadoc")
@Named
@RequestScoped
public class BbsBean implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 838847692234344684L;
	/*
	 * フィールドのところはちょっと悩み中です．というか，設計をよく理解できてません．
	 * とりあえず，データベースから書き込み（トピック？）を全部もらってきたのを保持するフィールドと，
	 * 各書き込みに対して，それを表示するかどうかの情報を持たせるフィールドが必要らしいです．
	 */
	public void onClickRemove(){
		/* 
		 * データベースに問い合わせて，該当する書き込みを削除してもらいます．
		 * また，Beanのフィールドからもそのデータを削除，更新する必要があります．
		 */
	}
	public void onClickPost(){
		/*
		 * データベースに問い合わせて，新たに書き込みを追加します．
		 * また，それに応じて，Beanのフィールドにもそれを追加，更新する必要があります．
		 */
	}
	public void onClickReply(){
		/*
		 * データベースに問い合わせて，新たに書き込みを追加します．
		 * また，それに応じて，Beanのフィールドにもそれを追加，更新する必要があります．
		 */
	}
	public void onClickPullDown(){
		/*
		 * 書き込みを表示するかどうかのBeanのフィールドを変更すれば実現されます．
		 * 具体的にはpull-downしたトピックを親に持つトピックに対応する箇所をすべて反転させてやればいいはずです．
		 */
	}
	public void idHidden(){
		/*
		 * 書き込みを表示するかどうかのBeanのフィールドを変更すれば実現されます．
		 * 具体的には非表示にしたいトピックに対応する箇所をすべて反転させてやればいいはずです．
		 */
	}
}
