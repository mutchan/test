package com.fujitsu.soft.rad.devsemi.seller;


//import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;

import java.io.Serializable;
import java.util.ArrayList;

//import javax.faces.bean.ManagedBean;
import javax.inject.Named;

import org.primefaces.model.chart.Axis;
import org.primefaces.model.chart.AxisType;
//import org.primefaces.model.chart.CategoryAxis;
import org.primefaces.model.chart.LineChartModel;
import org.primefaces.model.chart.ChartSeries;
//import org.primefaces.model.chart.LineChartSeries;
 
@SuppressWarnings("serial")
@Named
@RequestScoped
public class ChartBean implements Serializable {
 
    private LineChartModel model;
    
    public ChartBean(){
    	System.out.println("Load Constructor");
    	model = new LineChartModel();
    	
    	ChartSeries series1 = new ChartSeries();
    	series1.setLabel("商品A");
    	
    	ArrayList<ArrayList<Number>> chartList = new ArrayList<>();
    	ArrayList<Number> tmp;
    	for(int i=1; i<13; i++){
    		tmp = new ArrayList<>();
    		tmp.add(i);
    		tmp.add(Math.random()*10);
    		chartList.add(tmp);
    	}
    	for(ArrayList<Number> array: chartList){
    		System.out.println(array.get(0));
    		series1.set(array.get(0), array.get(1));
    	}
    	
    	
    	model.addSeries(series1);
    	model.setTitle("売り上げ推移");
    	model.setLegendPosition("e");
    	model.setShowPointLabels(true);
    	Axis yAxis = model.getAxis(AxisType.Y);
    	yAxis.setLabel("売り上げ");
    	yAxis.setMin(0);
    	yAxis.setMax(10);
    }
    
    public LineChartModel getModel(){
		return model;
    }
    
    public void setModel(LineChartModel model){
    	this.model = model;
    }
}
 

