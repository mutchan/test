package com.fujitsu.soft.rad.devsemi.seller;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.enterprise.context.RequestScoped;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.UserTransaction;

import org.primefaces.context.RequestContext;

import com.fujitsu.soft.rad.devsemi.entity.Item;
import com.fujitsu.soft.rad.devsemi.manager.ItemManager;

/**
 * 在庫管理画面のビーン
 * 
 * @author jumma kudo
 *
 */
@SuppressWarnings("serial")
@ManagedBean
@ViewScoped
public class StockBean implements Serializable {
	@PersistenceContext(unitName = "Numazon")
	private EntityManager em;

	@Resource
	UserTransaction utx;

	private HashMap<Integer, Integer> addStockList = new HashMap<Integer, Integer>();// 在庫の追加数ハッシュマップ：商品ID,追加数
	private Item selectedStock;
	private ItemManager im;

	private List<Item> itemList;
	private List<String> addMessage;
	private List<String> errMessage;

	/**
	 * 初期化
	 */
	@PostConstruct
	public void init() {
		im = new ItemManager(em, utx);
		itemList = im.getAllItemList();

		addMessage = new ArrayList<String>();
		errMessage = new ArrayList<String>();

		errMessage.add("ここにメッセージが表示されます");
	}

	/**
	 * 在庫追加リストの設定
	 * 
	 * @param addStockList
	 *            在庫追加リスト
	 */
	public void setAddStockList(HashMap<Integer, Integer> addStockList) {
		this.addStockList = addStockList;
	}

	/**
	 * 在庫追加リストの取得
	 * 
	 * @return 在庫追加リスト
	 */
	public HashMap<Integer, Integer> getAddStockList() {
		return addStockList;
	}

	/**
	 * html側で追加する数を見て、追加処理の結果を出力
	 * 
	 * @return 「○○○を××個追加しました。」というメッセージ
	 */
	public String getAddMessage() {
		System.out.println("Call getAddMessage()");
		System.out.println(addMessage);

		if (errMessage.size() > 0) {
			return errMessage.stream().map(s->s+"\r\n").collect(Collectors.joining());
		}
		
		return addMessage.stream().map(s->s+"個追加しました。\r\n").collect(Collectors.joining());
	}

	/**
	 * 追加可能かのチェック
	 */
	public void calcAddStock() {
		//
		addMessage.clear();
		errMessage.clear();

		System.out.println(addStockList.size());

		Item item;
		for (int id : addStockList.keySet()) {
			if ((item = im.getItem(id)) != null && addStockList.get(id) != null) {
				if (item.getStock() + addStockList.get(id) > item.getCategory().getInitStock() * 5) {
					errMessage.add(item.getName() + "の在庫が上限を超えます。");
				} else {// マネージャから商品名をもらう。
					addMessage.add(item.getName() + "の在庫を" + addStockList.get(id) + "個追加");
				}
			}
		}
		if (addMessage.size() == 0 && errMessage.size() == 0) {
			errMessage.add("入力内容がありません");
		}
	}

	/**
	 * html側で追加する数を見て、追加処理の結果を出力
	 * 
	 * @return 「○○○を××個追加しました。」というメッセージ
	 */
	public List<String> getAddMessageDialog() {
		System.out.println("call getAddMessageDialog():size=" + errMessage.size());
		if (errMessage.size() > 0) {
			return errMessage;
		}
		return addMessage;
	}

	/**
	 * 
	 * @return
	 */
	public boolean getIsError() {
		return errMessage.size() == 0;
	}

	/**
	 * 在庫リストの取得
	 * 
	 * @return 在庫リスト
	 */
	public List<Item> getStockList() {
		return itemList;
	}

	/**
	 * 在庫追加を、マネージャに頼んで行うメソッド
	 * 
	 * @return 何もしない
	 */
	public String onClickAdd() {
		for (int itemId : addStockList.keySet()) {
			if (addStockList.get(itemId) != null) {
				im.addStock(itemId, addStockList.get(itemId));
			}
		}
		itemList = im.getAllItemList();
		calcAddStock();
		addStockList.clear();
		return "#";
	}

	/**
	 * 選択された行の取得
	 * 
	 * @return 選択された在庫
	 */
	public Item getSelectedStock() {
		return selectedStock;
	}

	/**
	 * 選択された行の設定
	 * 
	 * @param selectedStock
	 *            選択された行
	 */
	public void setSelectedStock(Item selectedStock) {
		this.selectedStock = selectedStock;
	}

}
