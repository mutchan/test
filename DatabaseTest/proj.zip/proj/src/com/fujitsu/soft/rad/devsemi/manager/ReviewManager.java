package com.fujitsu.soft.rad.devsemi.manager;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.transaction.HeuristicMixedException;
import javax.transaction.HeuristicRollbackException;
import javax.transaction.NotSupportedException;
import javax.transaction.RollbackException;
import javax.transaction.SystemException;
import javax.transaction.UserTransaction;

import com.fujitsu.soft.rad.devsemi.entity.Avatar;
import com.fujitsu.soft.rad.devsemi.entity.Review;

/**
 * レビューDBへのアクセス
 * 
 * @author Hiradate, Mutsuki
 *
 */
public class ReviewManager implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 3460558501877376950L;
	
	EntityManager em;
	UserTransaction utx;

	/**
	 * コンストラクタ
	 * 
	 * @param em
	 *            エンティティマネージャ
	 * @param utx
	 *            ユーザートランザクション
	 */
	public ReviewManager(EntityManager em, UserTransaction utx) {
		this.em = em;
		this.utx = utx;
	}

	/**
	 * レビューIDからレビューを取得
	 * 
	 * @param reviewId
	 *            レビューID
	 * @return レビュー
	 */
	public Review getReview(int reviewId) {
		try {
			return em.createNamedQuery(Review.BY_ID, Review.class).setParameter("id", reviewId).getSingleResult();
		} catch (NoResultException e) {
			return null;
		}
	}

	/**
	 * おすすめ商品の取得
	 * 
	 * @return おすすめ商品のリスト
	 */
	public List<Review> getRecommendReviewList() {
		try {
			return em.createQuery("select r from Review r where r.star >= 4", Review.class).getResultList();
		} catch (NoResultException e) {
			return null;
		}
	}

	/**
	 * 商品IDからレビューのリストを取得
	 * 
	 * @param itemId
	 *            商品ID
	 * @return レビューのリスト
	 */
	public List<Review> getReviewListByItemId(int itemId) {
		try {
			return em.createNamedQuery(Review.BY_ITEM_ID, Review.class).setParameter("itemId", itemId).getResultList();
		} catch (NoResultException e) {
			return null;
		}
	}

	/**
	 * グロコミIDからレビューのリストを取得
	 * 
	 * @param accountId
	 *            グロコミID
	 * @return レビューのリスト
	 */
	public List<Review> getReviewListByAccountId(String accountId) {
		try {
			return em.createNamedQuery(Review.BY_ACCOUNT_ID, Review.class).setParameter("accountId", accountId)
					.getResultList();
		} catch (NoResultException e) {
			return null;
		}
	}

	/**
	 * レビューの投稿
	 * 
	 * @param review
	 *            追加するレビュー
	 *
	 */
	public void postReview(Review review) {
		try {
			utx.begin();
			em.persist(review);
			utx.commit();
		} catch (NotSupportedException | SystemException | SecurityException | IllegalStateException | RollbackException
				| HeuristicMixedException | HeuristicRollbackException e) {
			e.printStackTrace();

			try {
				utx.rollback();
			} catch (IllegalStateException | SecurityException | SystemException e1) {
				e1.printStackTrace();
			}
		}
	}

	/**
	 * レビューの削除
	 *
	 * @param reviewId
	 *            レビューID
	 */
	public void removeReview(int reviewId) {
		try {
			utx.begin();
			Review review = getReview(reviewId);
			em.remove(review);
			utx.commit();
		} catch (NotSupportedException | SystemException | SecurityException | IllegalStateException | RollbackException
				| HeuristicMixedException | HeuristicRollbackException e) {
			e.printStackTrace();

			try {
				utx.rollback();
			} catch (IllegalStateException | SecurityException | SystemException e1) {
				e1.printStackTrace();
			}
		}
	}

	/**
	 * レビューのいいねカウントを追加
	 * 
	 * @param reviewId
	 *            いいねしたレビューのレビューID
	 */
	public void addGoodCount(int reviewId) {
		try {
			utx.begin();
			Review review = getReview(reviewId);
			review.setGoodCount(review.getGoodCount() + 1);
			utx.commit();
		} catch (NotSupportedException | SystemException | SecurityException | IllegalStateException | RollbackException
				| HeuristicMixedException | HeuristicRollbackException e) {
			e.printStackTrace();

			try {
				utx.rollback();
			} catch (IllegalStateException | SecurityException | SystemException e1) {
				e1.printStackTrace();
			}
		}
	}
}
