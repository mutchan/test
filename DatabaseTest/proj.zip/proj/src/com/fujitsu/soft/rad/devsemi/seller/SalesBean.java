package com.fujitsu.soft.rad.devsemi.seller;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.List;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.UserTransaction;

import org.eclipse.persistence.jpa.jpql.parser.DateTime;

import com.fujitsu.soft.rad.devsemi.entity.Item;
import com.fujitsu.soft.rad.devsemi.entity.Sales;
import com.fujitsu.soft.rad.devsemi.manager.ItemManager;
import com.fujitsu.soft.rad.devsemi.manager.SalesManager;
import com.fujitsu.soft.rad.devsemi.stub.SalesManagerStub;

/**
 * 
 * 売り上げ画面です
 * 
 * @author who?
 *
 */
@Named
@RequestScoped
@SuppressWarnings("serial")
public class SalesBean implements Serializable {
	@PersistenceContext(unitName = "Numazon")
	private EntityManager em;

	@Resource
	UserTransaction utx;

	public static final double TAX = 0.08; // 消費税率

	private int ItemID;// 現状はint型で(6/27) とりあえずItemのIは大文字で
	private int salesNum;
	private int subTotal;
	private int tax;// ややこしいけど内税のことです（小計が100円なら8円のこと）、とりあえずTは大文字で

	private Calendar now = Calendar.getInstance();
	private Date endDate; // 選択した期間の終了日（デフォルトでは現在の日付）
	private Date startDate; // 選択した期間の開始日（デフォルトでは現在の1か月前）

	private boolean alert; // 必要ないかもしれない
	private int allTotalSales; // 総売り上げ（小計）
	private int allTotalTax; // 総売り上げの内税
	private Item selectedStock;
	private List<Item> itemList;

	private HashMap<Integer, int[]> salesHash; // itemIdと、List(売上個数、小計)のHashMap
	// private SalesManagerStub sales;
	private SalesManager sales;
	private ItemManager im;

	@PostConstruct
	public void init() {
		// TODO:テストコードの変更
		allTotalSales = 0;
		allTotalTax = 0;
		im = new ItemManager(em, utx);
		itemList = im.getAllItemList();
		sales = new SalesManager(em, utx);
		createHashMap();
	}

	/**
	 * 商品のIDに対応する売上個数、小計を記憶したHashMapを生成
	 */
	public void createHashMap() {
		salesHash = new HashMap<Integer, int[]>();
		System.out.println("Load createHashMap()");
		List<Sales> salesList;
		if (startDate == null && endDate == null) {
			endDate = now.getTime();
			startDate = Date.from(LocalDateTime.now().minusMonths(1).atZone(ZoneId.systemDefault()).toInstant());
			salesList = sales.getAllSalesList();
			System.out.println("size(All): " + salesList.size());
		} else {
			salesList = sales.extractAllSalesList(startDate, endDate);
			System.out.println("size(Apart):" + salesList.size());
		}
		
		System.out.println("start: " + startDate);
		System.out.println("end: " + endDate);

		int tmp_count, tmp_price, tmp_id;
		for (Sales s : salesList) {
			tmp_id = s.getItemId();
			allTotalSales += s.getPrice();
			if (salesHash.containsKey(tmp_id)) {
				tmp_count = salesHash.get(tmp_id)[0] + s.getCount();
				tmp_price = salesHash.get(tmp_id)[1] + s.getPrice();
				salesHash.put(s.getItemId(), new int[] { tmp_count, tmp_price });
			} else {
				salesHash.put(s.getItemId(), new int[] { s.getCount(), s.getPrice() });
			}
		}
		allTotalTax = (int) (allTotalSales * TAX);
	}

	/**
	 * 在庫が不足しているか判断するメソッド 在庫が残り1割りを下回ったらtrue,下回っていなかったらfalse
	 * 
	 * salesNum: 在庫数 subTotal： 現在の単価
	 * 
	 * 
	 * @param salesNum
	 *            在庫数
	 * @param subTotal
	 *            現在の単価
	 * 
	 * @return true(在庫1割以下) false(在庫1割以上)
	 * 
	 */
	public boolean checkAlert(int salesNum, int subTotal) {
		/**
		 * salesNum: 現在の在庫数 subTotal: 現在の価格
		 * 
		 * アルゴリズム 在庫数が10個以下かつ現在の価格が100,000円ならばtrue
		 * 在庫数が100個以下かつ現在の価格が15,000円ならばtrue 在庫数が1000個以下かつ現在の価格が1,000円ならばtrue
		 */
		boolean ch = false;
		if (salesNum <= 10 && subTotal >= 100000) { // テスト用に右辺を==→>=に変更してる
			ch = true;
		} else if (salesNum <= 1000 && subTotal >= 14000) {
			ch = true;
		} else if (salesNum <= 10000 && subTotal >= 1000) {
			ch = true;
		}
		return ch;
	} // なんか値返すの？

	/**
	 * 売り上げ個数
	 * 
	 * @param itemId
	 * @return 0 or 売上個数
	 */
	public int calcTotalNum(int itemId) {
		try {
			return salesHash.get(itemId)[0];
		} catch (NullPointerException e) {
			// System.out.println("itemID: " + salesHash.get(itemId) + "\tNo
			// Sales (TotanNum)");
			return 0;
		}
	}

	/**
	 * 売上高（小計）
	 * 
	 * @param itemId
	 * @return 0 or 売上高 /** 表中の小計を計算するメソッド 単価が変わるので結構めんどそう
	 * 
	 * @return 小計
	 */
	public int calcTotalSales(int itemId) {
		try {
			return salesHash.get(itemId)[1];
		} catch (NullPointerException e) {
			// System.out.println("itemID: " + salesHash.get(itemId) + "\tNo
			// Sales (TotalSales)");
			return 0;
		}
	}

	/**
	 * 表中の内税を計算するメソッド 小計×税率(0.08)ですかね
	 * 
	 * @param itemId
	 * @return 0 or 内税
	 */
	public int calcTax(int itemId) {
		try {
			return (int) (salesHash.get(itemId)[1] * TAX); // intに型変換している
															// 小数点以下切り捨て
		} catch (NullPointerException e) {
			// System.out.println("itemID: " + salesHash.get(itemId) + "\tNo
			// Sales (Tax)");
			return 0;
		}
	}

	public int getItemID() {
		return ItemID;
	}

	public void setItemID(int itemID) {
		this.ItemID = itemID;
	}

	public int getSalesNum() {
		return salesNum;
	}

	public void setSalesNum(int salesNum) {
		this.salesNum = salesNum;
	}

	public int getSubtotal() {
		return subTotal;
	}

	public void setSubtotal(int subTotal) {
		this.subTotal = subTotal;
	}

	public int getTax() {
		return tax;
	}

	public void setTax(int tax) {
		this.tax = tax;
	}

	/*
	 * 必要ないかもしれない
	 */
	public boolean getAlert() {
		return this.alert;
	}

	public void setAlert(boolean alert) {
		this.alert = alert;
	}

	/**
	 * 商品リストの取得
	 * 
	 * @return 商品リスト
	 */
	public List<Item> getItemList() {
		return itemList;
		// return (new SalesManagerStub()).getSalesList();
		// return null; // new ItemManager().getItemList();
	}

	public void setItemList(List<Item> itemList) {
		this.itemList = itemList;
	}

	/**
	 * 選択された行の取得
	 * 
	 * @return 選択された在庫
	 */
	public Item getSelectedStock() {
		return selectedStock;
	}

	/**
	 * 選択された行の設定
	 * 
	 * @param selectedStock
	 *            選択された行
	 */
	public void setSelectedStock(Item selectedStock) {
		this.selectedStock = selectedStock;
	}

	public HashMap<Integer, int[]> getSalesHash() {
		return this.salesHash;
	}

	public void setSalesHash(HashMap<Integer, int[]> salesHash) {
		this.salesHash = salesHash;
	}

	public int getAllTotalSales() {
		return (int) (allTotalSales * (1 + TAX));
	}

	public void setAllTotalSales(int allTotalSales) {
		this.allTotalSales = allTotalSales;
	}

	public int getAllTotalTax() {
		return allTotalTax;
	}

	public void setAllTotalTax(int allTotalTax) {
		this.allTotalTax = allTotalTax;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

}
