package com.fujitsu.soft.rad.devsemi.user;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.enterprise.context.RequestScoped;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.UserTransaction;

import com.fujitsu.soft.rad.devsemi.entity.Cart;
import com.fujitsu.soft.rad.devsemi.entity.Item;
import com.fujitsu.soft.rad.devsemi.entity.UserAccount;
import com.fujitsu.soft.rad.devsemi.manager.AccountManager;
import com.fujitsu.soft.rad.devsemi.manager.CartManager;
import com.fujitsu.soft.rad.devsemi.manager.ItemManager;
import com.fujitsu.soft.rad.devsemi.manager.SalesManager;
import com.fujitsu.soft.rad.devsemi.seller.PublicStat;

/**
 * 各商品の詳細を出すBean
 * 
 * @auther Okano Naoki (6/28)
 */
@SuppressWarnings("serial")
@ManagedBean
@ViewScoped
public class ConfirmBean implements Serializable {
	@PersistenceContext(unitName = "Numazon")
	private EntityManager em;

	@Resource
	UserTransaction utx;

	private AccountManager am;
	private CartManager cm;
	private ItemManager im;
	private SalesManager sm;

	// private UserAccount account;
	private Map<Integer, Integer> itemPriceMap; // ページ遷移時の価格マップ（itemId->price）
	private List<Cart> cartList = new ArrayList<Cart>();
	private UserAccount user; // 自分のユーザーアカウント

	private int total;// 注文したときの合計金額
	private int tax;// 内税
	private int balance;// 残高

	private static final double TAX = 0.08;

	@PostConstruct
	public void init() {
		cm = new CartManager(em, utx);
		am = new AccountManager(em, utx);
		im = new ItemManager(em, utx);
		sm = new SalesManager(em, utx);

		// Todo: テスト用ログイン
		// am.userLogin("user", "pass");

		user = am.getCurrentUserAccount();
		cartList = new ArrayList<Cart>();
		if (user != null) {
			String glocommId = user.getGlocommId();

			// カートマネージャからカートリストを受け取る
			cartList = cm.getCartList(glocommId);

		}

		itemPriceMap = cartList.stream()
				.collect(Collectors.toMap(s -> s.getItemId(), s -> im.getItem(s.getItemId()).getPrice()));
	}

	public List<Cart> getCartList() {
		return cartList;
	}

	public void setCartList(List<Cart> cartList) {
		this.cartList = cartList;
	}

	public int getTotal() {
		// ItemManagerStub im = new ItemManagerStub();
		total = 0;

		for (Cart cart : cartList) {
			total += im.getItem(cart.getItemId()).getPrice() * cart.getCount();
			System.out.println("price:" + im.getItem(cart.getItemId()).getPrice() + ",count:" + cart.getCount());
		}

		return (int) (total * (1 + TAX));
	}

	public boolean checkPublicItemInCart() {
		boolean ret = true;
		for (Cart cart : cartList) {
			System.out.println("DEBUG:cartitemid:" + cart.getItemId() + ",publicstat:"
					+ (im.getItem(cart.getItemId()).getPublicStat() == PublicStat.PUBLIC));
			ret = ret && (im.getItem(cart.getItemId()).getPublicStat() == PublicStat.PUBLIC);

		}
		return ret;
	}

	public String getImagePath(int itemid) {
		// ItemManagerStub im = new ItemManagerStub();
		return im.getItem(itemid).getImagePath();
	}

	public String getItemName(int itemid) {
		// ItemManagerStub im = new ItemManagerStub();

		return im.getItem(itemid).getName();
	}

	public int getItemPrice(int itemid) {
		// ItemManagerStub im = new ItemManagerStub();

		return im.getItem(itemid).getPrice();
	}

	public int getTax() {
		// ItemManagerStub im = new ItemManagerStub();
		total = 0;
		for (Cart cart : cartList) {
			total += im.getItem(cart.getItemId()).getPrice() * cart.getCount();
		}
		return (int) (total * TAX);
	}

	public int getBalance() {
		balance = user.getMoney() - getTotal();
		return balance;
	}

	/**
	 * カートの中身が在庫よりも大きくないかのチェック
	 * 
	 * @return
	 */
	public boolean checkStock() {
		boolean ret = true;
		for (Cart cart : cartList) {
			System.out.println(cart.getCount() + "->" + im.getItem(cart.getItemId()).getStock());
			ret = ret && (cart.getCount() <= im.getItem(cart.getItemId()).getStock());
		}
		return ret;
	}

	/**
	 * 購入できるかチェック
	 * 
	 * @return
	 */
	public String purchase() {
		// 残高チェック
		if (user.getMoney() < getTotal()) {
			// 残高変動のメッセージを記録
			FacesContext.getCurrentInstance().getExternalContext().getFlash().put("FailedMessage", "残高が足りません");

			return "purchasefailed";
		}

		// 残高の変動チェック
		if (user.getMoney() != am.getCurrentUserAccount().getMoney()) {
			// 残高変動のメッセージを記録
			FacesContext.getCurrentInstance().getExternalContext().getFlash().put("FailedMessage", "残高が変動しました");

			return "purchasefailed";
		}

		// 在庫チェック
		if (!checkStock()) {
			// 在庫数変動のメッセージを記録
			FacesContext.getCurrentInstance().getExternalContext().getFlash().put("FailedMessage", "在庫数が変動しました");

			return "purchasefailed";
		}

		// 非公開アイテムチェック
		if (!checkPublicItemInCart()) {
			// カート内の非公開アイテムを消す処理
			for (Cart cart : cartList) {
				if (im.getItem(cart.getItemId()).getPublicStat() != PublicStat.PUBLIC) {
					cm.removeCart(cart.getId());
				}
			}

			// 非公開になったメッセージを記録
			FacesContext.getCurrentInstance().getExternalContext().getFlash().put("FailedMessage", "商品が非公開になりました");

			return "purchasefailed";
		}

		// 価格変動チェック
		if (cartList.stream().anyMatch(s -> itemPriceMap.get(s.getItemId()) != im.getItem(s.getItemId()).getPrice())) {
			// 価格変動のメッセージを記録
			FacesContext.getCurrentInstance().getExternalContext().getFlash().put("FailedMessage", "価格が変動しました");

			return "purchasefailed";
		}
		// 以下、購入可能時に行われる処理
		am.updateUserMoney(user.getMoney() - getTotal());// 残高の更新
		for (Cart cart : cartList)// 在庫の更新
		{
			im.addStock(cart.getItemId(), -cart.getCount());
			sm.addSales(am.getCurrentUserAccount().getGlocommId(), cart.getCount(), cart.getItemId(),
					im.getItem(cart.getItemId()).getPrice());
		}

		// カートの中身の削除
		cm.removeCartList(am.getCurrentUserAccount().getGlocommId());

		return "purchasesucceed";
	}

	/*
	 * 確定ボタンを押したときにおこなうメソッド
	 */
	public void onClickSubmit() {
		// Todo:
	}
	/*
	 * //デバッグ用 public void debugTest() { List<Cart> cartList =
	 * cm.getCartList(user.getGlocommId()); for(Cart cart:cartList) { Item item
	 * = im.getItem(cart.getItemId()); im.addStock(item.getId(),
	 * 1-item.getStock()); }
	 * 
	 * }
	 */
}
