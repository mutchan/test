package com.fujitsu.soft.rad.devsemi.manager;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.transaction.HeuristicMixedException;
import javax.transaction.HeuristicRollbackException;
import javax.transaction.NotSupportedException;
import javax.transaction.RollbackException;
import javax.transaction.SystemException;
import javax.transaction.UserTransaction;

import com.fujitsu.soft.rad.devsemi.entity.Avatar;

/**
 * アバターDBへのアクセス
 * 
 * @author Hiradate, Mutsuki
 *
 */
public class AvatarManager implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 969461945090265735L;

	EntityManager em;
	UserTransaction utx;

	/**
	 * コンストラクタ
	 * 
	 * @param em
	 *            エンティティマネージャ
	 * @param utx
	 *            ユーザートランザクション
	 */
	public AvatarManager(EntityManager em, UserTransaction utx) {
		this.em = em;
		this.utx = utx;
	}

	/**
	 * すべてのアバターの情報を取得
	 * 
	 * @return すべてのアバターのリスト
	 */
	public List<Avatar> getAvatarList() {
		try {
			return em.createNamedQuery(Avatar.FIND_ALL, Avatar.class).getResultList();
		} catch (NoResultException e) {
			return new ArrayList<Avatar>();
		}
	}

	/**
	 * 指定したIDのアバター情報を取得
	 * 
	 * @param avatarId
	 *            アバターのID
	 * @return アバター情報
	 */
	public Avatar getAvatar(int avatarId) {
		try {
			return em.createNamedQuery(Avatar.BY_ID, Avatar.class).setParameter("id", avatarId).getSingleResult();
		} catch (NoResultException e) {
			return null;
		}
	}

	/**
	 * アバターの削除
	 * 
	 * @param avatar
	 *            追加するカート
	 */
	public void removeAvatar(Avatar avatar) {
		try {
			utx.begin();
			em.remove(avatar);
			utx.commit();
		} catch (NotSupportedException | SystemException | SecurityException | IllegalStateException | RollbackException
				| HeuristicMixedException | HeuristicRollbackException e) {
			e.printStackTrace();

			try {
				utx.rollback();
			} catch (IllegalStateException | SecurityException | SystemException e1) {
				e1.printStackTrace();
			}
		}
	}
}
