//Copyright FUJITSU LIMITED 2016

package com.fujitsu.soft.rad.devsemi.user;

import java.io.Serializable;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.enterprise.context.RequestScoped;
import javax.faces.context.FacesContext;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.UserTransaction;

import com.fujitsu.soft.rad.devsemi.entity.UserAccount;
import com.fujitsu.soft.rad.devsemi.manager.AccountManager;
//import com.fujitsu.soft.rad.devsemi.manager.CartManager;
//import com.fujitsu.soft.rad.devsemi.manager.ItemManager;
//import com.fujitsu.soft.rad.devsemi.manager.ReviewManager;

/**
 * 購入完了の豆です．残高を表すフィールドがあるだけです．
 * 
 * @author Omishima, Senchi(G03)
 */
@Named
@RequestScoped
public class PurchaseSucceedBean implements Serializable {

	@PersistenceContext(unitName = "Numazon")
	private EntityManager em;
	@Resource
	UserTransaction utx;
	
	private static final long serialVersionUID = 155901101976094195L;	
	private int balance;//残高
	private UserAccount user; // 自分のユーザーアカウント
	private AccountManager am;
	

	
	/**
	 * 初期化
	 */
	@PostConstruct
	public void init() {
		am = new AccountManager(em,utx);
		user = am.getCurrentUserAccount();
	}
	
	
	/**
	 * 購入完了後の残高の取得
	 * @return 購入完了後の残高
	 */
	public int getBalance() {
		return balance;
	}
	
	/**
	 * 購入完了後のメッセージを出すメソッド
	 */
	public String getMessage() {
		return "残高は" + user.getMoney() + "円です。";
	}

	/**
	 * 購入完了後のメッセージを出すメソッド
	 */
	public String getFailedMessage() {
		Object obj = FacesContext.getCurrentInstance().getExternalContext().getFlash().get("FailedMessage");
		if(obj == null){
			return "予期せぬエラーです";
		}
		return obj.toString();
	}
}
