/** ItemManagerと不仲な状態です．この状態では全く動きません． **/

package com.fujitsu.soft.rad.devsemi.user;

import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.enterprise.context.RequestScoped;
import javax.faces.context.FacesContext;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.ServletContext;
import javax.transaction.UserTransaction;

import com.fujitsu.soft.rad.devsemi.entity.Item;
import com.fujitsu.soft.rad.devsemi.entity.Review;
import com.fujitsu.soft.rad.devsemi.manager.*;
import com.fujitsu.soft.rad.devsemi.seller.PublicStat;

/**
 * 商品一覧のページのBean htmlと連携しやすいように大幅に変更してしまいました(6/30, Omishima)
 * 
 * @auther Okano Naoki (6/28)
 */

@SuppressWarnings("serial")
@Named
@RequestScoped
public class ListBean implements Serializable {
	@PersistenceContext(unitName = "Numazon")
	private EntityManager em;

	@Resource
	UserTransaction utx;

	private List<Item> itemList;
	private List<List<Item>> dividedItemList;

	/* getItemListとgetDividedItemListのめんどうな処理を1度で済ますためのフラグです． */
	private boolean generated;
	private boolean generatedDivided;

	private String keyword;
	private boolean recommend;
	private String sortByPrice; /* 価格ソート */
	private String sortByRelease; /* 発売日ソート */
	private String sortByStar;

	private ItemManager im;
	private ReviewManager rm;

	/**
	 * 初期化
	 */
	@PostConstruct
	public void init() {

		im = new ItemManager(em, utx);
		rm = new ReviewManager(em, utx);
	}

	public ListBean() {
		generated = false;
		generatedDivided = false;
		recommend = true; /* デフォルトはtrueで評価の高いものしか表示しません． */
	}

	@PostConstruct
	public void setRecommend(boolean recommend) {
		this.recommend = recommend;
	}

	public boolean getRecommend() {
		return recommend;
	}

	@PostConstruct
	public void setSortByStar(String sortByStar) {
		this.sortByStar = sortByStar;
	}

	public String getSortByStar() {
		return sortByStar;
	}

	@PostConstruct
	public void setSortByPrice(String sortByPrice) {
		this.sortByPrice = sortByPrice;
	}

	public String getSortByPrice() {
		return sortByPrice;
	}

	@PostConstruct
	public void setSortByRelease(String sortByRelease) {
		this.sortByRelease = sortByRelease;
	}

	public String getSortByRelease() {
		return sortByRelease;
	}

	@PostConstruct
	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}

	public String getKeyword() {
		return keyword;
	}

	public List<Item> getItemList() {
		if (generated) {
			return itemList;
		} else {
			/* キーワードで選別します． */
			if (keyword == null || keyword.length() == 0) {
				itemList = im.getAllItemList();
			} else {
				itemList = im.getItemListContains(keyword);
			}
			/* 公開設定がPUBLICなものだけを選びます． */
			List<Item> visible = new ArrayList<Item>();
			while (!itemList.isEmpty()) {
				if (itemList.get(0).getPublicStat() == PublicStat.PUBLIC) {
					visible.add(itemList.get(0));
				}
				itemList.remove(0);
			}
			itemList = visible;

			/* レビューの日時順に並び替えます． */
			if (itemList == null || itemList.size() == 0) {
			} else {
				Collections.sort(itemList, new java.util.Comparator<Item>() {
					public int compare(Item a, Item b) {
						Date d1, d2;
						List<Review> list1 = rm.getReviewListByItemId(a.getId());
						if (list1 == null || list1.size() == 0) {
							d1 = new Date(0);
						} else {
							Collections.sort(list1, new java.util.Comparator<Review>() {
								public int compare(Review x, Review y) {
									return x.getDate().compareTo(y.getDate());
								}
							});
							d1 = list1.get(list1.size() - 1).getDate();
						}
						List<Review> list2 = rm.getReviewListByItemId(b.getId());
						if (list2 == null || list2.size() == 0) {
							d2 = new Date(0);
						} else {
							Collections.sort(list2, new java.util.Comparator<Review>() {
								public int compare(Review x, Review y) {
									return x.getDate().compareTo(y.getDate());
								}
							});
							d2 = list2.get(list2.size() - 1).getDate();
						}
						return d2.compareTo(d1);
					}
				});
			}
			/* 並び替えました． */
			/* 4未満をrecommendがtrueならはじく */
			if (recommend) {
				List<Item> filtered = new ArrayList<Item>();
				while (!itemList.isEmpty()) {
					if (itemList.get(0).getAverageStar() >= 4) {
						filtered.add(itemList.get(0));
					}
					itemList.remove(0);
				}
				itemList = filtered;
			}

			/* はじきました． */
			/* 価格ソート */
			if (sortByPrice == null) {
			} else {
				if (sortByPrice.equals("ascending")) {
					Collections.sort(itemList, new java.util.Comparator<Item>() {
						public int compare(Item a, Item b) {
							return a.getPrice() - b.getPrice();
						}
					});
				}
				if (sortByPrice.equals("descending")) {
					Collections.sort(itemList, new java.util.Comparator<Item>() {
						public int compare(Item a, Item b) {
							return b.getPrice() - a.getPrice();
						}
					});
				}
			}
			/* 価格ソート終 */
			/* 発売日ソート */
			if (sortByRelease == null) {
			} else {
				if (sortByRelease.equals("ascending")) {
					Collections.sort(itemList, new java.util.Comparator<Item>() {
						public int compare(Item a, Item b) {
							return a.getRegistDate().compareTo(b.getRegistDate());
						}
					});
				}
				if (sortByRelease.equals("descending")) {
					Collections.sort(itemList, new java.util.Comparator<Item>() {
						public int compare(Item a, Item b) {
							return b.getRegistDate().compareTo(a.getRegistDate());
						}
					});
				}
			}
			/* 発売日ソート終わり */
			/* 星ソート */
			if (sortByStar == null) {
			} else {
				if (sortByStar.equals("ascending")) {
					Collections.sort(itemList, new java.util.Comparator<Item>() {
						public int compare(Item a, Item b) {
							return (int) ((a.getAverageStar() - b.getAverageStar()) * 100);
						}
					});
				}
				if (sortByStar.equals("descending")) {
					Collections.sort(itemList, new java.util.Comparator<Item>() {
						public int compare(Item a, Item b) {
							return (int) ((b.getAverageStar() - a.getAverageStar()) * 100);
						}
					});
				}
			}
			/* 星ソートおしまい */

			generated = true;
			return itemList;
		}
	}

	/*
	 * xhtmlのほうの商品表示の条件を記述するのがダルいので，
	 * beanのほうでgetItemListをさらに分割させて，それを受け取って表示するようにしてます．
	 */
	public List<List<Item>> getDividedItemList() {
		if (generatedDivided) {
			return dividedItemList;
		} else {
			List<Item> copy = copy(getItemList());
			if (copy.size() < 4) {
				List<List<Item>> out = new ArrayList<List<Item>>();
				out.add(copy);
				dividedItemList = out;
			} else {
				List<List<Item>> out = new ArrayList<List<Item>>();
				List<Item> row1 = new ArrayList<Item>();
				for (int i = 0; i < 3; i++) {
					row1.add(copy.get(0));
					copy.remove(0);
				}
				out.add(row1);
				while (copy.size() >= 4) {
					List<Item> row = new ArrayList<Item>();
					for (int i = 0; i < 4; i++) {
						row.add(copy.get(0));
						copy.remove(0);
					}
					out.add(row);
				}
				if (copy.size() != 0) {
					out.add(copy);
				}
				dividedItemList = out;
			}
			generatedDivided = true;
			return dividedItemList;
		}
	}

	public List<Item> copy(List<Item> list) {
		List<Item> copy = new ArrayList<Item>();
		for (int i = 0; i < list.size(); i++) {
			copy.add(list.get(i));
		}
		return copy;
	}

	/**
	 * 指定されたidの商品に登録されているパスに画像が存在するか確認して
	 * なければ　no imageを返すメソッドです
	 * 
	 * @param id
	 * @return current path
	 */
	public String getCurrentImagePath(int id) {
		Item item = im.getItem(id);
		if (item != null) {
			// String imagepath = item.getImagePath();
			String imagename = item.getImagePath();
			String imagepath = "product/item-img";
			int lastpos = imagename.lastIndexOf("/");
			if (lastpos != -1) {
				imagename = imagename.substring(lastpos + 1);
				System.out.println("DEBUG:" + imagename + "," + id + "," + getRealPath(imagepath));
				File imageFile = new File(getRealPath(imagepath), imagename);
				System.out.println(imagename);
				if (imageFile.exists()) {
					return imageFile.getPath();
				} else {
					return "/product/item-img/no_picture.JPG";
				}

			}
		}
		return "/product/item-img/no_picture.JPG";

	}

	/**
	 * 相対パスを絶対パスに変えるメソッドです
	 * 
	 * @param path
	 *            相対パス
	 * @return 絶対パス
	 */
	public String getRealPath(String path) {
		ServletContext ct = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
		return ct.getRealPath(path);
	}
}