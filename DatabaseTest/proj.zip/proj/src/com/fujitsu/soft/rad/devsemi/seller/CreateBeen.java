package com.fujitsu.soft.rad.devsemi.seller;

import java.io.IOException;
import java.io.Serializable;
import java.nio.file.Files;
import java.io.*;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.enterprise.context.RequestScoped;
import javax.faces.context.FacesContext;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.Part;
import javax.transaction.UserTransaction;

import org.hibernate.validator.constraints.NotEmpty;

import com.fujitsu.soft.rad.devsemi.manager.ItemManager;

import javax.servlet.ServletContext;

/**
 * @author Hiradate, Mutsuki, Ishimatsu
 *
 */
@Named
@RequestScoped
public class CreateBeen implements Serializable {

	@PersistenceContext(unitName = "Numazon")
	private EntityManager em;

	@Resource
	private UserTransaction utx;

	/**
	 * 
	 */
	private static final long serialVersionUID = 1978891714396809992L;

	private PublicStat openInfo;
	private String name;
	private String desc;
	private Category category;
	private int count;
	private Part file;

	/**
	 * 
	 */
	@PostConstruct
	public void init() {
		count = 0;
		category = Category.A;
	}

	/**
	 * @return openInfo
	 */
	public PublicStat getOpenInfo() {
		return openInfo;
	}

	/**
	 * @param openInfo
	 *            セットする openInfo
	 */
	public void setOpenInfo(PublicStat openInfo) {
		this.openInfo = openInfo;
	}

	/**
	 * 公開のリストの取得
	 * 
	 * @return 公開のリスト
	 */
	public PublicStat[] getOpenInfoList() {
		return PublicStat.values();
	}

	/**
	 * @return name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name
	 *            セットする name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return desc
	 */
	public String getDesc() {
		return desc;
	}

	/**
	 * @param desc
	 *            セットする desc
	 */
	public void setDesc(String desc) {
		this.desc = desc;
	}

	/**
	 * @return file
	 */
	public Part getFile() {
		return file;
	}

	/**
	 * @param file
	 *            セットする file
	 */
	public void setFile(Part file) {
		this.file = file;
	}

	/**
	 * @return category
	 */
	public Category getCategory() {
		return category;
	}

	/**
	 * @param category
	 *            セットする category
	 */
	public void setCategory(Category category) {
		this.category = category;
	}

	/**
	 * 商品カテゴリのリストの取得
	 * 
	 * @return 商品カテゴリのリスト
	 */
	public Category[] getCategoryList() {
		return Category.values();
	}

	/**
	 * @return count
	 */
	public int getCount() {
		return category.getInitStock();
	}

	/**
	 * @param count
	 *            セットする count
	 */
	public void setCount(int count) {
		this.count = count;
	}

	/**
	 * 
	 * @return null
	 */
	public String regist() {
		//ファイルがなかったときの処理
		uploadFile();
		ItemManager im = new ItemManager(em, utx);
		
		int id = im.addItem(desc, name, category, openInfo, "product/item-img/" + file.getSubmittedFileName());
		im.updateItem(id, desc, name, category, openInfo, "/product/item-img/" + changeFilename(id));
		System.out.println("DEBUG[REGIST]:"+id+","+desc+","+name+","+category+","+openInfo+","+im.getItem(id).getImagePath()+",");
		return "productCreate";
	}

	/**
	 * ファイルをサーバーにアップロード
	 */
	public void uploadFile() {
		try {
			String filepath = getRealPath("product/item-img");
			String filename = file.getSubmittedFileName();
			Files.copy(file.getInputStream(), new File(filepath, filename).toPath());
		} catch (IOException e) {
			System.out.println("失敗！！！");
		}
	}

	/**
	 * アップロードしたファイルの名前をitem(id)にrename
	 * 
	 * @param id
	 * @return 新しいファイル名
	 */

	public String changeFilename(int id) {
		String path = "product/item-img";
		String srcname = file.getSubmittedFileName();

		int dotpos = srcname.indexOf(".");
		String itemname = "item" + Integer.toString(id);
		if (dotpos != -1) {
			itemname = itemname + srcname.substring(dotpos);
		}

		File srcimage = new File(getRealPath(path), srcname);
		File itemimage = new File(getRealPath(path), itemname);

		if (srcimage.isFile() && srcimage.renameTo(itemimage)) {
			System.out.println("complete");
			return itemname;
		} else {
			System.out.println("rename failed");
			return srcname;
		}
	}

	/**
	 * 相対パスを絶対パスに変えるメソッドです
	 * 
	 * @param path
	 *            相対パス
	 * @return 絶対パス
	 */
	public String getRealPath(String path) {
		ServletContext ct = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
		return ct.getRealPath(path);
	}
}
