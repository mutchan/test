package com.fujitsu.soft.rad.devsemi.manager;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.faces.context.FacesContext;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.transaction.HeuristicMixedException;
import javax.transaction.HeuristicRollbackException;
import javax.transaction.NotSupportedException;
import javax.transaction.RollbackException;
import javax.transaction.SystemException;
import javax.transaction.UserTransaction;

import com.fujitsu.soft.rad.devsemi.entity.Cart;

/**
 * カートの中身のDBにアクセスするクラス
 * 
 * @author Hiradate, Mutsuki
 *
 */
public class CartManager {
	EntityManager em;
	UserTransaction utx;

	/**
	 * コンストラクタ
	 * 
	 * @param em
	 *            エンティティマネージャ
	 * @param utx
	 *            ユーザートランザクション
	 */
	public CartManager(EntityManager em, UserTransaction utx) {
		this.em = em;
		this.utx = utx;
	}

	/**
	 * 指定したIDのカートの中身を取得
	 * 
	 * @param glocommId
	 *            ユーザーのID
	 * @return カートの中身のリスト
	 */
	public List<Cart> getCartList(String glocommId) {
		try {
			return em.createNamedQuery(Cart.BY_GLOCOMM_ID, Cart.class).setParameter("glocommId", glocommId)
					.getResultList();
		} catch (NoResultException e) {
			return new ArrayList<Cart>();
		}
	}

	/**
	 * 指定したIDのカートの中身を削除
	 * 
	 * @param glocommId
	 *            ユーザーのID
	 */
	public void removeCartList(String glocommId) {
		try {
			utx.begin();
			List<Cart> cart = getCartList(glocommId);
			cart.stream().forEach(em::remove);
			utx.commit();
		} catch (NotSupportedException | SystemException | SecurityException | IllegalStateException | RollbackException
				| HeuristicMixedException | HeuristicRollbackException e) {
			e.printStackTrace();

			try {
				utx.rollback();
			} catch (IllegalStateException | SecurityException | SystemException e1) {
				e1.printStackTrace();
			}
		}
	}

	/**
	 * カートの追加
	 * 
	 * @param accountId
	 *            グロコミID
	 * @param itemId
	 *            商品ID
	 * @param count
	 *            カート内の個数
	 */
	public void addCartItem(String accountId, int itemId, int count) {
		try {
			utx.begin();
			Cart cart = new Cart();
			cart.setAccountId(accountId);
			cart.setItemId(itemId);
			cart.setCount(count);
			em.persist(cart);
			utx.commit();
		} catch (NotSupportedException | SystemException | SecurityException | IllegalStateException | RollbackException
				| HeuristicMixedException | HeuristicRollbackException e) {
			e.printStackTrace();

			try {
				utx.rollback();
			} catch (IllegalStateException | SecurityException | SystemException e1) {
				e1.printStackTrace();
			}
		}
	}

	/**
	 * カートの追加
	 * 
	 * @param cart
	 *            追加するカート
	 */
	public void addCart(Cart cart) {
		try {
			utx.begin();
			em.persist(cart);
			utx.commit();
		} catch (NotSupportedException | SystemException | SecurityException | IllegalStateException | RollbackException
				| HeuristicMixedException | HeuristicRollbackException e) {
			e.printStackTrace();

			try {
				utx.rollback();
			} catch (IllegalStateException | SecurityException | SystemException e1) {
				e1.printStackTrace();
			}
		}
	}

	/**
	 * カート情報の削除
	 * 
	 * @param cartId
	 *            削除するカート情報のID
	 */
	public void removeCart(int cartId) {
		try {
			utx.begin();
			em.remove(getCart(cartId));
			utx.commit();
		} catch (NotSupportedException | SystemException | SecurityException | IllegalStateException | RollbackException
				| HeuristicMixedException | HeuristicRollbackException e) {
			e.printStackTrace();

			try {
				utx.rollback();
			} catch (IllegalStateException | SecurityException | SystemException e1) {
				e1.printStackTrace();
			}
		}
	}

	/**
	 * カート内の商品の個数の更新
	 * 
	 * @param cartId
	 *            更新するカートのID
	 * @param count
	 *            更新後のカート内の商品の個数
	 */
	public void updateCartCount(int cartId, int count) {
		try {
			utx.begin();
			Cart cart = getCart(cartId);
			cart.setCount(count);
			utx.commit();
		} catch (NotSupportedException | SystemException | SecurityException | IllegalStateException | RollbackException
				| HeuristicMixedException | HeuristicRollbackException e) {
			e.printStackTrace();

			try {
				utx.rollback();
			} catch (IllegalStateException | SecurityException | SystemException e1) {
				e1.printStackTrace();
			}
		}
	}
	
	/**
	 * グロコミIDの価格変動チェック前に保存しておくメソッド
	 * @param glocommId
	 */
	public void saveCartPrice(String glocommId)
	{
		ItemManager im = new ItemManager(em,utx);
		List<Cart> cartlist = getCartList(glocommId);
		Map<Integer,Integer> cartmap = cartlist.stream().collect(Collectors.toMap(c->c.getItemId(),
				c -> im.getItem(c.getItemId()).getPrice()));
		FacesContext.getCurrentInstance().getExternalContext().getSessionMap().put("Cart",cartmap); 
		System.out.println("DEBUG:saveCartPrice");
				
				//map(c->im.getItem(c.getItemId()).getPrice()).collect(Collectors.toList()));
	}
	/**
	 * グロコミIDの価格変動をチェックします。
	 * @param glocommId
	 * @return
	 */
	public boolean checkCartPrice(String glocommId)
	{
		boolean ret = true;
		ItemManager im = new ItemManager(em,utx);
		List<Cart> cartlist = getCartList(glocommId);
		Object checklist = FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("Cart");
		if(checklist instanceof Map)
		{
			if(((Map)checklist).keySet().isEmpty())
			{
				ret=false;
			}else{
				for(Object obj : ((Map)checklist).keySet())
				{
					ret = (obj instanceof Integer);
					break;
				}
			}
			for(Cart cart : cartlist)
			{
				ret = ret && ((Map<Integer,Integer>)checklist).get(cart.getItemId()) ==  im.getItem(cart.getItemId()).getPrice();
				System.out.println("DEBUG cartid:"+cart.getItemId()+", checkprice"+((Map<Integer,Integer>)checklist).get(cart.getItemId())+",checklist price"+im.getItem(cart.getItemId()).getPrice());
				//cart.getItemId()
			}
		}
		return ret;
	}
	
	/**
	 * カートIDからカートの中身を取得
	 * 
	 * @param cartId
	 * @return
	 */
	private Cart getCart(int cartId) {
		try {
			return em.createNamedQuery(Cart.BY_ID, Cart.class).setParameter("id", cartId).getSingleResult();
		} catch (NoResultException e) {
			throw new IllegalArgumentException("存在しないカートID \"" + cartId + "\" が指定されました");
		}
	}
}
