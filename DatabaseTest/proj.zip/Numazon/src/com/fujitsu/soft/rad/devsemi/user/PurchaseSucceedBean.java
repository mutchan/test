//Copyright FUJITSU LIMITED 2016

package com.fujitsu.soft.rad.devsemi.user;

import java.io.Serializable;

import javax.enterprise.context.RequestScoped;
import javax.inject.Named;

/**
 * 購入完了の豆です．残高を表すフィールドがあるだけです．
 * 
 * @author Omishima, Senchi(G03)
 */
@Named
@RequestScoped
public class PurchaseSucceedBean implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 155901101976094195L;
	
	private int balance;

	/**
	 * 購入完了後の残高の取得
	 * @return 購入完了後の残高
	 */
	public int getBalance() {
		return balance;
	}
}
