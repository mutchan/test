// Copyright(c) FUJITSU lIMITED
package com.fujitsu.soft.rad.devsemi.user;

import java.util.List;
import java.util.stream.Collectors;
import java.io.Serializable;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.UserTransaction;

import org.primefaces.event.SelectEvent;
import org.primefaces.event.UnselectEvent;

import com.fujitsu.soft.rad.devsemi.entity.Avatar;
import com.fujitsu.soft.rad.devsemi.entity.UserAccount;
import com.fujitsu.soft.rad.devsemi.manager.AccountManager;
import com.fujitsu.soft.rad.devsemi.manager.AvatarManager;
import com.fujitsu.soft.rad.devsemi.entity.PreservedAvatar;

/**
 * 
 * @author Kagajo Mitsuru
 *
 */
@ManagedBean
@ViewScoped // ポイントの交換ボタンのクリックを行えるかどうかの計算が初期化されるためRequestScopedにしない
public class PointBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5617182325445023224L;

	@PersistenceContext(unitName = "Numazon")
	private EntityManager em;

	@Resource
	UserTransaction utx;

	// 一覧データ
	private List<Avatar> avatarList;

	private List<Avatar> selectedAvatarList; // 選択されたアバターリスト
	private List<PreservedAvatar> preservedAvatarList; // アバターの交換履歴

	private int predictPoint;
	private int currentPoint;

	AvatarManager avm;
	AccountManager acm;
	UserAccount account;

	/**
	 * 初期化
	 */
	@PostConstruct
	public void init() {
		// マネージャの初期化
		avm = new AvatarManager(em, utx);
		acm = new AccountManager(em, utx);

		// TODO:テスト用のログインを削除
		acm.userLogin("user7", "pass");

		// 表示情報の更新
		updateData();
	}

	/**
	 * 表示する条項の更新
	 */
	private void updateData() {
		// ログイン中のアカウント情報の取得
		account = acm.getCurrentUserAccount();
		predictPoint = account.getPoint();
		currentPoint = account.getPoint();

		// 所持アバターを取得
		preservedAvatarList = acm.getPreservedAvatar(account.getGlocommId());
		preservedAvatarList.sort((a1, a2) -> a2.getDate().compareTo(a1.getDate()));

		// 表示データ取得
		List<Integer> list = preservedAvatarList.stream().map(s -> s.getAvatar().getId()).collect(Collectors.toList());
		avatarList = avm.getAvatarList().stream().filter(s -> !list.contains(s.getId())).collect(Collectors.toList());
	}

	/**
	 * @return avatarList
	 */
	public List<Avatar> getAvatarList() {
		return avatarList;
	}

	/**
	 * @param selectedAvatarList
	 *            チェックボックスで選択されたアバターのリスト
	 */
	public void setSelectedAvatarList(List<Avatar> selectedAvatarList) {
		this.selectedAvatarList = selectedAvatarList;
	}

	/**
	 * 
	 * @return チェックボックスで選択されたアバターのリスト
	 */
	public List<Avatar> getSelectedAvatarList() {
		return selectedAvatarList;
	}

	/**
	 * 交換したアバターのリストを取得
	 * 
	 * @return 交換したアバターのリスト
	 */
	public List<PreservedAvatar> getAvatarExchangeList() {
		return preservedAvatarList;
	}

	/**
	 * 
	 * @return 所持Ypを取得
	 */
	public int getCurrentPoint() {
		return currentPoint;
	}

	/**
	 * 
	 * @return アバター交換後の残高
	 */
	public int getPredictPoint() {
		return predictPoint;
	}

	/**
	 * "交換するが"押されたときに実行。 predictYpが0より大きいとき、アバター交換可能。
	 */
	public void onClickExchange() {
		if (predictPoint > 0) {
			// アバターの交換
			acm.exchangeAvatar(selectedAvatarList);

			// 表示情報の更新
			updateData();

			// 選択中のリストをクリア
			selectedAvatarList.clear();
		}
	}

	/**
	 * 
	 * 残りポイントによってボタンに表示する文字列を変更
	 * 
	 * @return ボタンに表示する文字列
	 */
	public String getExchangeString() {
		if (predictPoint == currentPoint) {
			return "商品を選択してください";
		} else if (predictPoint < 0) {
			return "ポイントが足りません";
		} else {
			return "交換する";
		}
	}

	/**
	 * 残りポイントの計算
	 */
	private void calcPredictPoint() {
		predictPoint = currentPoint;
		if (selectedAvatarList != null) {
			for (Avatar avatar : selectedAvatarList) {
				predictPoint -= avatar.getPoint();
			}
		}
	}

	/**
	 * 行を選択したときのイベント
	 * 
	 * @param event
	 *            イベント
	 */
	public void onRowSelect(SelectEvent event) {
		calcPredictPoint();
	}

	/**
	 * 行の選択を解除したときのイベント
	 * 
	 * @param event
	 *            イベント
	 */
	public void onRowUnselect(UnselectEvent event) {
		calcPredictPoint();
	}
}
