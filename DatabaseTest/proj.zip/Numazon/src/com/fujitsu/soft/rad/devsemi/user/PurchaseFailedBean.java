package com.fujitsu.soft.rad.devsemi.user;

import java.io.Serializable;

/**
 * 購入不可画面にメッセージを出すBeanクラス
 * 
 * @auther Okano Naoki (6/28)
 */
public class PurchaseFailedBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3163695513776114890L;

	private String message;

	/**
	 * 購入失敗の理由を示すメッセージの取得
	 * 
	 * @return 購入失敗の理由を示すメッセージ
	 */
	public String getMessage() {
		return message;
	}
	// setterは使う予定はないので作っていません
}
