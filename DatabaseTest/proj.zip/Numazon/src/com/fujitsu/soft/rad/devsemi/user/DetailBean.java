package com.fujitsu.soft.rad.devsemi.user;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.faces.application.ConfigurableNavigationHandler;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.UserTransaction;

import com.fujitsu.soft.rad.devsemi.entity.Avatar;
import com.fujitsu.soft.rad.devsemi.entity.Cart;
import com.fujitsu.soft.rad.devsemi.entity.Item;
import com.fujitsu.soft.rad.devsemi.entity.Review;
import com.fujitsu.soft.rad.devsemi.manager.AccountManager;
import com.fujitsu.soft.rad.devsemi.manager.CartManager;
import com.fujitsu.soft.rad.devsemi.manager.ItemManager;
import com.fujitsu.soft.rad.devsemi.manager.ReviewManager;

/**
 * 各商品の詳細を出すクラス
 * 
 * @auther Okano Naoki (6/28)
 */
@ManagedBean
@ViewScoped
public class DetailBean implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -9065998059999462131L;

	@PersistenceContext(unitName = "Numazon")
	private EntityManager em;

	@Resource
	UserTransaction utx;

	private final boolean STUBTEST = false;

	// 表示する商品の情報
	private Item item;
	private int count = 1;
	private int itemID = 0; // htmlでこのitemIDをsetして、そのitemを表示させる

	// 投稿するレビュー
	private Review review; // レビュー
	private List<Avatar> avatarList; // 選択可能なアバターのリスト
	private Map<Integer, Avatar> avatarMap; // 選択可能なアバターとIDを紐づけるマップ

	// 投稿されたレビューの情報
	private List<Review> reviewList = new ArrayList<Review>(); // 商品のレビューのリスト
	private Map<String, String> accountNameMap; // グロコミIDとアカウント名を紐づけるマップ

	// DBアクセス用のマネージャー
	private AccountManager am;
	private ItemManager im;
	private ReviewManager rm;
	CartManager cm;

	/**
	 * 初期化
	 */
	@PostConstruct
	public void init() {
		// マネージャーの初期化
		am = new AccountManager(em, utx);
		im = new ItemManager(em, utx);
		rm = new ReviewManager(em, utx);
		cm = new CartManager(em, utx);

		// TODO: テスト用にログイン
		am.userLogin("user8", "pass");

		// 表示情報の初期化
		avatarList = am.getPreservedAvatar(am.getCurrentUserAccount().getGlocommId()).stream().map(s -> s.getAvatar())
				.distinct().collect(Collectors.toList());
		avatarMap = avatarList.stream().collect(Collectors.toMap(s -> s.getId(), s -> s));

		review = new Review();
		review.setAvatar(avatarList.get(0));

		if (STUBTEST) {
			// ReviewManagerStub rm = new ReviewManagerStub();
			// reviewList = rm.getItemReviewList(itemID);
		}
	}

	// ここからgetter,setter

	/**
	 * 商品IDの設定
	 * 
	 * @return 商品ID
	 */
	public int getItemId() {
		return this.itemID;
	}

	/**
	 * 商品IDの設定
	 * 
	 * @param itemId
	 *            商品ID
	 */
	public void setItemId(int itemId) {
		this.itemID = itemId;
		this.item = im.getItem(itemId);
		updateReviewList();
	}

	/**
	 * 商品の取得
	 * 
	 * @return 商品の情報
	 */
	public Item getItem() {
		return item;
	}

	/**
	 * 購入個数の取得
	 * 
	 * @return 購入個数
	 */
	public int getCount() {
		return count;
	}

	/**
	 * 購入個数の設定
	 * 
	 * @param count
	 *            購入個数
	 */
	public void setCount(int count) {
		this.count = count;
	}

	/**
	 * カートに追加を押したときにカートに追加するメソッド？
	 * 
	 * @return カートの確認への遷移
	 */
	public String onClickAddCart() {
		// カートマネージャを呼び出してカートに突っ込んでもらう。		
		Cart cart = new Cart();
		cart.setCount(count);
		cart.setItemId(itemID);
		cart.setAccountId(am.getCurrentUserAccount().getGlocommId());
		cm.addCart(cart);
		
		// どの商品をカートに追加したのかを記録
		FacesContext.getCurrentInstance().getExternalContext().getFlash().put("CartItemId", itemID);
		
		return "cart.xhtml";// Todo:htmlさんにがんばってもらう
	}

	/**
	 * 商品IDが存在しない場合にエラーページに遷移
	 */
	public void isExistItemId() {
		if (im.getItem(itemID) == null) {
			ConfigurableNavigationHandler handler = (ConfigurableNavigationHandler) FacesContext.getCurrentInstance()
					.getApplication().getNavigationHandler();
			handler.performNavigation("/user/notfound.xhtml");
		}
	}

	/**
	 * @return avatarId
	 */
	public int getAvatarId() {
		return review.getAvatar().getId();
	}

	/**
	 * @param avatarId
	 *            セットする avatarId
	 */
	public void setAvatarId(int avatarId) {
		review.setAvatar(avatarMap.get(avatarId));
	}

	/**
	 * レビューのリストを取得
	 * 
	 * @return レビューのリスト
	 */
	public List<Review> getReviewList() {
		return reviewList;
	}

	/**
	 * @return avatarList
	 */
	public List<Avatar> getAvatarList() {
		return avatarList;
	}

	/**
	 * @return avatarList
	 */
	public Map<Integer, Avatar> getAvatarMap() {
		return avatarMap;
	}

	/**
	 * @return review
	 */
	public Review getReview() {
		return this.review;
	}

	private void updateReviewList() {
		this.reviewList = rm.getReviewListByItemId(itemID);
		this.accountNameMap = am.getUserAccountList().stream()
				.collect(Collectors.toMap(s -> s.getGlocommId(), s -> s.getName()));
		// DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S");
		// this.reviewList.stream().forEach(s ->
		// System.out.println(format.format(s.getDate())));
	}

	/**
	 * 
	 * レビューするボタンをクリックして投稿するメソッド
	 * 
	 * @return 現在のページに留まる
	 *
	 */
	public String onClickReview() {
		review.setAccountId(am.getCurrentUserAccount().getGlocommId());
		review.setItemId(itemID);
		review.setGoodCount(0);
		review.setDate(new Date());

		Date date = new Date();
		DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S");
		System.out.println("SET:" + format.format(date));

		rm.postReview(review);

		review = new Review();
		review.setAvatar(avatarList.get(0));
		updateReviewList();

		return "#";
	}

	/**
	 * レビュー定型文のフレーズのgetter
	 * 
	 * @return 定型文リスト
	 */
	public List<String> getPhrase() {
		// Todo:htmlさんにがんばってもらう
		return null;
	}

	/**
	 * いいねをクリックしたときにいいねをするメソッド
	 * 
	 * @return null
	 */
	public String onClickGood() {
		int reviewId = Integer.parseInt(
				FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get("reviewId"));
		rm.addGoodCount(reviewId);
		updateReviewList();
		return "#";
	}

	/**
	 * @return accountNameMap
	 */
	public Map<String, String> getAccountNameMap() {
		return accountNameMap;
	}
}
