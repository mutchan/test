package com.fujitsu.soft.rad.devsemi.user;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.ValueChangeEvent;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.UserTransaction;

import com.fujitsu.soft.rad.devsemi.entity.Cart;
import com.fujitsu.soft.rad.devsemi.entity.Item;
import com.fujitsu.soft.rad.devsemi.entity.UserAccount;
import com.fujitsu.soft.rad.devsemi.manager.AccountManager;
import com.fujitsu.soft.rad.devsemi.manager.CartManager;
import com.fujitsu.soft.rad.devsemi.manager.ItemManager;

import java.io.Serializable;

/**
 * カートの確認ビーン
 * 
 * @author kudo jumma
 *
 */
@ManagedBean
@ViewScoped
public class CartBean implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -3519200839262987868L;

	@PersistenceContext(unitName = "Numazon")
	private EntityManager em;

	@Resource
	UserTransaction utx;

	private AccountManager am;
	private CartManager cm;
	private ItemManager im;

	private UserAccount account; // 自分のユーザーアカウント

	private int total; // カートの合計
	private List<Cart> cartList; // カートのリスト
	Map<Integer, Item> itemMap; // カートIDと商品とを紐づけるマップ

	private String message; // 「○○をカートに追加しました」メッセージ

	/**
	 * 初期化
	 */
	@PostConstruct
	public void init() {
		System.out.println("INIT");
		am = new AccountManager(em, utx);
		cm = new CartManager(em, utx);
		im = new ItemManager(em, utx);

		// TODO: テスト用にログイン
		am.userLogin("user8", "pass");

		account = am.getCurrentUserAccount();
		if (account != null) {
			// カートマネージャからカートリストを受け取る
			cartList = cm.getCartList(account.getGlocommId());

			// カートの商品を列挙
			itemMap = cartList.stream().collect(Collectors.toMap(s -> s.getId(), s -> im.getItem(s.getItemId())));
		} else {
			cartList = new ArrayList<Cart>();
		}

		// 商品ページからの遷移を確認
		// 遷移した時に商品在庫が0個でも「●●をカートに追加しました」と出るから、修正@嶋田
		Object obj = FacesContext.getCurrentInstance().getExternalContext().getFlash().get("CartItemId");
		// if (obj != null) {
		if (obj != null && cartList.stream().anyMatch(s -> im.getItem(s.getItemId()).getStock() > s.getCount())) {
			int itemId = (int) obj;
			message = im.getItem(itemId).getName() + "をカートに追加しました";
		}
	}

	public void updateCount(String strCartId) {
		// System.out.println("PhaseId" + e.getPhaseId());
		// System.out.println("OldValue" + e.getOldValue());
		// System.out.println("NewValue" + e.getNewValue());
		// System.out.println(e.getComponent().getId());
		 int cartId = Integer.parseInt(strCartId);
		 System.out.println(cartId);
		
		 int count = cartList.stream().filter(s -> s.getId() ==
		 cartId).findFirst().get().getCount();
		 System.out.println(count);
		
		 cm.updateCartCount(cartId, count);
	}

	/**
	 * カートの削除ボタンを押したときの処理
	 * 
	 * @return ページ遷移なし
	 */
	public String onClickRemove() {
		// 削除するカートのIDを取得
		int cartId = Integer.parseInt(
				FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get("cartId"));

		// CartのDBにアクセス
		cm.removeCart(cartId);

		// カート情報の更新
		cartList = cm.getCartList(account.getGlocommId());
		System.out.println("TEST:REMOVE");

		return "#";
	}

	/**
	 * 注文確認画面へ飛ぶ
	 * 
	 * @return 注文確認画面
	 */
	public String onClickConfirm() {
		cm.saveCartPrice(account.getGlocommId());
		System.out.println("click confirm"); // test用
		if (cartList.stream().anyMatch(s -> im.getItem(s.getItemId()).getStock() < s.getCount())) {
			// alert += "商品の在庫が足りません";
			return "purchasefailed";
		}

		// アカウントの残高と商品合計を照らし合わせてアラートを表示
		if (account.getMoney() < cartList.stream().mapToInt(s -> im.getItem(s.getItemId()).getPrice() * s.getCount())
				.sum()) {
			// alert += "残高が足りません";
			return "purchasefailed";
		}

		return "confirm";
	}

	/**
	 * cartの中見をマネージャに問い合わせて受け取り、返すメソッド
	 * 
	 * @return カートの中身
	 */
	public List<Cart> getCartList() {
		return cartList;
	}

	/**
	 * htmlで遷移するときに「○○をカートに追加しました」を入れる カートを確認して何もなかったら「カート内に商品がありません」をセットする
	 * 
	 * @return メッセージ
	 */
	public String getMessage() {
		if (cartList.size() == 0) {
			message = "カート内に商品がありません";
		}

		return message;

	}

	/**
	 * 商品とIDとを紐づけるマップの取得
	 * 
	 * @return 商品とIDとを紐づけるマップ
	 */
	public Map<Integer, Item> getItemMap() {
		return itemMap;
	}

	/**
	 * リストから合計を出す。getで計算する
	 * 
	 * @return the total
	 */
	public int getTotal() {
		total = cartList.stream().mapToInt(s -> itemMap.get(s.getId()).getPrice() * s.getCount()).sum();
		return (int) (total * 1.08); // 消費税8%つけて切り捨て
	}

	/**
	 * 
	 * 「商品の在庫がありません」、「商品の在庫が足りません」、「残高が足りません」をセットして出力
	 * プルダウンを押したときにアラートのゲットを走らせて、表示部で表示する。
	 * 
	 * @return the alert
	 */
	public String getAlert() {
		String alert = "";
		// カートに登録された商品の在庫が足りるかを確認、
		if (cartList.stream().anyMatch(s -> itemMap.get(s.getId()).getStock() < s.getCount())) {
			alert += "商品の在庫が足りません";
		}

		// アカウントの残高と商品合計を照らし合わせてアラートを表示
		if (account.getMoney() < getTotal()) {
			alert += "残高が足りません";
		}

		return alert;
	}

	/**
	 * 
	 * 「商品の在庫がありません」、「商品の在庫が足りません」、「残高が足りません」をセットして出力
	 * プルダウンを押したときにアラートのゲットを走らせて、表示部で表示する。
	 * 
	 * @return the alert
	 */
	public boolean getAlertBool() {
		// カートに登録された商品の在庫が足りるかを確認、
		if (cartList.stream().anyMatch(s -> itemMap.get(s.getId()).getStock() < s.getCount())) {
			return true;
		}

		// アカウントの残高と商品合計を照らし合わせてアラートを表示
		if (account.getMoney() < getTotal()) {
			return true;
		}

		return false;
	}
}
