package com.fujitsu.soft.rad.devsemi.entity;

import java.io.Serializable;
import java.lang.String;
import java.util.Date;
import javax.persistence.*;

/**
 * Entity implementation class for Entity: Sales
 *
 */
@SuppressWarnings("javadoc")
@Entity
@NamedQueries({ @NamedQuery(name = Sales.FIND_ALL, query = "Select s from Sales s"),
		@NamedQuery(name = Sales.BY_ID, query = "Select s from Sales s where s.id = :id"),
		@NamedQuery(name = Sales.BY_ACCOUNT, query = "Select s from Sales s where s.accountId = :id") })
public class Sales implements Serializable {

	public static final String FIND_ALL = "Sales.findAll";
	public static final String BY_ID = "Sales.findById";
	public static final String BY_ACCOUNT = "Sales.findByAccount";

	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	
	@Temporal(TemporalType.TIMESTAMP)
	private Date date;

	@Column(name = "ITEM_ID")
	private int itemId;
	private int count;

	@Column(name = "ACCOUNT_ID", length = 30)
	private String accountId;
	private int price;
	
	private static final long serialVersionUID = 1L;

	public Sales() {
		super();
	}   
	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}   
	public Date getDate() {
		return this.date;
	}

	public void setDate(Date date) {
		this.date = date;
	}   
	public int getItemId() {
		return this.itemId;
	}

	public void setItemId(int itemId) {
		this.itemId = itemId;
	}   
	public int getCount() {
		return this.count;
	}

	public void setCount(int count) {
		this.count = count;
	}   
	public String getAccountId() {
		return this.accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}   
	public int getPrice() {
		return this.price;
	}

	public void setPrice(int price) {
		this.price = price;
	}
   
}