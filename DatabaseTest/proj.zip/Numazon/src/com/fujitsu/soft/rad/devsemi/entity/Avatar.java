package com.fujitsu.soft.rad.devsemi.entity;

import java.io.Serializable;
import java.lang.String;
import javax.persistence.*;

/**
 * Entity implementation class for Entity: Avatar
 *
 */
@Entity
@NamedQueries({ @NamedQuery(name = Avatar.FIND_ALL, query = "Select c from Avatar c"),
		@NamedQuery(name = Avatar.BY_ID, query = "Select c from Avatar c where c.id = :id") })
public class Avatar implements Serializable {
	/**
	 * 全件取得
	 */
	public static final String FIND_ALL = "Avatar.findAll";
	/**
	 * IDによるサーチ
	 */
	public static final String BY_ID = "Avatar.findById";

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	@Column(name = "IMAGE_PATH")
	private String imagePath;
	private int point;
	private String name;
	private static final long serialVersionUID = 1L;

	/**
	 * コンストラクタ
	 */
	public Avatar() {
		super();
	}

	/**
	 * 
	 * アバターIDの取得
	 * 
	 * @return アバターID
	 */
	public int getId() {
		return this.id;
	}

	/**
	 * アバターIDの設定
	 * 
	 * @param id
	 *            アバターID
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * 画像パスの取得
	 * 
	 * @return 画像パス
	 */
	public String getImagePath() {
		return this.imagePath;
	}

	/**
	 * 画像パスの設定
	 * 
	 * @param imagePath
	 *            画像パス
	 */
	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}

	/**
	 * 交換に必要なポイントの取得
	 * 
	 * @return 交換に必要なポイント
	 */
	public int getPoint() {
		return this.point;
	}

	/**
	 * 交換に必要なポイントの設定
	 * 
	 * @param point
	 *            交換に必要なポイント
	 */
	public void setPoint(int point) {
		this.point = point;
	}

	/**
	 * 景品名の取得
	 * 
	 * @return 景品名
	 */
	public String getName() {
		return this.name;
	}

	/**
	 * 景品名の設定
	 * 
	 * @param name
	 *            景品名
	 */
	public void setName(String name) {
		this.name = name;
	}

}
