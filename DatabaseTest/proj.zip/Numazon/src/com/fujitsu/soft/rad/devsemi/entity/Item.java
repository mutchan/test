package com.fujitsu.soft.rad.devsemi.entity;

import java.io.Serializable;
import java.lang.String;
import java.util.Date;

import javax.annotation.Resource;
import javax.persistence.*;
import javax.transaction.UserTransaction;

import com.fujitsu.soft.rad.devsemi.seller.Category;
import com.fujitsu.soft.rad.devsemi.seller.PublicStat;

/**
 * Entity implementation class for Entity: Item
 *
 */
@SuppressWarnings("javadoc")
@Entity
@NamedQueries({ @NamedQuery(name = Item.FIND_ALL, query = "select i from Item i"),
		@NamedQuery(name = Item.BY_ID, query = "select i from Item i where i.id = :id"),
		@NamedQuery(name = Item.BY_CATEGORY, query = "select i from Item i where i.category = :category"),
		@NamedQuery(name = Item.BY_NAME, query = "select i from Item i where i.name like :name"),
		@NamedQuery(name = Item.BY_STAR_ORDER_DATE, query = "select i from Item i where i.averageStar >= 4 order by i.lastEdit asc") })
public class Item implements Serializable {

	public static final String FIND_ALL = "Item.findAll";
	public static final String BY_ID = "Item.findById";
	public static final String BY_CATEGORY = "Item.findByCategoryId";
	public static final String BY_NAME = "Item.findByName";
	public static final String BY_STAR_ORDER_DATE = "Item.findByStarOrderStar";

	@Id
	@GeneratedValue
	private int id;
	private String name;
	private String description;
	private int stock;
	@Column(name = "AVERAGE_STAR")
	private double averageStar;
	@Column(name = "IMAGE_PATH")
	private String imagePath;
	@Enumerated(EnumType.ORDINAL)
	private Category category;
	@Enumerated(EnumType.ORDINAL)
	@Column(name = "PUBLIC_STAT")
	private PublicStat publicStat;
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "LAST_EDIT")
	private Date lastEdit;
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "REGIST_DATE")
	private Date registDate;

	private static final long serialVersionUID = 1L;

	public Item() {
		super();
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDesc() {
		return this.description;
	}

	public void setDesc(String description) {
		this.description = description;
	}

	public int getStock() {
		return this.stock;
	}

	public void setStock(int stock) {
		this.stock = stock;
	}

	public double getAverageStar() {
		return this.averageStar;
	}

	public void setAverageStar(double averageStar) {
		this.averageStar = averageStar;
	}

	public String getImagePath() {
		return this.imagePath;
	}

	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}

	public Category getCategory() {
		return this.category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public PublicStat getPublicStat() {
		return this.publicStat;
	}

	public void setPublicStat(PublicStat publicStat) {
		this.publicStat = publicStat;
	}

	public Date getLastEdit() {
		return lastEdit;
	}

	public void setLastEdit(Date lastEdit) {
		this.lastEdit = lastEdit;

	}

	public Date getRegistDate() {
		return registDate;
	}

	public void setRegistDate(Date registDate) {
		this.registDate = registDate;

	}
	/*
	 * 商品の値段を返すメソッド
	 * 在庫の仕様について(配布された資料のWebショップ機能仕様書を参照)
	 * A:初期在庫 100 初期単価 10,000円(在庫が10減る毎に単価 +10,000円,在庫が10増える毎に単価 -10,000円)
	 * B:初期在庫 10,000  初期単価 5,000円(在庫が1000減る毎に単価 +1,000円,在庫が1000増える毎に単価 -1,000円)
	 * C:初期在庫 100,000 初期単価 100円(在庫が1000減る毎に単価 +100円,在庫が1000増える毎に単価 -100円)
	 * 独自設定⇒在庫の上限：初期在庫の5倍、単価の下限：初期単価
	 */
	public int getPrice() {
		switch (category) {
		case A:
			if(this.stock >= 100){
				return 10_000;//初期単価を返す
			}
			else{
				return 10_000 + 10_000*((100-this.stock)/10);
			}
			
		case B:
			if(this.stock>=10_000){
				return 5_000;//初期単価を返す
			}
			else{
				return 5_000 + 1_000*((10_000-this.stock)/1_000);
			}
			
		case C:
			if(this.stock>=100_000){
				return 100;//初期単価を返す
			}
			else{
				return 100 + 100*((100_000-this.stock)/1_000);
			}
			
		default:
			throw new IllegalArgumentException();
		}
	}
	
	/*
	 * カテゴリーから在庫の上限を返すメソッド(A:初期在庫 100,B:初期在庫 10,000,C:初期在庫 100,000)
	 * 今回の仕様は在庫の上限：初期在庫の5倍
	 */
	public int getMaxStock(){
		switch (category) {
		case A:
			return 500;
			
		case B:
			return 50_000;
			
		case C:
			return 500_000;
			
		default:
			throw new IllegalArgumentException();
		}
	}
	

	public String getPublicStatString() {
		switch (publicStat) {
		case PRIVATE:
			return "非公開";
		case PUBLIC:
			return "公開";
		default:
			throw new IllegalArgumentException();
		}
	}
	
}
