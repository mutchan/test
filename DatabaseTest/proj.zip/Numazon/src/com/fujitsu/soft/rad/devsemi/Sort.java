package com.fujitsu.soft.rad.devsemi;

import java.util.List;

//import com.fujitsu.soft.rad.devsemi.entity.Item;
import com.fujitsu.soft.rad.devsemi.entity.Review;
import com.fujitsu.soft.rad.devsemi.entity.UserAccount;

/**
 * ソートの実行
 * 
 * @author Mu
 *
 */
public class Sort {
	/**
	 * 日時による比較
	 * 
	 * @param reviewlist
	 *            レビューのリスト
	 */
	public static void sortReviewByDate(List<Review> reviewlist) {
		reviewlist.sort((c1, c2) -> c2.getDate().compareTo(c1.getDate()));
	}

	/**
	 * 星の数によるソート
	 * 
	 * @param reviewlist
	 *            レビューのリスト
	 */
	public static void sortReviewByStar(List<Review> reviewlist) {
		reviewlist.sort((c1, c2) -> (c1.getStar() < c2.getStar()) ? 1 : (c1.getStar() == c2.getStar()) ? 0 : -1);
	}
	public static void sortUserByYP(List<UserAccount> userlist)
	{
		userlist.sort( (c1,c2) ->
		(c1.getPoint() < c2.getPoint())? 1 :
		(c1.getPoint() == c2.getPoint())?	0 : -1
				);
	}
	public static List<Review> getReviewByStar(List<Review> reviewlist) {
		reviewlist.sort((c1, c2) -> (c1.getStar() < c2.getStar()) ? 1 : (c1.getStar() == c2.getStar()) ? 0 : -1);
		return reviewlist;
	} 
	public static List<Review> getReviewByDate(List<Review> reviewlist) {
		reviewlist.sort((c1, c2) -> c2.getDate().compareTo(c1.getDate()));
		return reviewlist;
	} 
}
