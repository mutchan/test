package com.fujitsu.soft.rad.devsemi.user;

import java.util.List;

import com.fujitsu.soft.rad.devsemi.entity.PreservedAvatar;
//import com.fujitsu.soft.rad.devsemi.entity.Review;
import com.fujitsu.soft.rad.devsemi.entity.Sales;
import com.fujitsu.soft.rad.devsemi.entity.UserAccount;

/**
 * アカウント画面のバッキングビーン
 * 
 * @author kudo jumma
 *
 */
public class AccountBean {
	private UserAccount account;

	private String newname;

	/**
	 * アカウントの部屋番号をだす
	 * 
	 * @return アカウントの部屋番号
	 */
	public int getRoomNumber() {
		return account.getRoomNumber();
	}

	/**
	 * アカウントの名前を出力
	 * 
	 * @return アカウントの名前
	 */
	public String getName() {
		return account.getName();
	}

	/**
	 * アカウントのグロコミID出力
	 * 
	 * @return アカウントのグロコミID
	 */
	public String getGlocommId() {
		return "" + account.getGlocommId();
	}

	/**
	 * アカウントの残高を出力
	 * 
	 * @return アカウントの残高
	 */
	public int getMoney() {
		return account.getMoney();
	}

	/**
	 * アカウントのYPを出力
	 * 
	 * @return アカウントのYP
	 */
	public int getPoint() {
		return account.getPoint();
	}

	/**
	 * YPランキングDBから現在のランキングを計算する
	 * 
	 * @return 現在のランキング
	 */
	public int getRanking() {
		int nRetRank = 0;
		// アカウントマネージャからYPランクを計算
		// AccountManager am = new AccountManager();
		// nRetRank = am.getYPRank(account);

		return nRetRank;
	}

	/**
	 * ItemManagerから取り出した注文履歴をかえす
	 * 
	 * @return 注文履歴
	 */
	List<Sales> getOrderHistory() {
		List<Sales> retOrderHistory = null;
		// マネージャーから取りに行く
		// ItemManager im = new ItemManager();

		return retOrderHistory;
	}

	/**
	 * PreservedAvatarManagerから取り出したポイント履歴をかえす
	 * 
	 * @return
	 */
	List<PreservedAvatar> getPointHistory() {
		List<PreservedAvatar> retPointHistoryList = null;
		// マネージャーから取りに行く
		// PreservedAvatarManager pm = new PreservedAvatarManager();

		return retPointHistoryList;
	}

	/**
	 * レビューするをクリック
	 */
	void onClickReview() {
		// ReviewManager rm = new ReviewManager();
		// Review review;
	}

	/**
	 * 名前変更をクリック
	 */
	void onClickName() {
		// AccountManager am = new AccountManager();

	}

	/**
	 * その商品にレビューされたか？ をチェックする。レビューマネージャから判断してもらう。
	 * 
	 * @return
	 */
	boolean isReviewed() {
		// ReviewManager = new ReviewManager();
		return true;
	}

	/**
	 * @return the newname
	 */
	public String getNewname() {
		return newname;
	}

	/**
	 * 新しいアカウント名
	 * 
	 * @param newname
	 *            the newname to set
	 */
	public void setNewname(String newname) {
		this.newname = newname;
	}
}
