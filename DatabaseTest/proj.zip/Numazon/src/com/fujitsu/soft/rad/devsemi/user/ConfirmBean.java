package com.fujitsu.soft.rad.devsemi.user;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.UserTransaction;

import com.fujitsu.soft.rad.devsemi.entity.Cart;
import com.fujitsu.soft.rad.devsemi.entity.Item;
import com.fujitsu.soft.rad.devsemi.entity.UserAccount;
import com.fujitsu.soft.rad.devsemi.manager.AccountManager;
import com.fujitsu.soft.rad.devsemi.manager.CartManager;
import com.fujitsu.soft.rad.devsemi.manager.ItemManager;
import com.fujitsu.soft.rad.devsemi.seller.PublicStat;

/**
 * 各商品の詳細を出すBean
 * 
 * @auther Okano Naoki (6/28)
 */
@SuppressWarnings("serial")
@Named
@RequestScoped
public class ConfirmBean implements Serializable {
	@PersistenceContext(unitName = "Numazon")
	private EntityManager em;

	@Resource
	UserTransaction utx;

	private AccountManager am;
	private CartManager cm;
	private ItemManager im;

	// private UserAccount account;
	private List<Cart> cartList = new ArrayList<Cart>();
	private UserAccount user; // 自分のユーザーアカウント
	private int total;// 注文したときの合計金額
	@SuppressWarnings("unused")
	private int tax;// 内税
	private int balance;// 残高

	private static final double TAX = 0.08;

	@PostConstruct
	public void init() {
		// TODO:テストコードの修正
		cm = new CartManager(em, utx);
		am = new AccountManager(em, utx);
		im = new ItemManager(em, utx);

		user = am.getCurrentUserAccount();
		cartList = new ArrayList<Cart>();
		if (user != null) {
			String glocommId = user.getGlocommId();

			// カートマネージャからカートリストを受け取る
			cartList = cm.getCartList(glocommId);
			
		}
		
	}

	public ConfirmBean() {
		/*
		 * am = new AccountManagerStub(); cm = new CartManagerStub();
		 * 
		 * account = am.getCurrentAccount(); cartList =
		 * cm.getCartList(account.getGlocommId());
		 */
	}

	public List<Cart> getCartList() {
		return cartList;
	}

	public void setCartList(List<Cart> cartList) {
		this.cartList = cartList;
	}

	public int getTotal() {
		// ItemManagerStub im = new ItemManagerStub();
		total = 0;

		for (Cart cart : cartList) {
			total += im.getItem(cart.getItemId()).getPrice() * cart.getCount();
			System.out.println("price:" + im.getItem(cart.getItemId()).getPrice() + ",count:" + cart.getCount());
		}

		return (int) (total * (1 + TAX));
	}

	public boolean checkPublicItemInCart() {
		boolean ret = true;
		for (Cart cart : cartList) {
			System.out.println("DEBUG:cartitemid:"+cart.getItemId()+",publicstat:"+(im.getItem(cart.getItemId()).getPublicStat() == PublicStat.PUBLIC));
			ret = ret && (im.getItem(cart.getItemId()).getPublicStat() == PublicStat.PUBLIC);

		}
		return ret;
	}

	public String getImagePath(int itemid) {
		// ItemManagerStub im = new ItemManagerStub();
		return im.getItem(itemid).getImagePath();
	}

	public String getItemName(int itemid) {
		// ItemManagerStub im = new ItemManagerStub();

		return im.getItem(itemid).getName();
	}

	public int getItemPrice(int itemid) {
		// ItemManagerStub im = new ItemManagerStub();

		return im.getItem(itemid).getPrice();
	}

	public int getTax() {
		// ItemManagerStub im = new ItemManagerStub();
		total = 0;
		for (Cart cart : cartList) {
			total += im.getItem(cart.getItemId()).getPrice() * cart.getCount();
		}
		return (int) (total * TAX);
	}

	public int getBalance() {
		balance = user.getMoney() - getTotal();
		return balance;
	}

	public String purchase() {
		
		if (user.getMoney() < getTotal()) {
			return "purchasefailed";
		}
		//非公開アイテムチェック
		if (!checkPublicItemInCart()) {
			//カート内の非公開アイテムを消す処理
			for(Cart cart : cartList)
			{
				if(im.getItem(cart.getItemId()).getPublicStat() != PublicStat.PUBLIC)
				{
					cm.removeCart(cart.getId());
				}
			}
			
			return "purchasefailed";
		}
		//価格変動チェック
		if(!cm.checkCartPrice(user.getGlocommId())){
			return "purchasefailed";
		}
		
		am.updateUserMoney( user.getMoney() - getTotal() );
		
		return "purchasesucceed";
	}

	/*
	 * 確定ボタンを押したときにおこなうメソッド
	 */
	public void onClickSubmit() {
		// Todo:
	}
	public void debugTest()
	{
		List<Cart> cartList = cm.getCartList(user.getGlocommId());
		for(Cart cart:cartList)
		{
			Item item = im.getItem(cart.getItemId());
			im.addStock(item.getId(), 1-item.getStock());
		}
		
	}
}
