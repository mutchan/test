package com.fujitsu.soft.rad.devsemi.stub;

import java.util.ArrayList;
import java.util.List;

import com.fujitsu.soft.rad.devsemi.entity.UserAccount;

/**
 * AccountManagerのスタブ
 * 
 * @author Hiradate, Mutsuki
 *
 */
public class AccountManagerStub {
	/**
	 * 名前の変更
	 * @param id
	 * @param name
	 */
	public void changeName(String id, String name) {
		UserAccount account = getAccountFromId(id);
		account.setName(name);
	}

	/**
	 * ポイントの追加
	 * @param id
	 * @param value
	 */
	public void addPoint(String id, int value) {
		UserAccount account = getAccountFromId(id);
		account.setPoint(account.getPoint() + value);
	}

	/**
	 * ポイントの減少
	 * @param id
	 * @param value
	 */
	public void subPoint(String id, int value) {
		UserAccount account = getAccountFromId(id);
		account.setPoint(account.getPoint() - value);
	}

	/**
	 * ログイン可能かをチェック
	 * @param id
	 * @param password
	 * @return
	 */
	public boolean check(String id, String password) {
		return id.equals("test") && password.equals("user");
	}

	/**
	 * グロコミIDからアカウントを取得
	 * @param id
	 * @return
	 */
	public UserAccount getAccountFromId(String id) {
		List<UserAccount> allAccountList = getAllAccount();

		for (UserAccount account : allAccountList) {
			if (account.getGlocommId() == id) {
				return account;
			}
		}

		return null;
	}
	
	/**
	 * YPランキング用の5位までのリストを出力
	 * @return
	 */
	public List<UserAccount> getYPRankList()
	{
		List<UserAccount> allAccountList = getAllAccount();
		allAccountList.sort(
				(a1,a2) -> (a1.getPoint() < a2.getPoint()) ? 1:
							(a1.getPoint() == a2.getPoint())? 0 : -1 
							);
		return allAccountList.subList(0, 5);
		
	}

	/**
	 * すべてのユーザーアカウントを取得
	 * @return
	 */
	public List<UserAccount> getAllAccount() {
		List<UserAccount> accountList = new ArrayList<UserAccount>();

		UserAccount account0 = new UserAccount();
		account0.setGlocommId("user1");
		account0.setName("嶋田");
		account0.setRoomNumber(100);
		account0.setPoint(10000);
		account0.setMoney(100000);
		accountList.add(account0);

		UserAccount account1 = new UserAccount();
		account1.setGlocommId("user2");
		account1.setName("工藤");
		account1.setRoomNumber(200);
		account1.setPoint(200);
		account1.setMoney(100000);
		accountList.add(account1);

		UserAccount account2 = new UserAccount();
		account2.setGlocommId("user3");
		account2.setName("岡野");
		account2.setRoomNumber(300);
		account2.setPoint(300);
		account2.setMoney(100000);
		accountList.add(account2);
		
		UserAccount account3 = new UserAccount();
		account3.setGlocommId("user4");
		account3.setName("平館");
		account3.setRoomNumber(400);
		account3.setPoint(400);
		account3.setMoney(100000);
		accountList.add(account3);
		
		UserAccount account4 = new UserAccount();
		account4.setGlocommId("user5");
		account4.setName("加賀城");
		account4.setRoomNumber(500);
		account4.setPoint(500);
		account4.setMoney(100000);
		accountList.add(account4);
		
		UserAccount account5 = new UserAccount();
		account5.setGlocommId("user6");
		account5.setName("大三島");
		account5.setRoomNumber(101);
		account5.setPoint(600);
		account5.setMoney(100000);
		accountList.add(account5);
		
		UserAccount account6 = new UserAccount();
		account6.setGlocommId("user7");
		account6.setName("水谷");
		account6.setRoomNumber(102);
		account6.setPoint(700);
		account6.setMoney(100000);
		accountList.add(account6);
		
		return accountList;
	}

	/**
	 * 現在のユーザーアカウントを取得
	 * @return　現在のユーザーアカウント
	 */
	public UserAccount getCurrentAccount(){
		return getAccountFromId("user1");
	}
}
