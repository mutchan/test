package com.fujitsu.soft.rad.devsemi.stub;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import com.fujitsu.soft.rad.devsemi.entity.Item;
import com.fujitsu.soft.rad.devsemi.entity.Review;

public class ReviewManagerStub {
	private List<Review> reviewList = new ArrayList<Review>();
	public ReviewManagerStub()
	{
		ArrayList<Review> list = new ArrayList<Review>();
		
		Review review1 = new Review();

		review1.setId(0);
		review1.setAccountId("user@jp.fujitsu.com");
		review1.setComment("神机でした");
		review1.setDate(new Date(0));
		review1.setGoodCount(0);
//		review1.setAvatar(null);
		review1.setItemId(0);
		review1.setStar(5);
		list.add(review1);
		
		Review review2 = new Review();

		review2.setId(1);
		review2.setAccountId("user@jp.fujitsu.com");
		review2.setComment("神椅子でした");
		review2.setDate(new Date(1));
		review2.setGoodCount(1);
//		review2.setAvatar(null);
		review2.setItemId(1);
		review2.setStar(5);
		list.add(review2);
		
		Review review3 = new Review();

		review3.setId(2);
		review3.setAccountId("user2@jp.fujitsu.com");
		review3.setComment("クソ机でした");
		review3.setDate(new Date(2));
		review3.setGoodCount(0);
//		review3.setAvatar(null);
		review3.setItemId(0);
		review3.setStar(1);
		list.add(review3);
		
		Review review4 = new Review();
		review4.setId(3);
		review4.setAccountId("user2@jp.fujitsu.com");
		review4.setComment("神シャーペンでした");
		review4.setDate(new Date(3));
		review4.setGoodCount(0);
//		review4.setAvatar(null);
		review4.setItemId(2);
		review4.setStar(5);
		list.add(review4);

		reviewList.addAll(list);
	}
	
	/**
	 * レビューリストを返す
	 * @return
	 */
	public List<Review> getReviewList()
	{
		return reviewList;
	}
	
	/**
	 * レビューのリストを返す
	 * @param id
	 * @return
	 */
	public Review getReview(int id)
	{
		return reviewList.get(id);
	}
	
	/**
	 * itemidのレビューをフィルターしてリストで返す
	 * @param itemid
	 * @return
	 */
	public List<Review> getItemReviewList(int itemid)
	{
		return reviewList.stream().filter(s -> (s.getItemId() == itemid)).collect(Collectors.toList());
	}
	
	/**
	 * idのレビューを削除する
	 * @param id
	 */
	public void removeReview(int id)
	{
		reviewList.removeIf(s->s.getId() == id);
	}
	
	/**
	 * レビューを増やす
	 * @param r
	 */
	public void addReview(Review r)
	{
		//うまい具合にIDをsetする
		
		r.setId(reviewList.size());
		reviewList.add(r);
	}
	/**
	 * idのレビューにいいねする
	 * @param id
	 */
	public void goodReview(int id)
	{
		for(Review r:reviewList)
		{
			if(r.getId() == id)
			{
				//1いいねを追加
				r.addGoodCount(1);
			}
		}
	}
	/**
	 * オススメレビューを持ってくる。実際の処理はItemManagerで行うけど、stubなので、ReviewManagerの方で行う
	 * @param itemID
	 * @return
	 */
	public Review getRecommendReview(int itemID)
	{
		//stubなのでreviewManagerの方で行う
		Review review1 = new Review();
		
		review1.setId(0);
		review1.setAccountId("user@jp.fujitsu.com");
		review1.setComment("エラーだよ");
		review1.setDate(new Date(0));
		review1.setGoodCount(0);
//		review1.setAvatar(null);
		review1.setItemId(0);
		review1.setStar(5);
		
		return reviewList.stream()
				.filter(s -> (s.getItemId() == itemID))
				.filter(s -> s.getStar() >= 4)
				.findFirst().orElse(review1);
	}
}
