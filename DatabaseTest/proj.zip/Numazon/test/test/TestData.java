package test;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.transaction.SystemException;
import javax.transaction.UserTransaction;

import com.fujitsu.soft.rad.devsemi.entity.Avatar;
import com.fujitsu.soft.rad.devsemi.entity.Bbs;
import com.fujitsu.soft.rad.devsemi.entity.Cart;
import com.fujitsu.soft.rad.devsemi.entity.GlocommAccount;
import com.fujitsu.soft.rad.devsemi.entity.Item;
import com.fujitsu.soft.rad.devsemi.entity.PreservedAvatar;
import com.fujitsu.soft.rad.devsemi.entity.Review;
import com.fujitsu.soft.rad.devsemi.entity.Sales;
import com.fujitsu.soft.rad.devsemi.entity.SellerAccount;
import com.fujitsu.soft.rad.devsemi.entity.UserAccount;
import com.fujitsu.soft.rad.devsemi.manager.AccountManager;
import com.fujitsu.soft.rad.devsemi.manager.ItemManager;
import com.fujitsu.soft.rad.devsemi.seller.Category;
import com.fujitsu.soft.rad.devsemi.seller.PublicStat;

/**
 * テスト用のデータベースの作成
 * 
 * @author Mutsuki Hiradate
 *
 */
@Named
@RequestScoped
public class TestData implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1176304073652316550L;

	@PersistenceContext(unitName = "Numazon")
	private EntityManager em;

	@Resource
	private UserTransaction utx;

	AccountManager am;
	ItemManager im;

	static final int USER_ACCOUNT_NUM = 10;
	static final int AVATAR_NUM = 10;
	static final int PRESERVED_AVATAR_NUM = 40;
	static final int REVIEW_NUM = 1000;
	static final int SALES_NUM = 100;
	static final int CART_NUM = 100;

	List<UserAccount> userAccount = new ArrayList<UserAccount>();
	List<Avatar> avatarList = new ArrayList<Avatar>();
	List<Item> itemList = new ArrayList<Item>();

	/**
	 * コンストラクタ
	 */
	@PostConstruct
	public void init() {
		am = new AccountManager(em, utx);
		im = new ItemManager(em, utx);
	}

	/**
	 * 
	 */
	public void createData() {
		// データベースのクリア
		clearDatabase();

		// 買い手アカウントのデータ作成
		createUserAccount();

		// 売り手アカウントのデータ作成
		createSellerAccount();

		// アバターのデータ作成
		createAvatar();

		// 商品のデータ作成
		createItem();

		// 商品レビューのデータ作成
		createReview();

		// 売上のデータ作成
		createSales();

		// カートのデータ作成
		createCart();
	}

	private void clearDatabase() {
		try {
			try {
				utx.begin();
				List<SellerAccount> list = em.createNamedQuery(SellerAccount.FIND_ALL, SellerAccount.class)
						.getResultList();
				list.stream().forEach(s -> em.remove(s));
				utx.commit();
			} catch (Exception e) {
				e.printStackTrace();
				try {
					utx.rollback();
				} catch (IllegalStateException | SecurityException | SystemException e1) {
					e1.printStackTrace();
				}
			}
		} catch (NoResultException e) {
		}

		try {
			try {
				utx.begin();
				List<Review> list = em.createNamedQuery(Review.FIND_ALL, Review.class).getResultList();
				list.stream().forEach(s -> em.remove(s));
				utx.commit();
			} catch (Exception e) {
				e.printStackTrace();
				try {
					utx.rollback();
				} catch (IllegalStateException | SecurityException | SystemException e1) {
					e1.printStackTrace();
				}
			}
		} catch (NoResultException e) {
		}

		try {
			try {
				utx.begin();
				List<Sales> list = em.createNamedQuery(Sales.FIND_ALL, Sales.class).getResultList();
				list.stream().forEach(s -> em.remove(s));
				utx.commit();
			} catch (Exception e) {
				e.printStackTrace();
				try {
					utx.rollback();
				} catch (IllegalStateException | SecurityException | SystemException e1) {
					e1.printStackTrace();
				}
			}
		} catch (NoResultException e) {
		}

		try {
			try {
				utx.begin();
				List<Cart> list = em.createNamedQuery(Cart.FIND_ALL, Cart.class).getResultList();
				list.stream().forEach(s -> em.remove(s));
				utx.commit();
			} catch (Exception e) {
				e.printStackTrace();
				try {
					utx.rollback();
				} catch (IllegalStateException | SecurityException | SystemException e1) {
					e1.printStackTrace();
				}
			}
		} catch (NoResultException e) {
		}

		try {
			try {
				utx.begin();
				List<Item> list = em.createNamedQuery(Item.FIND_ALL, Item.class).getResultList();
				list.stream().forEach(s -> em.remove(s));
				utx.commit();
			} catch (Exception e) {
				e.printStackTrace();
				try {
					utx.rollback();
				} catch (IllegalStateException | SecurityException | SystemException e1) {
					e1.printStackTrace();
				}
			}
		} catch (NoResultException e) {
		}

		try {
			try {
				utx.begin();
				List<Avatar> list = em.createNamedQuery(Avatar.FIND_ALL, Avatar.class).getResultList();
				list.stream().forEach(s -> em.remove(s));
				utx.commit();
			} catch (Exception e) {
				e.printStackTrace();
				try {
					utx.rollback();
				} catch (IllegalStateException | SecurityException | SystemException e1) {
					e1.printStackTrace();
				}
			}
		} catch (NoResultException e) {
		}

		try {
			try {
				utx.begin();
				List<PreservedAvatar> list = em.createNamedQuery(PreservedAvatar.FIND_ALL, PreservedAvatar.class)
						.getResultList();
				list.stream().forEach(s -> em.remove(s));
				utx.commit();
			} catch (Exception e) {
				e.printStackTrace();
				try {
					utx.rollback();
				} catch (IllegalStateException | SecurityException | SystemException e1) {
					e1.printStackTrace();
				}
			}
		} catch (NoResultException e) {
		}

		try {
			try {
				utx.begin();
				List<Bbs> list = em.createNamedQuery(Bbs.FIND_ALL, Bbs.class).getResultList();
				list.stream().forEach(s -> em.remove(s));
				utx.commit();
			} catch (Exception e) {
				e.printStackTrace();
				try {
					utx.rollback();
				} catch (IllegalStateException | SecurityException | SystemException e1) {
					e1.printStackTrace();
				}
			}
		} catch (NoResultException e) {
		}

		try {
			try {
				utx.begin();
				List<UserAccount> list = em.createNamedQuery(UserAccount.FIND_ALL, UserAccount.class).getResultList();
				list.stream().forEach(s -> em.remove(s));
				utx.commit();
			} catch (Exception e) {
				e.printStackTrace();
				try {
					utx.rollback();
				} catch (IllegalStateException | SecurityException | SystemException e1) {
					e1.printStackTrace();
				}
			}
		} catch (NoResultException e) {
		}

		try {
			try {
				utx.begin();
				List<GlocommAccount> list = em.createNamedQuery(GlocommAccount.FIND_ALL, GlocommAccount.class)
						.getResultList();
				list.stream().forEach(s -> em.remove(s));
				utx.commit();
			} catch (Exception e) {
				e.printStackTrace();
				try {
					utx.rollback();
				} catch (IllegalStateException | SecurityException | SystemException e1) {
					e1.printStackTrace();
				}
			}
		} catch (NoResultException e) {
		}
	}

	private void createUserAccount() {

		try {
			utx.begin();
			UserAccount account = new UserAccount();
			account.setGlocommId("user");
			account.setMoney(100000);
			account.setName("user");
			account.setPoint(100);
			account.setRoomNumber(296);
			em.persist(account);

			GlocommAccount ga = new GlocommAccount();
			ga.setId("user");
			ga.setPass("pass");
			em.persist(ga);
			userAccount.add(account);
			utx.commit();
		} catch (Exception e) {
			e.printStackTrace();
			try {
				utx.rollback();
			} catch (IllegalStateException | SecurityException | SystemException e1) {
				e1.printStackTrace();
			}
		}

		for (int i = 0; i < USER_ACCOUNT_NUM; i++) {
			try {
				utx.begin();
				UserAccount account = new UserAccount();
				account.setGlocommId("user" + i);
				account.setMoney(100000);
				account.setName("user" + i);
				account.setPoint(i * 100);
				account.setRoomNumber(100 + i * 30);
				em.persist(account);

				GlocommAccount ga = new GlocommAccount();
				ga.setId("user" + i);
				ga.setPass("pass");
				em.persist(ga);
				utx.commit();
				userAccount.add(account);
			} catch (Exception e) {
				e.printStackTrace();
				try {
					utx.rollback();
				} catch (IllegalStateException | SecurityException | SystemException e1) {
					e1.printStackTrace();
				}
			}
		}
	}

	private void createSellerAccount() {

		try {
			utx.begin();
			SellerAccount account = new SellerAccount();
			account.setId("seller");
			account.setPassword("pass");
			account.setMail("test@hoge.com");
			em.persist(account);
			utx.commit();
		} catch (Exception e) {
			e.printStackTrace();
			try {
				utx.rollback();
			} catch (IllegalStateException | SecurityException | SystemException e1) {
				e1.printStackTrace();
			}
		}
	}

	private void createAvatar() {
		for (int i = 0; i < AVATAR_NUM; i++) {
			try {
				utx.begin();
				Avatar avatar = new Avatar();
				avatar.setName("景品" + i);
				avatar.setPoint((int) (Math.random() * 500));
				avatar.setImagePath("/product/avater-img/" + i + ".JPG");

				em.persist(avatar);
				utx.commit();
				avatarList.add(avatar);
			} catch (Exception e) {
				e.printStackTrace();
				try {
					utx.rollback();
				} catch (IllegalStateException | SecurityException | SystemException e1) {
					e1.printStackTrace();
				}
			}
		}

		for (int i = 0; i < PRESERVED_AVATAR_NUM; i++) {
			try {
				utx.begin();
				PreservedAvatar pa = new PreservedAvatar();
				pa.setAvatar(avatarList.get((int) (Math.random() * AVATAR_NUM)));
				pa.setAccountId("user" + (int) (Math.random() * USER_ACCOUNT_NUM));
				
				int year = (int) (Math.random() * 16);
				int month = (int) (Math.random() * 12);
				int day = (int) (Math.random() * 20);
				int hour = (int) (Math.random() * 24);
				int min = (int) (Math.random() * 24);
				int sec = (int) (Math.random() * 24);

				DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S");
				String strDate = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", year, month, day, hour,
						min, sec);
				pa.setDate(format.parse(strDate));
				em.persist(pa);
				utx.commit();
			} catch (Exception e) {
				e.printStackTrace();
				try {
					utx.rollback();
				} catch (IllegalStateException | SecurityException | SystemException e1) {
					e1.printStackTrace();
				}
			}
		}
	}

	private void createItem() {
		// List<Item> itemList = new ItemManagerStub().getItemList();

		for (int i = 0; i < 100; i++) {
			try {
				utx.begin();
				Item item = new Item();
				item.setName("商品" + i);
				item.setDesc(getRandomString(255));
				item.setCategory(Category.values()[(int) (Math.random() * 3)]);
				if(i!=10){//商品番号が10の時の在庫数を0にしたいので一時的にry)
					item.setStock((int) (item.getCategory().getInitStock() * Math.random() * 2));
				}else{
					item.setStock(0);
				}
					item.setImagePath("/product/item-img/" + i + ".JPG");
				item.setPublicStat(PublicStat.values()[(int) (Math.random() * 2)]);
				item.setAverageStar(Math.random() * 5);

				int year = (int) (Math.random() * 16);
				int month = (int) (Math.random() * 12);
				int day = (int) (Math.random() * 20);
				int hour = (int) (Math.random() * 24);
				int min = (int) (Math.random() * 24);
				int sec = (int) (Math.random() * 24);

				DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S");
				String strDate = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", year, month, day, hour,
						min, sec);
				try {
					item.setLastEdit(format.parse(strDate));
					item.setRegistDate(format.parse(strDate));
				} catch (ParseException e) {
					e.printStackTrace();
				}
				// item.setReviewList(new ArrayList<Review>());

				em.persist(item);
				utx.commit();
				itemList.add(item);
			} catch (Exception e) {
				e.printStackTrace();
				try {
					utx.rollback();
				} catch (IllegalStateException | SecurityException | SystemException e1) {
					e1.printStackTrace();
				}
			}
		}
	}

	private void createReview() {
		for (int i = 0; i < REVIEW_NUM; i++) {
			try {
				utx.begin();
				Review review = new Review();
				review.setItemId(itemList.get((int) (Math.random() * 100)).getId());
				review.setAvatar(avatarList.get((int) (Math.random() * AVATAR_NUM)));
				review.setComment((getRandomString(255)));
				review.setAccountId(userAccount.get((int) (Math.random() * USER_ACCOUNT_NUM)).getGlocommId());
				review.setStar((int) (Math.random() * 5));
				review.setGoodCount((int) (Math.random() * 100));

				int year = (int) (Math.random() * 16);
				int month = (int) (Math.random() * 12);
				int day = (int) (Math.random() * 20);
				int hour = (int) (Math.random() * 24);
				int min = (int) (Math.random() * 24);
				int sec = (int) (Math.random() * 24);

				DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S");
				String strDate = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", year, month, day, hour,
						min, sec);
				try {
					review.setDate(format.parse(strDate));
				} catch (ParseException e) {
					e.printStackTrace();
				}

				em.persist(review);
				utx.commit();
			} catch (Exception e) {
				e.printStackTrace();
				try {
					utx.rollback();
				} catch (IllegalStateException | SecurityException | SystemException e1) {
					e1.printStackTrace();
				}
			}
		}
	}

	private void createSales() {
		List<UserAccount> userAccount = em.createNamedQuery(UserAccount.FIND_ALL, UserAccount.class).getResultList();
		for (int i = 0; i < SALES_NUM; i++) {
			try {
				utx.begin();
				Sales sales = new Sales();
				sales.setItemId(itemList.get((int) (Math.random() * 100)).getId());
				sales.setPrice((int) (Math.random() * 1000) * 100);
				sales.setCount((int) (Math.random() * 100));
				sales.setAccountId(userAccount.get((int) (Math.random() * userAccount.size())).getGlocommId());

				int year = (int) (Math.random() * 16);
				int month = (int) (Math.random() * 12);
				int day = (int) (Math.random() * 20);
				int hour = (int) (Math.random() * 24);
				int min = (int) (Math.random() * 24);
				int sec = (int) (Math.random() * 24);

				DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S");
				String strDate = String.format("20%1$02d-%2$02d-%3$02d %4$02d:%5$02d:%6$02d.0", year, month, day, hour,
						min, sec);
				try {
					sales.setDate(format.parse(strDate));
				} catch (ParseException e) {
					e.printStackTrace();
				}

				em.persist(sales);
				utx.commit();
			} catch (Exception e) {
				e.printStackTrace();
				try {
					utx.rollback();
				} catch (IllegalStateException | SecurityException | SystemException e1) {
					e1.printStackTrace();
				}
			}
		}

	}

	private void createCart() {
		List<Item> itemList = em.createNamedQuery(Item.FIND_ALL, Item.class).getResultList();
		for (int i = 0; i < SALES_NUM; i++) {
			try {
				Item item = itemList.get((int) (Math.random() * itemList.size()));
				utx.begin();
				Cart cart = new Cart();
				cart.setItemId(item.getId());
				cart.setCount((int) (Math.random() * 100));
				cart.setAccountId("user" + (int) (Math.random() * USER_ACCOUNT_NUM));

				em.persist(cart);
				utx.commit();
			} catch (Exception e) {
				e.printStackTrace();
				try {
					utx.rollback();
				} catch (IllegalStateException | SecurityException | SystemException e1) {
					e1.printStackTrace();
				}
			}
		}
	}

	/**
	 * ランダムな文字列の取得
	 * 
	 * @param maxLength
	 *            文字列の長さ
	 * @return
	 */
	private String getRandomString(int maxLength) {
		String ret = "";
		int length = (int) (Math.random() * maxLength);
		for (int i = 0; i < length; i++) {
			if (Math.random() > 0.5) {
				ret += (char) ('あ' + Math.random() * ('ん' - 'あ'));
			} else {
				ret += (char) ('亜' + Math.random() * ('唯' - '亜'));
			}
		}
		return ret;
	}

	/**
	 * 
	 */
	public void testData() {
		for (int i = 0; i < 10; i++) {
			getRandomString(255);
		}
	}
}
