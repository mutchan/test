$wc = new-object System.Net.WebClient
$proxy = [System.Net.WebRequest]::GetSystemWebProxy()
$proxy.Credentials = [System.Net.CredentialCache]::DefaultCredentials
$wc.Proxy = $proxy
$cred = get-credential
$wc.Proxy.Credentials = $cred.GetNetworkCredential()

$cur_dir = pwd

$wc.DownloadFile("http://www.cosme.net/brand/brand_id/4855/products", "${cur_dir}\main.txt")

$item_nm = cat main.txt | Select-String "product/product_id/" | Select-String -NotMatch "<p>" | Select-String -NotMatch "<li>" | Select-String -NotMatch "class="
$item_number = 52

for($i = 0; $i -lt $item_nm.length; $i++) {
	$line = $item_nm[$i]
	$url = ("$line").Split("<>")[1]
	$url = ("$url").Substring(8,($url.length-11))
	$name = ("$line").Split("<>")[2]
	
	echo NAME:$name
	#echo URL:$url
	
	$html = Invoke-WebRequest("$url")
	$dd = $html.ParsedHtml.getElementsByTagName("dd")
	$outerHTML = $dd | select @{E = "outerHTML"}
	
	for($j = 0; $j -lt $outerHTML.length; $j++){
		if($outerHTML[$j].outerHTML.Contains("itemprop")){
			$desc = $outerHTML[$j].outerHTML.Split(">")[1]
		}
	}
	
	echo DESC:$desc
	
	$item_number = $item_number + 1
	echo $name >> names.txt
	echo $desc | Out-File -Encoding default "$item_number.txt"
	
	#$reviews = cat .\item.txt | Select-String "description" | Select-String "review"
}

function Set-CustomCredentials {
    # 平文パスワードをSecureStringに変換
    $password = ConvertTo-SecureString "0000080425" -AsPlainText -Force
    # Credentialを生成
    $cred = New-Object System.Management.Automation.PSCredential "m.hiradate@jp.fujitsu.com", $password
    # プロキシ情報を設定
    $proxy = New-Object System.Net.WebProxy "http://kmt.proxy.nic.fujitsu.com:8080/"
    # WebProxyにCredentialを持たせる
    $proxy.Credentials = $cred
    # デフォルトのプロキシに、上で作成したWebProxyを設定
    [System.Net.WebRequest]::DefaultWebProxy = $proxy
}
