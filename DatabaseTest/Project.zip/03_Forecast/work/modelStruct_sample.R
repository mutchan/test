library("ranger")

#���f���\�z
file.input.main <- "../../02_ModelStruct/tmp/input.modelstruct.csv" #1�Ԗڂ̈������擾����
file.output.main <- commandArgs(trailingOnly=TRUE)[2] #2�Ԗڂ̈������擾����
file.output.main <- ifelse(is.na(file.output.main), "output/model_list", file.output.main)

#�f�[�^�ǂݍ���
cat(sprintf("INPUT  : %s\n", file.input.main))
cat(sprintf("OUTPUT : %s\n", file.output.main))
x<-read.csv(file.input.main)
cat(sprintf("COLMUN : %d\n", dim(x)[2]))
cat(sprintf("RECORD : %d\n", dim(x)[1]))

#�����ϐ��̎擾
eValDatas<-x[,(15:ncol(x))]


#rb<-ranger(Sepal.Length~.,data=iris)
#result<-predict(rb,data = head(iris,3))
model_list<-list()
val_first_index<-2
for(i in 0.:12){
  index<-val_first_index+i
  targetDF<-cbind(x[,index],eValDatas)
  colnames(targetDF)[1]="oVal"
  rb<-ranger(oVal~.,data=targetDF, )
  model_list[[i+1]]<-rb
}

save(list = "model_list",file = file.output.main)

