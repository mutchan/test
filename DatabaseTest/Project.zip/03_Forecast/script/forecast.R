library("ranger")

#���f���\�z
file.input.main <- commandArgs(trailingOnly=TRUE)[1] #1�Ԗڂ̈������擾����
file.input.model <- commandArgs(trailingOnly=TRUE)[2] #2�Ԗڂ̈������擾����
file.output.main <- commandArgs(trailingOnly=TRUE)[3] #3�Ԗڂ̈������擾����
file.output.main <- ifelse(is.na(file.output.main), "output/predictions.csv", file.output.main)

#file.input.main <- "../tmp/input.modelstruct.csv"
#file.input.model <- "../../02_ModelStruct/output/model_list.RData"
#file.output.main <- "result.csv"

#�f�[�^�ǂݍ���
cat(sprintf("INPUT  : %s\n", file.input.main))
cat(sprintf("MODEL  : %s\n", file.input.model))
cat(sprintf("OUTPUT : %s\n", file.output.main))
load(file.input.model)
x<-read.csv(file.input.main)
cat(sprintf("COLMUN : %d\n", dim(x)[2]))
cat(sprintf("RECORD : %d\n", dim(x)[1]))

#�����ϐ��̎擾
eValDatas<-x[,(2:ncol(x))]

result <- matrix(0,9,14)
result[,1] <- x[,1]
for(i in 1.:length(model_list)){
  rb <- model_list[[i]]
  pred <- predict(rb, data=eValDatas)
  result[,i+1] <- pred$predictions
}

colnames(result) <- c("ITEM_CODE","0","1","2","3","4","5","6","7","8","9","10","11","12")
write.csv(x = round(result), file = file.output.main, row.names = FALSE)
