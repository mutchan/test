//
var acc = 0;

// ジャイロセンサー情報
// X軸
var beta = 0;
// Y軸
var gamma = 0;
// Z軸
var alpha = 0;


// 加速度
// X軸
var x = 0;
// Y軸
var y = 0;
// Z軸
var z = 0;

(function() {

	$(function() {

		var isMotion = false;
		
		window.addEventListener("devicemotion", devicemotionHandler);
		window.addEventListener("deviceorientation", deviceorientationHandler);
	});

	// 加速度が変化
	function devicemotionHandler(event) {
		//if (isMotion)
		//	return;

		// 加速度
		// X軸
		x = event.acceleration.x;
		// Y軸
		y = event.acceleration.y;
		// Z軸
		z = event.acceleration.z;

		var l = 5;
		if (x > l || x < -l || y > l || y < -l) { // 下
			acc = Math.sqrt(x * x + y * y + z * z);
			document.getElementById('test').innerHTML = ('Acc=' + acc);
		} else {
			return;
		}

		isMotion = true;

		$arrow.delay(200).transition({
			x : 0,
			y : 0
		}, 300, "easeOutCubic", function() {
			isMotion = false
		});
	}

	/**
	 * 
	 * @param event
	 */
	function deviceorientationHandler(event) {
		// ジャイロセンサー情報取得
		// X軸
		beta = event.beta;
		// Y軸
		gamma = event.gamma;
		// Z軸
		alpha = event.alpha;
	}
})();