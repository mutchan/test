(function() {

	var $arrow;
	var $window;
	var $testText
	var stageW;
	var stageH;

	var maxZ = 0;
	var minZ = 360;

	var acc = 0;

	var isMotion;

	$(function() {
		$arrow = $("#arrow");
		$window = $(window);
		$testText = $("test");

		isMotion = false;

		$(window).on("resize", resizeHandler);
		resizeHandler();

		// DeviceMotion Event
		window.addEventListener("devicemotion", devicemotionHandler);
		window.addEventListener("deviceorientation", deviceorientationHandler);
	});

	// 加速度が変化
	function devicemotionHandler(event) {
		if (isMotion)
			return;

		// 加速度
		// X軸
		var x = event.acceleration.x;
		// Y軸
		var y = event.acceleration.y;
		// Z軸
		var z = event.acceleration.z;

		$arrow.stop();

		var l = 20;
		if (x > l || x < -l || y > l || y < -l) { // 下
			$arrow.css({
				y : -stageH
			});
			$arrow.children("img").css({
				"-webkit-transform" : "rotate(180deg)",
				"-moz-transform" : "rotate(180deg)",
				"transform" : "rotate(180deg)"
			});
			acc = Math.sqrt(x * x + y * y + z * z);
			document.getElementById('test').innerHTML = ('Acc=' + acc);
		} else {
			return;
		}

		isMotion = true;

		$arrow.delay(100).transition({
			x : 0,
			y : 0
		}, 300, "easeOutCubic", function() {
			isMotion = false
		});
	}

	/**
	 * 
	 * @param event
	 */
	function deviceorientationHandler(event) {
		if (!isMotion)
			return;

		// ジャイロセンサー情報取得
		// X軸
		var beta = event.beta;
		// Y軸
		var gamma = event.gamma;
		// Z軸
		var alpha = event.alpha;

		var html = "";
		html += "X回転 : " + beta + "<br>";
		html += "Y回転 : " + gamma + "<br>";
		html += 'Z回転 : ' + alpha;

		document.getElementById('orient').innerHTML = html;

		maxZ = Math.max(maxZ, alpha);
		minZ = Math.min(minZ, alpha);
		var rot = (maxZ - minZ);
		if (rot > 180) {
			rot = 360 - rot;
		}
		document.getElementById('z-rot').innerHTML = ("ROT=" + rot);

		document.getElementById('j_idt6:dist').innerHTML = acc * rot * 3;
		document.getElementById('intest').innerHTML = acc * rot * 3;
		
	}

	function resizeHandler(event) {
		stageW = $window.width();
		stageH = $window.height();
	}
})();