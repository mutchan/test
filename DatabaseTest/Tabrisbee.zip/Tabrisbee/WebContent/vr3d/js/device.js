//
var acc = 0.0;

// ジャイロセンサー情報
// X軸
var beta = 0;
// Y軸
var gamma = 0;
// Z軸
var alpha = 0;

// ジャイロセンサー情報
// X軸
var last_beta = 0;
// Y軸
var last_gamma = 0;
// Z軸
var last_alpha = 0;

// 加速度センサー情報
// X軸
var x = 0;
// Y軸
var y = 0;
// Z軸
var z = 0;

var isMotion = false;
var stop_frame = 0;

(function() {

	$(function() {
		window.addEventListener("devicemotion", devicemotionHandler);
		window.addEventListener("deviceorientation", deviceorientationHandler);
	});

	// 加速度が変化
	function devicemotionHandler(event) {

		var html = "";
		html += "X加速度 : " + x + "&#009;X回転 : " + beta + "<br>";
		html += "Y加速度 : " + y + "&#009;Y回転 : " + gamma + "<br>";
		html += 'Z加速度 : ' + z + "&#009;Z回転 : " + alpha + "<br>";
		html += 'ACC　 : ' + acc + "&#009;UP : "
				+ Math.sin(last_gamma * Math.PI / 180.0);
		$("#debug").html(html);

		if (stop_frame > 0) {
			stop_frame--;
			return;
		}
		stop_frame = 10;

		// 加速度
		// X軸
		x = event.acceleration.x;
		// Y軸
		y = event.acceleration.y;
		// Z軸
		z = event.acceleration.z;

		var l = 5;
		if (x > l || x < -l || y > l || y < -l) {
			// 加速度の絶対値を計算
			acc = Math.sqrt(x * x + y * y + z * z);

			// X軸
			last_beta = beta;
			// Y軸
			last_gamma = gamma;
			// Z軸
			last_alpha = alpha;
		} else {
			return;
		}
	}

	/**
	 * 
	 * @param event
	 */
	function deviceorientationHandler(event) {
		// ジャイロセンサー情報取得
		// X軸
		beta = event.beta;
		// Y軸
		gamma = event.gamma;
		// Z軸
		alpha = event.alpha;
	}
})();