/**
 * 
 */
var world = null;
var phyPlane = null;
var scene = null;
var camera = null;
var viewPlane = null;
var renderer = null;

var wSizeWidth = window.innerWidth; // 描画サイズ（横）
var wSizeHeight = window.innerHeight; // 描画サイズ（縦）

var selfData = new Object();
selfData.angle = 270; // 方角
selfData.posX = 0; // 位置
selfData.posY = 0; // 位置
selfData.height = 5; // 高さ
selfData.speed = 5; // 前進速度
var theta = 0;
var flag = true;
var last_acc = 0.0;

// Texture
var ground_texture = THREE.ImageUtils.loadTexture('./assets/images/ground.jpg');
ground_texture.wrapS = ground_texture.wrapT = THREE.RepeatWrapping;
ground_texture.repeat.set(64, 64);

initWorld(); // CANNON.jsの初期化
setView(); // Three.jsの初期化
animate(); // レンダリング

function shape2mesh(body) {
	var obj = new THREE.Object3D();
	var currentMaterial = new THREE.MeshLambertMaterial({
		color : 0xffff00
	});

	for (var l = 0; l < body.shapes.length; l++) {
		var shape = body.shapes[l];

		var mesh;

		switch (shape.type) {

		case CANNON.Shape.types.SPHERE:
			var sphere_geometry = new THREE.SphereGeometry(shape.radius, 8, 8);
			mesh = new THREE.Mesh(sphere_geometry, currentMaterial);
			break;

		case CANNON.Shape.types.PARTICLE:
			mesh = new THREE.Mesh(this.particleGeo, this.particleMaterial);
			var s = this.settings;
			mesh.scale.set(s.particleSize, s.particleSize, s.particleSize);
			break;

		case CANNON.Shape.types.PLANE:
			var geometry = new THREE.PlaneGeometry(10, 10, 4, 4);
			mesh = new THREE.Object3D();
			var submesh = new THREE.Object3D();
			var ground = new THREE.Mesh(geometry, currentMaterial);
			ground.scale.set(100, 100, 100);
			submesh.add(ground);

			ground.castShadow = true;
			ground.receiveShadow = true;

			mesh.add(submesh);
			break;

		case CANNON.Shape.types.BOX:
			var box_geometry = new THREE.BoxGeometry(shape.halfExtents.x * 2,
					shape.halfExtents.y * 2, shape.halfExtents.z * 2);
			mesh = new THREE.Mesh(box_geometry, currentMaterial);
			break;

		case CANNON.Shape.types.CONVEXPOLYHEDRON:
			var geo = new THREE.Geometry();

			// Add vertices
			for (var i = 0; i < shape.vertices.length; i++) {
				var v = shape.vertices[i];
				geo.vertices.push(new THREE.Vector3(v.x, v.y, v.z));
			}

			for (var i = 0; i < shape.faces.length; i++) {
				var face = shape.faces[i];

				// add triangles
				var a = face[0];
				for (var j = 1; j < face.length - 1; j++) {
					var b = face[j];
					var c = face[j + 1];
					geo.faces.push(new THREE.Face3(a, b, c));
				}
			}
			geo.computeBoundingSphere();
			geo.computeFaceNormals();
			mesh = new THREE.Mesh(geo, currentMaterial);
			break;

		case CANNON.Shape.types.HEIGHTFIELD:
			var geometry = new THREE.Geometry();

			var v0 = new CANNON.Vec3();
			var v1 = new CANNON.Vec3();
			var v2 = new CANNON.Vec3();
			for (var xi = 0; xi < shape.data.length - 1; xi++) {
				for (var yi = 0; yi < shape.data[xi].length - 1; yi++) {
					for (var k = 0; k < 2; k++) {
						shape.getConvexTrianglePillar(xi, yi, k === 0);
						v0.copy(shape.pillarConvex.vertices[0]);
						v1.copy(shape.pillarConvex.vertices[1]);
						v2.copy(shape.pillarConvex.vertices[2]);
						v0.vadd(shape.pillarOffset, v0);
						v1.vadd(shape.pillarOffset, v1);
						v2.vadd(shape.pillarOffset, v2);
						geometry.vertices.push(new THREE.Vector3(v0.x, v0.y,
								v0.z), new THREE.Vector3(v1.x, v1.y, v1.z),
								new THREE.Vector3(v2.x, v2.y, v2.z));
						var i = geometry.vertices.length - 3;
						geometry.faces.push(new THREE.Face3(i, i + 1, i + 2));
					}
				}
			}
			geometry.computeBoundingSphere();
			geometry.computeFaceNormals();
			mesh = new THREE.Mesh(geometry, currentMaterial);
			break;

		case CANNON.Shape.types.TRIMESH:
			var geometry = new THREE.Geometry();

			var v0 = new CANNON.Vec3();
			var v1 = new CANNON.Vec3();
			var v2 = new CANNON.Vec3();
			for (var i = 0; i < shape.indices.length / 3; i++) {
				shape.getTriangleVertices(i, v0, v1, v2);
				geometry.vertices.push(new THREE.Vector3(v0.x, v0.y, v0.z),
						new THREE.Vector3(v1.x, v1.y, v1.z), new THREE.Vector3(
								v2.x, v2.y, v2.z));
				var j = geometry.vertices.length - 3;
				geometry.faces.push(new THREE.Face3(j, j + 1, j + 2));
			}
			geometry.computeBoundingSphere();
			geometry.computeFaceNormals();
			mesh = new THREE.Mesh(geometry, currentMaterial);
			break;

		default:
			throw "Visual type not recognized: " + shape.type;
		}

		mesh.receiveShadow = true;
		mesh.castShadow = true;
		if (mesh.children) {
			for (var i = 0; i < mesh.children.length; i++) {
				mesh.children[i].castShadow = true;
				mesh.children[i].receiveShadow = true;
				if (mesh.children[i]) {
					for (var j = 0; j < mesh.children[i].length; j++) {
						mesh.children[i].children[j].castShadow = true;
						mesh.children[i].children[j].receiveShadow = true;
					}
				}
			}
		}

		var o = body.shapeOffsets[l];
		var q = body.shapeOrientations[l];
		mesh.position.set(o.x, o.y, o.z);
		mesh.quaternion.set(q.x, q.y, q.z, q.w);

		obj.add(mesh);
	}

	return obj;
};

/**
 * CANNON.jsの初期化
 */
function initWorld() {
	world = new CANNON.World(); // 物理世界を作成
	world.gravity.set(0, -9.82, 0); // 物理世界に重力を設定
	world.broadphase = new CANNON.NaiveBroadphase(); // 衝突している剛体の判定
	world.solver.iterations = 10; // 反復計算回数
	world.solver.tolerance = 0.1; // 許容値

	// Cannon Ground
	var groundMat = new CANNON.Material('groundMat'); // マテリアルを作成
	groundMat.friction = 0.3; // 摩擦係数
	groundMat.restitution = 0.5; // 反発係数

	phyPlane = new CANNON.Body({
		mass : 0
	}); // ボディを作成
	phyPlane.material = groundMat; // ボディにマテリアルを設定
	phyPlane.addShape(new CANNON.Plane()); // 地面を作成
	phyPlane.quaternion
			.setFromAxisAngle(new CANNON.Vec3(1, 0, 0), -Math.PI / 2); // 地面を回転
	world.add(phyPlane); // 物理世界に追加

	// Canon Sphere
	var cylinderShape = new CANNON.Cylinder(2, 2, 0.5, 30);

    var q = new CANNON.Quaternion();
    q.setFromAxisAngle(new CANNON.Vec3(1,0,0),Math.PI / 2);
    cylinderShape.transformAllPoints(new CANNON.Vec3(),q);
    
	var cylinderMat = new CANNON.Material('cylinderMat');
	cylinderMat.friction = 0.8;
	cylinderMat.restitution = 0.5;

	selfObj = new CANNON.Body({
		mass : 1
	});
	selfObj.material = cylinderMat;

	selfObj.addShape(cylinderShape);
	selfObj.position.x = selfData.posX;
	selfObj.position.y = selfData.height;
	selfObj.position.z = selfData.posY;
	selfObj.velocity.set(0, 10, 15);
	selfObj.angularDamping = 0.5;
	world.addBody(selfObj);
}

/**
 * Three.jsの初期化
 */
function setView() {
	scene = new THREE.Scene(); // Three.jsの世界（シーン）を作成
	scene.fog = new THREE.Fog(0x000000, 1, 100); // フォグを作成

	// Three Camera
	camera = new THREE.PerspectiveCamera(90, 800 / 600, 0.1, 10000);
	camera.position.set(0, 5, -3);

	camera.lookAt(new THREE.Vector3(0, 4, 0));

	scene.add(camera);

	// Three Light
	var light = new THREE.DirectionalLight(0xffffff, 0.5); // 照らす方向を指定する光源
	light.position.set(10, 10, -10); // 光源の位置を指定
	light.castShadow = true; // 影を作る物体かどうかを設定
	light.shadowMapWidth = 2024; // 影の精細さ（解像度）を設定
	light.shadowMapHeight = 2024; // 影の精細さ（解像度）を設定
	light.shadowCameraLeft = -50; // ライトの視点方向の影の表示度合い
	light.shadowCameraRight = 50; // ライトの視点方向の影の表示度合い
	light.shadowCameraTop = 50; // ライトの視点方向の影の表示度合い
	light.shadowCameraBottom = -50; // ライトの視点方向の影の表示度合い
	light.shadowCameraFar = 100; // 影を表示する範囲の設定
	light.shadowCameraNear = 0; // 影を表示する範囲の設定
	light.shadowDarkness = 0.5; // 影の透明度

	scene.add(light);

	var amb = new THREE.AmbientLight(0xffffff); // 全体に光を当てる光源
	scene.add(amb); // 光源をシーンに追加

	// Three Ground
	var graMeshGeometry = new THREE.PlaneGeometry(300, 300); // 地面の形状を作成
	var graMaterial = new THREE.MeshBasicMaterial({ // マテリアルを作成
		map : ground_texture
	// 地面にテクスチャ（砂地）を設定
	}); // 「ground_texture」は別部分で作成

	viewPlane = new THREE.Mesh(graMeshGeometry, graMaterial); // メッシュを作成
	viewPlane.rotation.x = -Math.PI / 2; // 地面を回転
	viewPlane.position.y = 1 / 2; // 地面の位置を設定
	viewPlane.receiveShadow = true; // 地面に影を表示する
	scene.add(viewPlane); // シーンに追加

	// Three Cylinder
	// viewCube = new THREE.Mesh(new THREE.CylinderGeometry(2, 2, 0.5, 30),
	// new THREE.MeshLambertMaterial({
	// color : 0xffff00
	// }));
	viewCube = shape2mesh(selfObj);
	scene.add(viewCube);

	// Three Render
	renderer = new THREE.WebGLRenderer({
		antialias : true
	}); // レンダラーを作成
	renderer.setSize(wSizeWidth, wSizeHeight); // レンダラーのサイズを設定

	renderer.setClearColor(0x000000, 1); // レンダラーの描画内容をクリア
	renderer.shadowMapEnabled = true; // レンダラーの影の描画を有効化
	document.body.appendChild(renderer.domElement); // DOM要素をBodyに追加

	// Start Rendering
	renderer.render(scene, camera); // レンダラーで3D空間を描画
}

function setObj() {
	selfObj.position.x = selfData.posX;
	selfObj.position.y = selfData.height;
	selfObj.position.z = selfData.posY;

	var vx = 0;
	var vy = -10 * Math.sin(last_gamma * Math.PI / 180.0);
	var vz = 10 * Math.cos(last_gamma * Math.PI / 180.0);
	selfObj.velocity.set(vx, vy, vz);
	selfObj.angularVelocity.set(0, 0, 0);
	selfObj.angularDamping = 0.5;
}

/**
 * レンダリング
 */
function animate() {
	if (acc !== last_acc) {
		setObj();
		last_acc = acc;
	}
	requestAnimationFrame(animate);

	// 物理エンジンの時間を進める
	world.step(1 / 60);
	viewCube.position.copy(selfObj.position);
	viewCube.position.y += 0.7;
	viewCube.quaternion.copy(selfObj.quaternion);
	// カメラ位置の設定
	// camera.position.set(selfObj.position.x, selfObj.position.y + 0.6,
	// selfObj.position.z);

	// レンダリング
	renderer.render(scene, camera);
}
