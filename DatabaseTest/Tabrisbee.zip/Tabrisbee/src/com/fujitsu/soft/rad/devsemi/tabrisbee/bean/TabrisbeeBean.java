package com.fujitsu.soft.rad.devsemi.tabrisbee.bean;

import java.io.Serializable;
import java.util.List;

import javax.annotation.Resource;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.UserTransaction;

import com.fujitsu.soft.rad.devsemi.tabrisbee.entity.Account;
import com.fujitsu.soft.rad.devsemi.tabrisbee.entity.Score;;

/**
 * アカウント画面のバッキングビーン
 * 
 * @author Hiradate, Mutsuki
 *
 */

@SuppressWarnings("serial")
@Named
@RequestScoped
public class TabrisbeeBean implements Serializable {
	private Account account;

	private int distance;

	public TabrisbeeBean() {
		distance = 0;
	}

	/**
	 * 距離をだす
	 * 
	 * @return 飛距離
	 */
	public int getDistance() {
		System.out.println("GET:" + distance);
		return distance;
	}

	/**
	 * 距離をだす
	 * 
	 * @return 飛距離
	 */
	public void setDistance(int distance) {
		this.distance = distance;
		System.out.println("SET:" + distance);
	}
	
	public void onChange(){
		System.out.println("ON CHANGE");
	}
}
