package com.fujitsu.soft.rad.devsemi.tabrisbee.entity;

import java.io.Serializable;
import java.lang.String;
import javax.persistence.*;

/**
 * Entity implementation class for Entity: Record
 *
 */
@Entity

public class Score implements Serializable {

	   
	@Id
	private int id;
	private String accountId;
	private int distance;
	private static final long serialVersionUID = 1L;

	public Score() {
		super();
	}   
	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}   
	public String getAccountId() {
		return this.accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}   
	public int getDistance() {
		return this.distance;
	}

	public void setDistance(int distance) {
		this.distance = distance;
	}
   
}
